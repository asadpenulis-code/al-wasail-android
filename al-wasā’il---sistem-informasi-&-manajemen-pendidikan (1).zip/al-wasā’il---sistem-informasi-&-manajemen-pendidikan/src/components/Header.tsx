import React, { useState } from 'react';
import { UserAccount, UserRole, PengaturanLembaga } from '../types';
import { Logo } from './Logo';
import { UserCheck, Shield, BookOpen, GraduationCap, Building2, ChevronDown, Download, Sparkles, LogOut, Menu } from 'lucide-react';

interface HeaderProps {
  currentUser: UserAccount;
  onSwitchRole: (role: UserRole, specificId?: string) => void;
  pengaturan: PengaturanLembaga;
  onOpenMutuModal: () => void;
  onOpenBackupModal: () => void;
  onToggleSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onSwitchRole,
  pengaturan,
  onOpenMutuModal,
  onOpenBackupModal,
  onToggleSidebar
}) => {
  const [showRoleMenu, setShowRoleMenu] = useState(false);

  const roleLabels: Record<UserRole, { label: string; icon: React.ReactNode; color: string }> = {
    admin: { label: 'Admin Utama', icon: <Shield className="w-4 h-4 text-amber-600" />, color: 'bg-amber-50 text-amber-900 border-amber-200' },
    guru: { label: 'Guru Al-Wasā’il', icon: <BookOpen className="w-4 h-4 text-blue-600" />, color: 'bg-blue-50 text-blue-900 border-blue-200' },
    santri: { label: 'Santri Al-Wasā’il', icon: <GraduationCap className="w-4 h-4 text-emerald-600" />, color: 'bg-emerald-50 text-emerald-900 border-emerald-200' },
    kepala: { label: 'Kepala Lembaga', icon: <Building2 className="w-4 h-4 text-purple-600" />, color: 'bg-purple-50 text-purple-900 border-purple-200' }
  };

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-[0_1px_3px_rgba(0,0,0,0.04)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Left Zone: Hamburger for Mobile + Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
              aria-label="Toggle navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <Logo size="md" logoUrl={pengaturan.logoUrl} />
          </div>

          {/* Slogan Banner on Desktop */}
          <div className="hidden xl:flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span className="font-arabic text-amber-700 font-semibold text-base">
              {pengaturan.sloganArab}
            </span>
            <span className="text-slate-300">·</span>
            <span className="italic text-slate-600">
              {pengaturan.sloganIndo}
            </span>
          </div>

          {/* Right Zone: Quality Analysis button, Backup, & Role Switcher */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Quick Mutual Quality Analyzer (Saran Utama Pengembangan) */}
            <button
              onClick={onOpenMutuModal}
              title="Analisis Mutu Metodologi Al-Wasā'il"
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#0B1B3D] bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Analisis Mutu</span>
            </button>

            {/* Backup DB quick button */}
            <button
              onClick={onOpenBackupModal}
              title="Pencadangan & Pemulihan Database"
              className="p-1.5 text-slate-600 hover:text-[#0B1B3D] hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Role Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowRoleMenu(!showRoleMenu)}
                className="flex items-center gap-2 px-2.5 py-1.5 text-xs font-medium bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors text-slate-700"
              >
                <span className="flex items-center gap-1.5">
                  {roleLabels[currentUser.role].icon}
                  <span className="hidden sm:inline font-semibold">{currentUser.name}</span>
                  <span className="text-slate-500 font-normal">({roleLabels[currentUser.role].label})</span>
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {showRoleMenu && (
                <div
                  className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-xl py-2 z-50 text-xs"
                  onMouseLeave={() => setShowRoleMenu(false)}
                >
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Ganti Hak Akses Akun</p>
                    <p className="text-slate-700 font-medium truncate mt-0.5">{currentUser.name}</p>
                  </div>

                  <div className="p-1 space-y-0.5">
                    <button
                      onClick={() => { onSwitchRole('admin'); setShowRoleMenu(false); }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${currentUser.role === 'admin' ? 'bg-amber-50 text-amber-900 font-semibold' : 'hover:bg-slate-50 text-slate-700'}`}
                    >
                      <Shield className="w-4 h-4 text-amber-600" />
                      <div>
                        <div>Admin Utama</div>
                        <div className="text-[10px] text-slate-400 font-normal">Kendali penuh sistem & data</div>
                      </div>
                    </button>

                    <button
                      onClick={() => { onSwitchRole('guru', 'g-2'); setShowRoleMenu(false); }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${currentUser.role === 'guru' ? 'bg-blue-50 text-blue-900 font-semibold' : 'hover:bg-slate-50 text-slate-700'}`}
                    >
                      <BookOpen className="w-4 h-4 text-blue-600" />
                      <div>
                        <div>Ust. M. Kholil (Guru)</div>
                        <div className="text-[10px] text-slate-400 font-normal">Absensi, jurnal & nilai kelas</div>
                      </div>
                    </button>

                    <button
                      onClick={() => { onSwitchRole('santri', 's-1'); setShowRoleMenu(false); }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${currentUser.role === 'santri' ? 'bg-emerald-50 text-emerald-900 font-semibold' : 'hover:bg-slate-50 text-slate-700'}`}
                    >
                      <GraduationCap className="w-4 h-4 text-emerald-600" />
                      <div>
                        <div>M. Faiz (Santri)</div>
                        <div className="text-[10px] text-slate-400 font-normal">Rapor, hafalan & absensi</div>
                      </div>
                    </button>

                    <button
                      onClick={() => { onSwitchRole('kepala'); setShowRoleMenu(false); }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${currentUser.role === 'kepala' ? 'bg-purple-50 text-purple-900 font-semibold' : 'hover:bg-slate-50 text-slate-700'}`}
                    >
                      <Building2 className="w-4 h-4 text-purple-600" />
                      <div>
                        <div>KH. Fauzi (Kepala Lembaga)</div>
                        <div className="text-[10px] text-slate-400 font-normal">Monitoring, tashih & analitik</div>
                      </div>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>
    </header>
  );
};
