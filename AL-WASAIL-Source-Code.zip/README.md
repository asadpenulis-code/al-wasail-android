# AL-WASAIL — Pondok Pesantren Al-Ihsan Jrangoan
> **Metode Mudah Baca Kitab Kuning**  
> Sistem Informasi & Manajemen Pendidikan Pesantren Terpadu

---

## 📖 Tentang Aplikasi
Aplikasi **AL-WASAIL** adalah platform manajemen pendidikan pesantren modern dan terintegrasi yang dirancang untuk mendukung pembelajaran gramatika Arab dan akselerasi membaca Kitab Kuning salafiyah khas **Pondok Pesantren Al-Ihsan Jrangoan**, Omben, Sampang, Madura.

Aplikasi ini mencakup 4 kategori pengguna (*Role-Based Access Control*):
1. **Pengurus / Administrator**: Manajemen seluruh data master, asatidz, santri, kelas, kurikulum, hak akses, dan backup data.
2. **Dewan Guru / Asatidz**: Pencatatan presensi real-time, input nilai 5 komponen evaluasi kitab, dan evaluasi berkala santri.
3. **Santri**: Akses jadwal pengajian, riwayat kehadiran, nilai dan raport digital, serta capaian level Al-Wasail.
4. **Wali Santri**: Pemantauan presensi dan perkembangan pendidikan putra/putri, raport digital resmi, dan warta pesantren.

---

## 📁 Struktur Direktori Proyek
```text
alwasail-app/
├── public/
│   ├── manifest.json            # Web App Manifest PWA Android
│   └── sw.js                    # Service Worker Offline Cache
├── src/
│   ├── assets/
│   │   └── images/              # Logo emblem resmi & foto kampus pesantren
│   ├── components/
│   │   └── common/              # Header, Sidebar, MobileNav, Splash, Modals
│   ├── context/
│   │   └── AuthContext.tsx      # Otentikasi sesi & otorisasi RBAC
│   ├── data/
│   │   └── initialData.ts       # Data awal lengkap PP Al-Ihsan Jrangoan
│   ├── hooks/
│   │   └── usePWAInstall.ts     # Hook instalasi instan PWA ke HP Android
│   ├── services/
│   │   ├── db.ts                # Database engine persistent, CRUD, & SQL generator
│   │   └── supabase.ts          # Integrasi klien Supabase cloud
│   ├── types/
│   │   └── index.ts             # Definisi TypeScript seluruh data model
│   ├── views/                   # 12 Modul tampilan utama aplikasi
│   ├── App.tsx                  # Root layout & routing internal
│   ├── index.css                # Tailwind CSS v4 & custom fonts
│   └── main.tsx                 # Entry point & PWA registration
├── capacitor.config.json        # Konfigurasi Capacitor untuk build Android Studio
├── index.html                   # HTML entry point dengan font Arab & PWA meta
├── package.json                 # Dependensi & script proyek
├── tsconfig.json                # Konfigurasi compiler TypeScript
└── vite.config.ts               # Konfigurasi Vite & Tailwind CSS
```

---

## 🚀 Panduan Menjalankan Proyek di Komputer Lokal

### 1. Prasyarat
- **Node.js** versi 18 atau lebih baru.
- **npm** atau **bun** / **yarn**.

### 2. Instalasi Dependensi
Buka terminal di direktori proyek dan jalankan:
```bash
npm install
```

### 3. Menjalankan Server Pengembangan (Dev Server)
```bash
npm run dev
```
Buka browser di `http://localhost:3000`.

---

## 📱 Panduan Kompilasi APK Android (Capacitor)

Proyek ini telah dikonfigurasi dengan `capacitor.config.json` (ID paket: `com.alwasail.alihsan.jrangoan`).

### Langkah 1: Pasang Dependensi Capacitor Android
```bash
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
```

### Langkah 2: Build Aset Web Produksi
```bash
npm run build
```

### Langkah 3: Inisialisasi Platform Android
```bash
npx cap add android
```
*Perintah ini akan membuat folder native `android/` lengkap dengan Gradle wrapper.*

### Langkah 4: Sinkronisasi Aset
```bash
npx cap sync android
```

### Langkah 5: Buka di Android Studio & Buat File APK
```bash
npx cap open android
```
Setelah Android Studio terbuka:
1. Tunggu proses **Gradle Sync** selesai.
2. Pilih menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. File `.apk` siap diinstal di HP Android Anda (tersimpan di `android/app/build/outputs/apk/debug/app-debug.apk`).

---

## 🗄️ Database Supabase & Row Level Security (RLS)
Aplikasi dapat dihubungkan ke proyek Supabase PostgreSQL Anda:
1. Buka dashboard di [supabase.com](https://supabase.com).
2. Buka **SQL Editor** pada proyek Supabase Anda.
3. Di dalam aplikasi AL-WASAIL, buka menu **Pengaturan > Integrasi Supabase**, klik tombol **"Salin SQL Migration & RLS"**, lalu jalankan skrip tersebut di SQL Editor Supabase.
4. Masukkan **Project URL** dan **Anon Key** ke dalam form Pengaturan di aplikasi dan klik **Simpan Kredensial**.

---

## 📝 Lisensi & Hak Cipta
Dikembangkan untuk **Pondok Pesantren Al-Ihsan Jrangoan**, Sampang, Jawa Timur.  
*Slogan: Metode Mudah Baca Kitab Kuning.*
