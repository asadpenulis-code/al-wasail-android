import React from 'react';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  BookOpen,
  CalendarCheck,
  Award,
  Calendar,
  Trophy,
  LineChart,
  Megaphone,
  FolderArchive,
  Settings,
  ChevronRight,
  Info,
  LogOut,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../services/db';
import { UserRole } from '../../types';

export interface MenuItem {
  id: string;
  label: string;
  icon: React.ElementType;
  description: string;
  allowedRoles: UserRole[];
}

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    description: 'Ringkasan & statistik aktivitas',
    allowedRoles: ['admin', 'guru', 'santri', 'wali'],
  },
  {
    id: 'santri',
    label: 'Data Santri',
    icon: Users,
    description: 'Biodata & status santri',
    allowedRoles: ['admin', 'guru'],
  },
  {
    id: 'guru',
    label: 'Data Guru',
    icon: GraduationCap,
    description: 'Asatidz & mata pelajaran',
    allowedRoles: ['admin'],
  },
  {
    id: 'akademik',
    label: 'Akademik & Kurikulum',
    icon: BookOpen,
    description: 'Kitab kuning & silabus Al-Wasail',
    allowedRoles: ['admin', 'guru', 'santri', 'wali'],
  },
  {
    id: 'absensi',
    label: 'Absensi',
    icon: CalendarCheck,
    description: 'Presensi harian & rekapitulasi',
    allowedRoles: ['admin', 'guru', 'santri', 'wali'],
  },
  {
    id: 'nilai',
    label: 'Penilaian & Raport',
    icon: Award,
    description: 'Nilai kitab & cetak raport',
    allowedRoles: ['admin', 'guru', 'santri', 'wali'],
  },
  {
    id: 'jadwal',
    label: 'Jadwal Pelajaran',
    icon: Calendar,
    description: 'Jadwal ngaji & madrasah',
    allowedRoles: ['admin', 'guru', 'santri', 'wali'],
  },
  {
    id: 'prestasi',
    label: 'Prestasi Santri',
    icon: Trophy,
    description: 'Musabaqah & piagam penghargaan',
    allowedRoles: ['admin', 'guru', 'santri', 'wali'],
  },
  {
    id: 'evaluasi',
    label: 'Evaluasi & Monitoring',
    icon: LineChart,
    description: 'Monitoring metode Al-Wasail',
    allowedRoles: ['admin', 'guru', 'wali'],
  },
  {
    id: 'pengumuman',
    label: 'Informasi & Pengumuman',
    icon: Megaphone,
    description: 'Warta resmi pesantren',
    allowedRoles: ['admin', 'guru', 'santri', 'wali'],
  },
  {
    id: 'dokumen',
    label: 'Arsip Dokumen',
    icon: FolderArchive,
    description: 'Berkas, modul & SK',
    allowedRoles: ['admin', 'guru', 'santri', 'wali'],
  },
  {
    id: 'pengaturan',
    label: 'Pengaturan',
    icon: Settings,
    description: 'Sistem, Supabase & backup',
    allowedRoles: ['admin'],
  },
];

interface SidebarProps {
  activeMenu: string;
  onSelectMenu: (menuId: string) => void;
  onOpenProfile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeMenu, onSelectMenu, onOpenProfile }) => {
  const { currentUser, role, logout } = useAuth();
  const lembaga = db.getLembaga();

  const roleLabels: Record<UserRole, { label: string; color: string }> = {
    admin: { label: 'Pengurus / Admin', color: 'bg-rose-50 text-rose-700 border-rose-200' },
    guru: { label: 'Guru / Asatidz', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
    santri: { label: 'Santri', color: 'bg-sky-50 text-sky-700 border-sky-200' },
    wali: { label: 'Wali Santri', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  };

  const currentRoleInfo = role ? roleLabels[role] : { label: 'Tamu', color: 'bg-slate-100 text-slate-700' };

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0 h-screen sticky top-0 z-30 select-none">
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-200 flex items-center gap-3">
        <img
          src={lembaga.logoUrl}
          alt="Logo AL-WASAIL"
          className="w-10 h-10 rounded-full border border-sky-200 object-cover bg-white shadow-xs"
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="font-extrabold text-base tracking-wide text-sky-900 leading-none">AL-WASAIL</span>
            <span className="text-[10px] font-semibold text-sky-600 bg-sky-50 px-1.5 py-0.5 rounded border border-sky-100">PP Al-Ihsan</span>
          </div>
          <p className="text-[11px] text-slate-500 truncate mt-1">{lembaga.slogan}</p>
        </div>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
          Menu Navigasi
        </div>
        {MENU_ITEMS.map((item) => {
          const isAllowed = role ? item.allowedRoles.includes(role) : false;
          if (!isAllowed) return null;

          const isActive = activeMenu === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => onSelectMenu(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                isActive
                  ? 'bg-sky-600 text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500'}`} />
              <span className="truncate flex-1">{item.label}</span>
              {isActive && <ChevronRight className="w-3.5 h-3.5 opacity-80 shrink-0" />}
            </button>
          );
        })}
      </div>

      {/* Institution Info & User Bar */}
      <div className="p-3 border-t border-slate-200 space-y-2 bg-slate-50/50">
        <button
          onClick={onOpenProfile}
          className="w-full flex items-center justify-between p-2 rounded-lg bg-sky-50/80 hover:bg-sky-100/80 border border-sky-200/60 text-sky-800 transition-colors text-left"
        >
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-sky-600 shrink-0" />
            <div className="min-w-0">
              <span className="text-xs font-semibold block truncate">Profil Lembaga</span>
              <span className="text-[10px] text-slate-500 block truncate">Al-Ihsan Jrangoan</span>
            </div>
          </div>
          <ChevronRight className="w-3.5 h-3.5 text-sky-600" />
        </button>

        {/* Current User Card */}
        <div className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-200">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold text-slate-900 truncate block">
                {currentUser?.fullName || 'Pengguna'}
              </span>
            </div>
            <span className={`inline-block text-[10px] font-medium px-1.5 py-0.2 rounded border mt-0.5 ${currentRoleInfo.color}`}>
              {currentRoleInfo.label}
            </span>
          </div>

          <button
            onClick={logout}
            title="Keluar dari akun"
            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors shrink-0"
            aria-label="Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
