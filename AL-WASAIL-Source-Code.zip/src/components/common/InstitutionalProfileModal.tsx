import React from 'react';
import { X, BookOpen, MapPin, Phone, Mail, Award, CheckCircle2, Globe, Building2 } from 'lucide-react';
import { db } from '../../services/db';

interface InstitutionalProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstitutionalProfileModal: React.FC<InstitutionalProfileModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;
  const lembaga = db.getLembaga();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Banner with Campus Photo */}
        <div className="relative h-48 sm:h-56 w-full bg-sky-900 overflow-hidden">
          <img
            src={lembaga.bannerUrl}
            alt="Pesantren Al-Ihsan Jrangoan"
            className="w-full h-full object-cover opacity-85"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-900/40 to-transparent" />
          
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/20 hover:bg-white/30 text-white backdrop-blur-md transition-colors"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-4 left-6 right-6 flex items-end gap-4">
            <img
              src={lembaga.logoUrl}
              alt="Logo AL-WASAIL"
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-white shadow-lg bg-white object-cover shrink-0"
            />
            <div className="text-white pb-1">
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight">{lembaga.namaLengkap}</h2>
              <p className="text-sky-300 text-xs sm:text-sm font-medium">
                {lembaga.nama} — <span className="italic">{lembaga.slogan}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Quick Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-sky-50 rounded-xl border border-sky-100">
              <span className="text-[11px] text-sky-700 font-medium block">NSPP Kemenag</span>
              <span className="text-sm font-bold text-slate-800 font-mono">{lembaga.nspp}</span>
            </div>
            <div className="p-3 bg-sky-50 rounded-xl border border-sky-100">
              <span className="text-[11px] text-sky-700 font-medium block">Tahun Berdiri</span>
              <span className="text-sm font-bold text-slate-800 font-mono">{lembaga.tahunBerdiri} M</span>
            </div>
            <div className="p-3 bg-sky-50 rounded-xl border border-sky-100">
              <span className="text-[11px] text-sky-700 font-medium block">Pengasuh</span>
              <span className="text-xs sm:text-sm font-bold text-slate-800 truncate block">{lembaga.pengasuh}</span>
            </div>
            <div className="p-3 bg-sky-50 rounded-xl border border-sky-100">
              <span className="text-[11px] text-sky-700 font-medium block">Ketua Pengurus</span>
              <span className="text-xs sm:text-sm font-bold text-slate-800 truncate block">{lembaga.ketuaPengurus}</span>
            </div>
          </div>

          {/* Slogan & Metode Al-Wasail Spotlight */}
          <div className="p-5 bg-gradient-to-r from-sky-50 via-sky-100/50 to-amber-50/50 rounded-2xl border border-sky-200">
            <div className="flex items-center gap-2 mb-2">
              <BookOpen className="w-5 h-5 text-sky-600" />
              <h3 className="text-base font-bold text-slate-900">Tentang Metode AL-WASAIL</h3>
            </div>
            <p className="text-sm text-slate-700 leading-relaxed">
              {lembaga.deskripsiMetode}
            </p>
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-white rounded-xl shadow-xs border border-sky-100">
                <span className="text-xs font-bold text-sky-700 block">Fase 1: Fondasi</span>
                <p className="text-xs text-slate-600 mt-0.5">Pengenalan pola kalimat (Tarkib) & tanda-tanda I'rob praktis.</p>
              </div>
              <div className="p-3 bg-white rounded-xl shadow-xs border border-sky-100">
                <span className="text-xs font-bold text-sky-700 block">Fase 2: Transisi</span>
                <p className="text-xs text-slate-600 mt-0.5">Membaca kitab gundul berharokat minim dengan analisis gramatika.</p>
              </div>
              <div className="p-3 bg-white rounded-xl shadow-xs border border-sky-100">
                <span className="text-xs font-bold text-sky-700 block">Fase 3: Kemandirian</span>
                <p className="text-xs text-slate-600 mt-0.5">Membaca kitab kuning gundul murni dan telaah makna kontekstual.</p>
              </div>
            </div>
          </div>

          {/* Visi & Misi */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-sky-700">Visi Lembaga</h3>
            <p className="text-sm text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-200 italic">
              "{lembaga.visi}"
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-sky-700">Misi Utama</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {lembaga.misi.map((m, idx) => (
                <div key={idx} className="flex items-start gap-2.5 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{m}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Kontak & Lokasi */}
          <div className="border-t border-slate-200 pt-5 space-y-2 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-sky-600 shrink-0" />
              <span>Desa {lembaga.desa}, Kec. {lembaga.kecamatan}, Kab. {lembaga.kabupaten}, {lembaga.provinsi} {lembaga.kodePos}</span>
            </div>
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-sky-600 shrink-0" />
                <span>{lembaga.telepon}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-sky-600 shrink-0" />
                <span>{lembaga.email}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-colors"
          >
            Tutup Informasi
          </button>
        </div>
      </div>
    </div>
  );
};
