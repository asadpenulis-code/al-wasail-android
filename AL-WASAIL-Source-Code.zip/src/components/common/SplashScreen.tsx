import React, { useEffect, useState } from 'react';
import { BookOpen, Sparkles, ChevronRight } from 'lucide-react';
import { db } from '../../services/db';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);
  const lembaga = db.getLembaga();

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onFinish, 300);
          return 100;
        }
        return prev + 15;
      });
    }, 180);

    return () => clearInterval(interval);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-br from-sky-600 via-sky-700 to-slate-900 text-white p-6 select-none overflow-hidden">
      {/* Decorative Islamic Geometric Pattern Overlay */}
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px]" />

      {/* Top institution tag */}
      <div className="pt-8 text-center z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-medium text-sky-100 border border-white/20">
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Sistem Informasi & Manajemen Terpadu</span>
        </div>
      </div>

      {/* Center Branding */}
      <div className="flex flex-col items-center text-center max-w-sm z-10 px-4">
        <div className="relative mb-5 group">
          <div className="absolute -inset-2 bg-gradient-to-r from-sky-400 to-amber-300 rounded-full blur-xl opacity-40 animate-pulse" />
          <img
            src={lembaga.logoUrl}
            alt="Logo AL-WASAIL PP Al-Ihsan Jrangoan"
            className="relative w-32 h-32 md:w-36 md:h-36 rounded-full shadow-2xl border-4 border-white/30 object-cover bg-white"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>

        <h1 className="text-3xl md:text-4xl font-extrabold tracking-wider text-white uppercase drop-shadow-md">
          AL-WASAIL
        </h1>
        <p className="text-base md:text-lg font-semibold text-sky-100 mt-1">
          {lembaga.namaLengkap}
        </p>
        <p className="text-xs md:text-sm text-sky-200/90 font-medium tracking-wide mt-2 px-3 py-1 bg-sky-950/40 rounded-full border border-sky-400/30">
          "{lembaga.slogan}"
        </p>
      </div>

      {/* Bottom Progress Bar & Skip Action */}
      <div className="w-full max-w-xs pb-10 flex flex-col items-center gap-4 z-10">
        <div className="w-full bg-white/20 rounded-full h-2 overflow-hidden backdrop-blur-sm">
          <div
            className="bg-gradient-to-r from-amber-300 via-sky-300 to-white h-full transition-all duration-200 ease-out rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex items-center justify-between w-full text-xs text-sky-200 font-mono">
          <span>Memuat Sistem...</span>
          <span>{progress}%</span>
        </div>

        <button
          onClick={onFinish}
          className="mt-2 text-xs font-semibold text-sky-100 hover:text-white flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-white/10 hover:bg-white/20 transition-all border border-white/15 active:scale-95"
        >
          <span>Langsung Masuk</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
