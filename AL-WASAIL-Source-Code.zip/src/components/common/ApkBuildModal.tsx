import React, { useState } from 'react';
import { X, Smartphone, Download, Terminal, CheckCircle2, Copy, Check, Sparkles, Layers, ArrowDownToLine } from 'lucide-react';
import { db } from '../../services/db';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface ApkBuildModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkBuildModal: React.FC<ApkBuildModalProps> = ({ isOpen, onClose }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const { isInstallable, install, isInstalled } = usePWAInstall();
  const lembaga = db.getLembaga();

  if (!isOpen) return null;

  const copyCommand = (cmd: string, idx: number) => {
    navigator.clipboard.writeText(cmd);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const steps = [
    {
      title: 'Langkah 1: Build Aset Web Produksi',
      command: 'npm run build',
      description: 'Mengompilasi seluruh kode React, Tailwind CSS, dan aset Vite ke direktori /dist.',
    },
    {
      title: 'Langkah 2: Tambahkan Platform Android Capacitor',
      command: 'npx cap add android',
      description: 'Menyiapkan folder native Android Studio lengkap dengan Gradle wrapper dan AndroidManifest.xml.',
    },
    {
      title: 'Langkah 3: Sinkronisasi Aset & Konfigurasi',
      command: 'npx cap sync android',
      description: 'Menyalin bundle dist web ke dalam aset Android dan menyinkronkan plugin Capacitor.',
    },
    {
      title: 'Langkah 4: Buka Proyek & Compile APK Debug / Release',
      command: 'npx cap open android',
      description: 'Membuka Android Studio. Pilih menu Build > Build Bundle(s) / APK(s) > Build APK(s) untuk menghasilkan file alwasail.apk siap instal di HP.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-sky-600 via-sky-700 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/10 rounded-xl backdrop-blur-sm border border-white/20">
              <Smartphone className="w-6 h-6 text-sky-200" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Build & Instalasi APK Android AL-WASAIL</h2>
              <p className="text-xs text-sky-100">{lembaga.namaLengkap}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Mobile Ready Status Banner */}
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-xs text-emerald-900">
              <span className="font-bold block text-sm">Aplikasi Siap Digunakan di HP Android & Tablet</span>
              <span>
                AL-WASAIL telah dirancang responsif dengan standar touch target 48px, bottom navigation,
                dan kompatibel penuh sebagai Progressive Web App (PWA) instan atau dibungkus menjadi APK mandiri melalui Capacitor.
              </span>
            </div>
          </div>

          {/* Quick Install Option: PWA */}
          <div className="p-4 bg-sky-50 rounded-2xl border border-sky-100 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-sky-900 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-sky-600" />
                <span>Opsi 1: Instal Langsung ke Layar Utama HP (PWA Web APK)</span>
              </h3>
              {isInstalled && (
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Sudah Terpasang
                </span>
              )}
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Aplikasi ini telah memenuhi standar resmi Progressive Web App (PWA). Anda dapat memasangnya langsung di HP Android tanpa perlu membuka Android Studio.
            </p>

            {isInstallable && (
              <button
                onClick={install}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                <ArrowDownToLine className="w-4 h-4" />
                <span>Klik untuk Pasang / Instal di HP Sekarang (1-Klik)</span>
              </button>
            )}

            <div className="text-[11px] text-slate-500 bg-white/80 p-2.5 rounded-xl border border-sky-200/60">
              💡 <strong>Cara di Browser Google Chrome Android:</strong> Buka menu browser (titik 3 di kanan atas) &gt; pilih <strong>"Tambahkan ke Layar Utama" (Add to Home screen)</strong> atau <strong>"Instal Aplikasi"</strong>.
            </div>
          </div>

          {/* Option 2: Capacitor Native Android APK Build */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-sky-600" />
              <span>Opsi 2: Alur Kompilasi APK Native dengan Capacitor & Android Studio</span>
            </h3>

            <div className="space-y-3">
              {steps.map((st, idx) => (
                <div key={idx} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-slate-800">{st.title}</span>
                    <button
                      onClick={() => copyCommand(st.command, idx)}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-[11px] font-mono text-slate-700 transition-colors"
                      title="Salin Perintah"
                    >
                      {copiedIndex === idx ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span className="text-emerald-700">Tersalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-slate-400" />
                          <span>Salin</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="p-2 bg-slate-900 rounded-lg text-emerald-400 font-mono text-xs overflow-x-auto flex items-center justify-between">
                    <code>{st.command}</code>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1.5 leading-normal">{st.description}</p>
                </div>
              ))}
            </div>
          </div>
          {/* Option 3: Download Complete Source Code ZIP */}
          <div className="p-4 bg-gradient-to-r from-sky-50 via-sky-100/40 to-indigo-50 rounded-2xl border border-sky-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-sky-900 uppercase tracking-wider flex items-center gap-1.5">
                <Download className="w-4 h-4 text-sky-600" />
                <span>Unduh Seluruh Source Code Lengkap (.ZIP)</span>
              </h3>
              <span className="text-[10px] font-mono font-bold text-sky-700 bg-white px-2 py-0.5 rounded border border-sky-200">
                1.67 MB (.ZIP)
              </span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Paket ZIP berisi seluruh kode sumber (React, TypeScript, Tailwind CSS), konfigurasi Capacitor Android (<code className="font-mono text-slate-800">capacitor.config.json</code>), manifest PWA, service worker, aset visual resmi, panduan <code className="font-mono text-slate-800">README.md</code>, dan skrip database. Siap diekstrak dan langsung dibuild di Android Studio atau VS Code.
            </p>
            <a
              href="/AL-WASAIL-Source-Code.zip"
              download="AL-WASAIL-Source-Code.zip"
              className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Unduh AL-WASAIL-Source-Code.zip Sekarang</span>
            </a>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">Paket ID: com.alwasail.alihsan.jrangoan</span>
          <div className="flex items-center gap-2">
            <a
              href="/AL-WASAIL-Source-Code.zip"
              download="AL-WASAIL-Source-Code.zip"
              className="px-4 py-2 text-xs font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-xl border border-sky-200 flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh ZIP</span>
            </a>
            <button
              onClick={onClose}
              className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-colors"
            >
              Selesai
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
