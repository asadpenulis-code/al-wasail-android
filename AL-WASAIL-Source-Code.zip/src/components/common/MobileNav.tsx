import React from 'react';
import {
  LayoutDashboard,
  CalendarCheck,
  Award,
  Users,
  Grid,
  X,
  ChevronRight,
  LogOut,
  Info,
  BookOpen,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../services/db';
import { MENU_ITEMS } from './Sidebar';

interface MobileNavProps {
  activeMenu: string;
  onSelectMenu: (menuId: string) => void;
  isDrawerOpen: boolean;
  onCloseDrawer: () => void;
  onOpenProfile: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeMenu,
  onSelectMenu,
  isDrawerOpen,
  onCloseDrawer,
  onOpenProfile,
}) => {
  const { role, logout, currentUser } = useAuth();
  const lembaga = db.getLembaga();

  // Bottom 4-5 core quick destinations
  const bottomQuickTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: role === 'admin' ? 'santri' : 'akademik', label: role === 'admin' ? 'Santri' : 'Kurikulum', icon: role === 'admin' ? Users : BookOpen },
    { id: 'absensi', label: 'Absensi', icon: CalendarCheck },
    { id: 'nilai', label: 'Nilai', icon: Award },
    { id: 'more', label: 'Lainnya', icon: Grid },
  ];

  return (
    <>
      {/* Fixed Bottom Tab Bar for Mobile */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg px-2 pb-safe">
        <div className="grid grid-cols-5 items-center h-16">
          {bottomQuickTabs.map((tab) => {
            const isMore = tab.id === 'more';
            const isActive = isMore ? isDrawerOpen : activeMenu === tab.id && !isDrawerOpen;
            const Icon = tab.icon;

            return (
              <button
                key={tab.id}
                onClick={() => {
                  if (isMore) {
                    // Toggle drawer
                    if (isDrawerOpen) onCloseDrawer();
                    else onSelectMenu('__OPEN_DRAWER__');
                  } else {
                    onSelectMenu(tab.id);
                    if (isDrawerOpen) onCloseDrawer();
                  }
                }}
                className="min-h-[44px] flex flex-col items-center justify-center py-1 transition-transform active:scale-95"
              >
                <div
                  className={`p-1 rounded-xl transition-colors ${
                    isActive ? 'bg-sky-100 text-sky-700' : 'text-slate-500'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span
                  className={`text-[10px] font-medium tracking-tight mt-0.5 ${
                    isActive ? 'text-sky-700 font-bold' : 'text-slate-500'
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Slide-out Full Drawer for 12 Menus on Mobile */}
      {isDrawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            onClick={onCloseDrawer}
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity animate-fade-in"
          />

          {/* Drawer Panel */}
          <div className="relative w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-200">
            {/* Drawer Header */}
            <div className="p-4 bg-gradient-to-r from-sky-600 to-sky-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={lembaga.logoUrl}
                  alt="Logo AL-WASAIL"
                  className="w-10 h-10 rounded-full border-2 border-white/50 bg-white object-cover shadow-xs"
                />
                <div>
                  <h2 className="text-base font-bold leading-tight">AL-WASAIL</h2>
                  <p className="text-[11px] text-sky-100">PP Al-Ihsan Jrangoan</p>
                </div>
              </div>
              <button
                onClick={onCloseDrawer}
                className="p-1.5 rounded-lg bg-white/20 text-white hover:bg-white/30 transition-colors"
                aria-label="Tutup Menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current user badge in drawer */}
            <div className="p-3 bg-sky-50/70 border-b border-sky-100 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-800 block truncate">{currentUser?.fullName}</span>
                <span className="text-[10px] text-sky-700 font-medium capitalize">Peran: {role}</span>
              </div>
              <button
                onClick={() => {
                  onOpenProfile();
                  onCloseDrawer();
                }}
                className="text-[11px] text-sky-600 font-semibold hover:underline flex items-center gap-1"
              >
                <Info className="w-3.5 h-3.5" />
                <span>Info</span>
              </button>
            </div>

            {/* 12 Menus List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-1">
              <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                12 Menu Utama AL-WASAIL
              </div>

              {MENU_ITEMS.map((item) => {
                const isAllowed = role ? item.allowedRoles.includes(role) : false;
                if (!isAllowed) return null;

                const isActive = activeMenu === item.id;
                const Icon = item.icon;

                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectMenu(item.id);
                      onCloseDrawer();
                    }}
                    className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-xs text-left transition-colors ${
                      isActive
                        ? 'bg-sky-600 text-white font-semibold shadow-xs'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                    <div className="flex-1 min-w-0">
                      <span className="block truncate">{item.label}</span>
                      <span className={`block text-[10px] truncate ${isActive ? 'text-sky-100' : 'text-slate-400'}`}>
                        {item.description}
                      </span>
                    </div>
                    <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-slate-300'}`} />
                  </button>
                );
              })}
            </div>

            {/* Drawer Footer */}
            <div className="p-3 border-t border-slate-200 bg-slate-50">
              <button
                onClick={() => {
                  logout();
                  onCloseDrawer();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Keluar Akun</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
