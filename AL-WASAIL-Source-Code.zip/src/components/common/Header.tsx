import React, { useState } from 'react';
import { Menu, Bell, Info, Shield, ChevronDown, Check, Smartphone, Download } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../services/db';
import { UserRole } from '../../types';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface HeaderProps {
  onToggleMobileMenu: () => void;
  onOpenProfile: () => void;
  onOpenApkModal?: () => void;
  currentMenuTitle: string;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleMobileMenu,
  onOpenProfile,
  onOpenApkModal,
  currentMenuTitle,
}) => {
  const { currentUser, role, switchRole } = useAuth();
  const { isInstallable, install, isInstalled } = usePWAInstall();
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const lembaga = db.getLembaga();
  const pengumuman = db.getPengumuman();

  const rolesList: { id: UserRole; label: string; desc: string }[] = [
    { id: 'admin', label: 'Pengurus / Admin', desc: 'Hak akses penuh kelola seluruh data & sistem' },
    { id: 'guru', label: 'Guru / Asatidz', desc: 'Isi absensi, input nilai, evaluasi santri' },
    { id: 'santri', label: 'Santri', desc: 'Lihat jadwal, absensi, nilai & perkembangan Al-Wasail' },
    { id: 'wali', label: 'Wali Santri', desc: 'Pantau kehadiran, nilai & raport putra/putri' },
  ];

  return (
    <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-20 flex items-center justify-between px-4 sm:px-6 gap-4">
      {/* Zone 1: Mobile Menu Button & Brand Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleMobileMenu}
          className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
          aria-label="Buka Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <img
            src={lembaga.logoUrl}
            alt="AL-WASAIL"
            className="w-8 h-8 rounded-full border border-sky-200 object-cover lg:hidden"
          />
          <div>
            <h1 className="text-sm sm:text-base font-bold text-slate-900 leading-tight flex items-center gap-2">
              <span className="text-sky-700">AL-WASAIL</span>
              <span className="hidden sm:inline text-slate-300">/</span>
              <span className="hidden sm:inline text-xs font-medium text-slate-600">{currentMenuTitle}</span>
            </h1>
            <p className="text-[10px] text-slate-500 hidden sm:block truncate">
              {lembaga.namaLengkap} · <span className="text-sky-600 font-medium">{lembaga.slogan}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Zone 2: Quick Role Switcher Pill / Badge */}
      <div className="relative">
        <button
          onClick={() => setRoleMenuOpen(!roleMenuOpen)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 text-xs font-semibold transition-all shadow-2xs"
          title="Ganti Mode Peran Pengguna"
        >
          <Shield className="w-3.5 h-3.5 text-sky-600" />
          <span className="truncate max-w-[120px] sm:max-w-none">
            Peran: <span className="capitalize">{role || 'Tamu'}</span>
          </span>
          <ChevronDown className="w-3 h-3 text-sky-600" />
        </button>

        {roleMenuOpen && (
          <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in zoom-in-95 duration-100">
            <div className="px-3 py-2 border-b border-slate-100 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Ganti Hak Akses (RBAC)
            </div>
            <div className="py-1 space-y-1">
              {rolesList.map((r) => (
                <button
                  key={r.id}
                  onClick={() => {
                    switchRole(r.id);
                    setRoleMenuOpen(false);
                  }}
                  className={`w-full flex items-start gap-2.5 p-2 rounded-xl text-left text-xs transition-colors ${
                    role === r.id ? 'bg-sky-50 text-sky-900 font-semibold' : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className={`mt-0.5 p-1 rounded-full ${role === r.id ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-400'}`}>
                    <Check className="w-3 h-3" />
                  </div>
                  <div>
                    <span className="block font-medium">{r.label}</span>
                    <span className="block text-[10px] text-slate-500 leading-tight mt-0.5">{r.desc}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Zone 3: Action Controls */}
      <div className="flex items-center gap-2">
        {/* In-App Direct Install or APK Guide */}
        {!isInstalled && (
          <button
            onClick={() => {
              if (isInstallable) {
                install();
              } else if (onOpenApkModal) {
                onOpenApkModal();
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs transition-colors"
            title="Instal AL-WASAIL ke HP"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isInstallable ? 'Instal ke HP' : 'APK & Instal'}</span>
            <span className="sm:hidden">Instal</span>
          </button>
        )}

        {/* Institution Info */}
        <button
          onClick={onOpenProfile}
          className="p-2 text-slate-600 hover:text-sky-700 hover:bg-sky-50 rounded-xl transition-colors"
          title="Profil Pesantren Al-Ihsan Jrangoan"
          aria-label="Profil Lembaga"
        >
          <Info className="w-4 h-4" />
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="p-2 text-slate-600 hover:text-sky-700 hover:bg-sky-50 rounded-xl transition-colors relative"
            title="Pemberitahuan & Pengumuman"
            aria-label="Notifikasi"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full" />
          </button>

          {notifOpen && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 z-50">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold text-slate-900">Pemberitahuan Pesantren</span>
                <span className="text-[10px] text-sky-600 font-medium font-mono">{pengumuman.length} Terkini</span>
              </div>
              <div className="py-2 space-y-2 max-h-64 overflow-y-auto">
                {pengumuman.slice(0, 4).map((p) => (
                  <div key={p.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs hover:bg-sky-50/50 transition-colors">
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="text-[10px] font-bold text-sky-700 uppercase">{p.kategori}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{p.tanggal}</span>
                    </div>
                    <p className="font-semibold text-slate-800 line-clamp-1">{p.judul}</p>
                    <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">{p.konten}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
