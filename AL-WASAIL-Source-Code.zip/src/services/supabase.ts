import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { db } from './db';

let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const config = db.getSupabaseConfig();
  if (!config.url || !config.anonKey) {
    return null;
  }
  if (!supabaseInstance) {
    try {
      supabaseInstance = createClient(config.url, config.anonKey);
    } catch (err) {
      console.warn('Failed to initialize Supabase client:', err);
      return null;
    }
  }
  return supabaseInstance;
}

export async function testSupabaseConnection(url: string, anonKey: string): Promise<{ success: boolean; message: string }> {
  try {
    const tempClient = createClient(url, anonKey);
    const { error } = await tempClient.from('lembaga_profil').select('id').limit(1);
    if (error && error.code !== 'PGRST116' && !error.message.includes('relation "lembaga_profil" does not exist')) {
      // If error is table not found, connection is valid, just schema not run yet
      if (error.message.includes('does not exist')) {
        return {
          success: true,
          message: 'Koneksi ke Supabase BERHASIL! (Catatan: Tabel belum dibuat, silakan jalankan SQL Schema di SQL Editor Supabase).',
        };
      }
      return { success: false, message: `Koneksi gagal: ${error.message}` };
    }
    return {
      success: true,
      message: 'Koneksi ke Supabase BERHASIL & Database siap digunakan!',
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return {
      success: false,
      message: `Error koneksi: ${errorMsg}. Pastikan URL dan Anon Key valid.`,
    };
  }
}
