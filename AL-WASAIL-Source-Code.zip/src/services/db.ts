import {
  LembagaProfil,
  UserAccount,
  Santri,
  Guru,
  Kelas,
  KitabKuning,
  AbsensiRecord,
  NilaiRaport,
  JadwalPelajaran,
  PrestasiSantri,
  EvaluasiMonitoring,
  Pengumuman,
  ArsipDokumen,
  SupabaseConfig,
} from '../types';
import {
  initialLembaga,
  initialUsers,
  initialSantri,
  initialGuru,
  initialKelas,
  initialKitab,
  initialAbsensi,
  initialNilai,
  initialJadwal,
  initialPrestasi,
  initialEvaluasi,
  initialPengumuman,
  initialDokumen,
} from '../data/initialData';

const DB_PREFIX = 'alwasail_db_v1_';

function getStorage<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(DB_PREFIX + key);
    if (!raw) {
      localStorage.setItem(DB_PREFIX + key, JSON.stringify(defaultValue));
      return defaultValue;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.warn(`Error reading ${key} from storage:`, err);
    return defaultValue;
  }
}

function setStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(DB_PREFIX + key, JSON.stringify(data));
    window.dispatchEvent(new CustomEvent('alwasail_db_updated', { detail: { table: key } }));
  } catch (err) {
    console.error(`Error saving ${key} to storage:`, err);
  }
}

class DatabaseService {
  // Config Supabase
  getSupabaseConfig(): SupabaseConfig {
    return getStorage<SupabaseConfig>('supabase_config', {
      url: '',
      anonKey: '',
      isConnected: false,
      autoSync: false,
    });
  }

  saveSupabaseConfig(cfg: Partial<SupabaseConfig>): SupabaseConfig {
    const current = this.getSupabaseConfig();
    const updated = { ...current, ...cfg };
    setStorage('supabase_config', updated);
    return updated;
  }

  // Profil Lembaga
  getLembaga(): LembagaProfil {
    return getStorage<LembagaProfil>('lembaga', initialLembaga);
  }

  updateLembaga(data: Partial<LembagaProfil>): LembagaProfil {
    const current = this.getLembaga();
    const updated = { ...current, ...data };
    setStorage('lembaga', updated);
    return updated;
  }

  // Akun Pengguna
  getUsers(): UserAccount[] {
    return getStorage<UserAccount[]>('users', initialUsers);
  }

  createUser(user: Omit<UserAccount, 'id'>): UserAccount {
    const users = this.getUsers();
    const newUser: UserAccount = {
      ...user,
      id: `usr-${Date.now()}`,
    };
    setStorage('users', [newUser, ...users]);
    return newUser;
  }

  updateUser(id: string, data: Partial<UserAccount>): UserAccount | null {
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    users[idx] = { ...users[idx], ...data };
    setStorage('users', users);
    return users[idx];
  }

  deleteUser(id: string): boolean {
    const users = this.getUsers();
    const filtered = users.filter(u => u.id !== id);
    if (filtered.length === users.length) return false;
    setStorage('users', filtered);
    return true;
  }

  // Data Santri
  getSantri(): Santri[] {
    return getStorage<Santri[]>('santri', initialSantri);
  }

  createSantri(item: Omit<Santri, 'id'>): Santri {
    const list = this.getSantri();
    const newItem: Santri = {
      ...item,
      id: `santri-${Date.now()}`,
    };
    setStorage('santri', [newItem, ...list]);
    return newItem;
  }

  updateSantri(id: string, data: Partial<Santri>): Santri | null {
    const list = this.getSantri();
    const idx = list.findIndex(s => s.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...data };
    setStorage('santri', list);
    return list[idx];
  }

  deleteSantri(id: string): boolean {
    const list = this.getSantri();
    const filtered = list.filter(s => s.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('santri', filtered);
    return true;
  }

  // Data Guru
  getGuru(): Guru[] {
    return getStorage<Guru[]>('guru', initialGuru);
  }

  createGuru(item: Omit<Guru, 'id'>): Guru {
    const list = this.getGuru();
    const newItem: Guru = {
      ...item,
      id: `guru-${Date.now()}`,
    };
    setStorage('guru', [newItem, ...list]);
    return newItem;
  }

  updateGuru(id: string, data: Partial<Guru>): Guru | null {
    const list = this.getGuru();
    const idx = list.findIndex(g => g.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...data };
    setStorage('guru', list);
    return list[idx];
  }

  deleteGuru(id: string): boolean {
    const list = this.getGuru();
    const filtered = list.filter(g => g.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('guru', filtered);
    return true;
  }

  // Kelas
  getKelas(): Kelas[] {
    return getStorage<Kelas[]>('kelas', initialKelas);
  }

  createKelas(item: Omit<Kelas, 'id'>): Kelas {
    const list = this.getKelas();
    const newItem: Kelas = {
      ...item,
      id: `kls-${Date.now()}`,
    };
    setStorage('kelas', [...list, newItem]);
    return newItem;
  }

  updateKelas(id: string, data: Partial<Kelas>): Kelas | null {
    const list = this.getKelas();
    const idx = list.findIndex(k => k.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...data };
    setStorage('kelas', list);
    return list[idx];
  }

  deleteKelas(id: string): boolean {
    const list = this.getKelas();
    const filtered = list.filter(k => k.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('kelas', filtered);
    return true;
  }

  // Kitab Kuning
  getKitab(): KitabKuning[] {
    return getStorage<KitabKuning[]>('kitab', initialKitab);
  }

  createKitab(item: Omit<KitabKuning, 'id'>): KitabKuning {
    const list = this.getKitab();
    const newItem: KitabKuning = {
      ...item,
      id: `ktb-${Date.now()}`,
    };
    setStorage('kitab', [...list, newItem]);
    return newItem;
  }

  updateKitab(id: string, data: Partial<KitabKuning>): KitabKuning | null {
    const list = this.getKitab();
    const idx = list.findIndex(k => k.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...data };
    setStorage('kitab', list);
    return list[idx];
  }

  deleteKitab(id: string): boolean {
    const list = this.getKitab();
    const filtered = list.filter(k => k.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('kitab', filtered);
    return true;
  }

  // Absensi
  getAbsensi(): AbsensiRecord[] {
    return getStorage<AbsensiRecord[]>('absensi', initialAbsensi);
  }

  createAbsensi(item: Omit<AbsensiRecord, 'id'>): AbsensiRecord {
    const list = this.getAbsensi();
    const newItem: AbsensiRecord = {
      ...item,
      id: `abs-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    };
    setStorage('absensi', [newItem, ...list]);
    return newItem;
  }

  saveBatchAbsensi(records: Omit<AbsensiRecord, 'id'>[]): AbsensiRecord[] {
    const currentList = this.getAbsensi();
    const newItems: AbsensiRecord[] = records.map((r, i) => ({
      ...r,
      id: `abs-${Date.now()}-${i}`,
    }));
    // Remove duplicates for same santri, date, and sesi
    const recordKeys = new Set(newItems.map(r => `${r.santriId}_${r.tanggal}_${r.sesi}`));
    const filteredCurrent = currentList.filter(r => !recordKeys.has(`${r.santriId}_${r.tanggal}_${r.sesi}`));
    const result = [...newItems, ...filteredCurrent];
    setStorage('absensi', result);
    return newItems;
  }

  deleteAbsensi(id: string): boolean {
    const list = this.getAbsensi();
    const filtered = list.filter(a => a.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('absensi', filtered);
    return true;
  }

  // Nilai & Raport
  getNilai(): NilaiRaport[] {
    return getStorage<NilaiRaport[]>('nilai', initialNilai);
  }

  calculatePredikat(nilaiAkhir: number): NilaiRaport['predikat'] {
    if (nilaiAkhir >= 90) return 'Mumtaz (A)';
    if (nilaiAkhir >= 80) return 'Jayyid Jiddan (B+)';
    if (nilaiAkhir >= 70) return 'Jayyid (B)';
    if (nilaiAkhir >= 60) return 'Maqbul (C)';
    return 'Rasib (D)';
  }

  createNilai(item: Omit<NilaiRaport, 'id' | 'nilaiAkhir' | 'predikat'>): NilaiRaport {
    const list = this.getNilai();
    // Weighted formula: Hafalan (20%), Membaca (25%), Tarkib & I'rob (30%), Pemahaman (15%), Ujian (10%)
    const nilaiAkhir = Math.round(
      item.nilaiHafalan * 0.2 +
      item.nilaiMembaca * 0.25 +
      item.nilaiTarkibIrob * 0.3 +
      item.nilaiMaknaPemahaman * 0.15 +
      item.nilaiUjian * 0.1
    );
    const predikat = this.calculatePredikat(nilaiAkhir);
    const newItem: NilaiRaport = {
      ...item,
      id: `nl-${Date.now()}`,
      nilaiAkhir,
      predikat,
    };
    setStorage('nilai', [newItem, ...list]);
    return newItem;
  }

  updateNilai(id: string, data: Partial<NilaiRaport>): NilaiRaport | null {
    const list = this.getNilai();
    const idx = list.findIndex(n => n.id === id);
    if (idx === -1) return null;
    const current = list[idx];
    const merged = { ...current, ...data };
    const nilaiAkhir = Math.round(
      merged.nilaiHafalan * 0.2 +
      merged.nilaiMembaca * 0.25 +
      merged.nilaiTarkibIrob * 0.3 +
      merged.nilaiMaknaPemahaman * 0.15 +
      merged.nilaiUjian * 0.1
    );
    const predikat = this.calculatePredikat(nilaiAkhir);
    list[idx] = { ...merged, nilaiAkhir, predikat };
    setStorage('nilai', list);
    return list[idx];
  }

  deleteNilai(id: string): boolean {
    const list = this.getNilai();
    const filtered = list.filter(n => n.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('nilai', filtered);
    return true;
  }

  // Jadwal
  getJadwal(): JadwalPelajaran[] {
    return getStorage<JadwalPelajaran[]>('jadwal', initialJadwal);
  }

  createJadwal(item: Omit<JadwalPelajaran, 'id'>): JadwalPelajaran {
    const list = this.getJadwal();
    const newItem: JadwalPelajaran = {
      ...item,
      id: `jdw-${Date.now()}`,
    };
    setStorage('jadwal', [...list, newItem]);
    return newItem;
  }

  updateJadwal(id: string, data: Partial<JadwalPelajaran>): JadwalPelajaran | null {
    const list = this.getJadwal();
    const idx = list.findIndex(j => j.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...data };
    setStorage('jadwal', list);
    return list[idx];
  }

  deleteJadwal(id: string): boolean {
    const list = this.getJadwal();
    const filtered = list.filter(j => j.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('jadwal', filtered);
    return true;
  }

  // Prestasi
  getPrestasi(): PrestasiSantri[] {
    return getStorage<PrestasiSantri[]>('prestasi', initialPrestasi);
  }

  createPrestasi(item: Omit<PrestasiSantri, 'id'>): PrestasiSantri {
    const list = this.getPrestasi();
    const newItem: PrestasiSantri = {
      ...item,
      id: `prs-${Date.now()}`,
    };
    setStorage('prestasi', [newItem, ...list]);
    return newItem;
  }

  updatePrestasi(id: string, data: Partial<PrestasiSantri>): PrestasiSantri | null {
    const list = this.getPrestasi();
    const idx = list.findIndex(p => p.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...data };
    setStorage('prestasi', list);
    return list[idx];
  }

  deletePrestasi(id: string): boolean {
    const list = this.getPrestasi();
    const filtered = list.filter(p => p.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('prestasi', filtered);
    return true;
  }

  // Evaluasi & Monitoring
  getEvaluasi(): EvaluasiMonitoring[] {
    return getStorage<EvaluasiMonitoring[]>('evaluasi', initialEvaluasi);
  }

  createEvaluasi(item: Omit<EvaluasiMonitoring, 'id'>): EvaluasiMonitoring {
    const list = this.getEvaluasi();
    const newItem: EvaluasiMonitoring = {
      ...item,
      id: `evl-${Date.now()}`,
    };
    setStorage('evaluasi', [newItem, ...list]);
    return newItem;
  }

  updateEvaluasi(id: string, data: Partial<EvaluasiMonitoring>): EvaluasiMonitoring | null {
    const list = this.getEvaluasi();
    const idx = list.findIndex(e => e.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...data };
    setStorage('evaluasi', list);
    return list[idx];
  }

  deleteEvaluasi(id: string): boolean {
    const list = this.getEvaluasi();
    const filtered = list.filter(e => e.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('evaluasi', filtered);
    return true;
  }

  // Pengumuman
  getPengumuman(): Pengumuman[] {
    return getStorage<Pengumuman[]>('pengumuman', initialPengumuman);
  }

  createPengumuman(item: Omit<Pengumuman, 'id'>): Pengumuman {
    const list = this.getPengumuman();
    const newItem: Pengumuman = {
      ...item,
      id: `pgm-${Date.now()}`,
    };
    setStorage('pengumuman', [newItem, ...list]);
    return newItem;
  }

  updatePengumuman(id: string, data: Partial<Pengumuman>): Pengumuman | null {
    const list = this.getPengumuman();
    const idx = list.findIndex(p => p.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...data };
    setStorage('pengumuman', list);
    return list[idx];
  }

  deletePengumuman(id: string): boolean {
    const list = this.getPengumuman();
    const filtered = list.filter(p => p.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('pengumuman', filtered);
    return true;
  }

  // Arsip Dokumen
  getDokumen(): ArsipDokumen[] {
    return getStorage<ArsipDokumen[]>('dokumen', initialDokumen);
  }

  createDokumen(item: Omit<ArsipDokumen, 'id'>): ArsipDokumen {
    const list = this.getDokumen();
    const newItem: ArsipDokumen = {
      ...item,
      id: `doc-${Date.now()}`,
    };
    setStorage('dokumen', [newItem, ...list]);
    return newItem;
  }

  deleteDokumen(id: string): boolean {
    const list = this.getDokumen();
    const filtered = list.filter(d => d.id !== id);
    if (filtered.length === list.length) return false;
    setStorage('dokumen', filtered);
    return true;
  }

  // Backup & Restore
  exportDatabaseJSON(): string {
    const data = {
      timestamp: new Date().toISOString(),
      institution: 'Pondok Pesantren Al-Ihsan Jrangoan',
      app: 'AL-WASAIL',
      version: '1.0.0',
      database: {
        lembaga: this.getLembaga(),
        users: this.getUsers(),
        santri: this.getSantri(),
        guru: this.getGuru(),
        kelas: this.getKelas(),
        kitab: this.getKitab(),
        absensi: this.getAbsensi(),
        nilai: this.getNilai(),
        jadwal: this.getJadwal(),
        prestasi: this.getPrestasi(),
        evaluasi: this.getEvaluasi(),
        pengumuman: this.getPengumuman(),
        dokumen: this.getDokumen(),
      },
    };
    return JSON.stringify(data, null, 2);
  }

  importDatabaseJSON(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      const db = parsed.database || parsed;
      if (db.lembaga) setStorage('lembaga', db.lembaga);
      if (db.users) setStorage('users', db.users);
      if (db.santri) setStorage('santri', db.santri);
      if (db.guru) setStorage('guru', db.guru);
      if (db.kelas) setStorage('kelas', db.kelas);
      if (db.kitab) setStorage('kitab', db.kitab);
      if (db.absensi) setStorage('absensi', db.absensi);
      if (db.nilai) setStorage('nilai', db.nilai);
      if (db.jadwal) setStorage('jadwal', db.jadwal);
      if (db.prestasi) setStorage('prestasi', db.prestasi);
      if (db.evaluasi) setStorage('evaluasi', db.evaluasi);
      if (db.pengumuman) setStorage('pengumuman', db.pengumuman);
      if (db.dokumen) setStorage('dokumen', db.dokumen);
      window.dispatchEvent(new CustomEvent('alwasail_db_updated', { detail: { table: 'all' } }));
      return true;
    } catch (err) {
      console.error('Import failed:', err);
      return false;
    }
  }

  resetToDefaultData(): void {
    setStorage('lembaga', initialLembaga);
    setStorage('users', initialUsers);
    setStorage('santri', initialSantri);
    setStorage('guru', initialGuru);
    setStorage('kelas', initialKelas);
    setStorage('kitab', initialKitab);
    setStorage('absensi', initialAbsensi);
    setStorage('nilai', initialNilai);
    setStorage('jadwal', initialJadwal);
    setStorage('prestasi', initialPrestasi);
    setStorage('evaluasi', initialEvaluasi);
    setStorage('pengumuman', initialPengumuman);
    setStorage('dokumen', initialDokumen);
    window.dispatchEvent(new CustomEvent('alwasail_db_updated', { detail: { table: 'all' } }));
  }

  // Generates Supabase DDL SQL Schema with Row Level Security (RLS)
  generateSupabaseSQL(): string {
    return `-- ========================================================
-- SCHEMA DATABASE SUPABASE: AL-WASAIL
-- PONDOK PESANTREN AL-IHSAN JRANGOAN
-- Slogan: Metode Mudah Baca Kitab Kuning
-- ========================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUM TYPES
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('admin', 'guru', 'santri', 'wali');
  CREATE TYPE kehadiran_status AS ENUM ('Hadir', 'Izin', 'Sakit', 'Alfa');
  CREATE TYPE jenjang_tingkat AS ENUM ('Ula', 'Wustha', 'Ulya');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- 3. PROFIL LEMBAGA
CREATE TABLE IF NOT EXISTS lembaga_profil (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nama VARCHAR(100) NOT NULL DEFAULT 'AL-WASAIL',
  nama_lengkap VARCHAR(255) NOT NULL DEFAULT 'Pondok Pesantren Al-Ihsan Jrangoan',
  slogan VARCHAR(255) NOT NULL DEFAULT 'Metode Mudah Baca Kitab Kuning',
  desa VARCHAR(100),
  kecamatan VARCHAR(100),
  kabupaten VARCHAR(100),
  provinsi VARCHAR(100),
  kode_pos VARCHAR(10),
  telepon VARCHAR(50),
  email VARCHAR(100),
  pengasuh VARCHAR(150),
  ketua_pengurus VARCHAR(150),
  visi TEXT,
  misi JSONB,
  deskripsi_metode TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 4. PROFILES & ROLE BASED ACCESS CONTROL (RBAC)
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username VARCHAR(100) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role user_role NOT NULL DEFAULT 'santri',
  email VARCHAR(255),
  phone VARCHAR(50),
  santri_id UUID,
  guru_id UUID,
  status VARCHAR(20) DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 5. DATA GURU / ASATIDZ
CREATE TABLE IF NOT EXISTS guru (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nip VARCHAR(50) UNIQUE NOT NULL,
  nama_lengkap VARCHAR(255) NOT NULL,
  gelar VARCHAR(50),
  spesialisasi_kitab VARCHAR(255),
  no_hp VARCHAR(50),
  email VARCHAR(150),
  alamat TEXT,
  kelas_ampu TEXT[],
  status_keaktifan VARCHAR(30) DEFAULT 'Aktif',
  tanggal_mulai_tugas DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 6. DATA KELAS
CREATE TABLE IF NOT EXISTS kelas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  kode_kelas VARCHAR(50) UNIQUE NOT NULL,
  nama_kelas VARCHAR(150) NOT NULL,
  jenjang jenjang_tingkat NOT NULL,
  wali_kelas_id UUID REFERENCES guru(id) ON DELETE SET NULL,
  ruangan VARCHAR(100),
  target_capaian TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 7. DATA SANTRI
CREATE TABLE IF NOT EXISTS santri (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nis VARCHAR(50) UNIQUE NOT NULL,
  nisn VARCHAR(50),
  nama_lengkap VARCHAR(255) NOT NULL,
  nama_panggilan VARCHAR(100),
  jenis_kelamin VARCHAR(5) CHECK (jenis_kelamin IN ('L', 'P')),
  tempat_lahir VARCHAR(100),
  tanggal_lahir DATE,
  jenjang jenjang_tingkat NOT NULL,
  kelas_id UUID REFERENCES kelas(id) ON DELETE SET NULL,
  asrama VARCHAR(100),
  kamar VARCHAR(100),
  nama_wali VARCHAR(255),
  no_hp_wali VARCHAR(50),
  alamat TEXT,
  tahun_masuk INT DEFAULT 2024,
  status VARCHAR(20) DEFAULT 'Aktif',
  level_baca_kitab INT CHECK (level_baca_kitab BETWEEN 1 AND 5),
  catatan_metode_alwasail TEXT,
  target_kitab VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 8. DATA KITAB KUNING & KURIKULUM
CREATE TABLE IF NOT EXISTS kitab_kuning (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  kode_kitab VARCHAR(50) UNIQUE NOT NULL,
  nama_kitab VARCHAR(255) NOT NULL,
  nama_kitab_arab VARCHAR(255),
  pengarang VARCHAR(255),
  fan_ilmu VARCHAR(100),
  jenjang jenjang_tingkat NOT NULL,
  target_bab TEXT,
  fase_metode_alwasail VARCHAR(255),
  deskripsi TEXT,
  total_bait_fasal INT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 9. ABSENSI SANTRI
CREATE TABLE IF NOT EXISTS absensi (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  santri_id UUID REFERENCES santri(id) ON DELETE CASCADE,
  kelas_id UUID REFERENCES kelas(id) ON DELETE CASCADE,
  tanggal DATE NOT NULL DEFAULT CURRENT_DATE,
  status kehadiran_status NOT NULL,
  keterangan TEXT,
  guru_id UUID REFERENCES guru(id) ON DELETE SET NULL,
  sesi VARCHAR(100) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 10. PENILAIAN & RAPORT
CREATE TABLE IF NOT EXISTS nilai_raport (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  santri_id UUID REFERENCES santri(id) ON DELETE CASCADE,
  kelas_id UUID REFERENCES kelas(id) ON DELETE CASCADE,
  kitab_id UUID REFERENCES kitab_kuning(id) ON DELETE CASCADE,
  semester VARCHAR(20) NOT NULL,
  tahun_ajaran VARCHAR(50) NOT NULL,
  nilai_hafalan NUMERIC(5,2),
  nilai_membaca NUMERIC(5,2),
  nilai_tarkib_irob NUMERIC(5,2),
  nilai_makna_pemahaman NUMERIC(5,2),
  nilai_ujian NUMERIC(5,2),
  nilai_akhir NUMERIC(5,2),
  predikat VARCHAR(50),
  catatan_ustadz TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 11. JADWAL PELAJARAN
CREATE TABLE IF NOT EXISTS jadwal_pelajaran (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  hari VARCHAR(20) NOT NULL,
  jam_mulai TIME NOT NULL,
  jam_selesai TIME NOT NULL,
  kelas_id UUID REFERENCES kelas(id) ON DELETE CASCADE,
  kitab_id UUID REFERENCES kitab_kuning(id) ON DELETE CASCADE,
  guru_id UUID REFERENCES guru(id) ON DELETE CASCADE,
  ruangan VARCHAR(100),
  sesi VARCHAR(100),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 12. PRESTASI SANTRI
CREATE TABLE IF NOT EXISTS prestasi_santri (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  santri_id UUID REFERENCES santri(id) ON DELETE CASCADE,
  nama_event VARCHAR(255) NOT NULL,
  kategori VARCHAR(100) NOT NULL,
  tingkat VARCHAR(100) NOT NULL,
  juara VARCHAR(100) NOT NULL,
  tahun INT NOT NULL,
  penyelenggara VARCHAR(255),
  deskripsi TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 13. EVALUASI DAN MONITORING METODE AL-WASAIL
CREATE TABLE IF NOT EXISTS evaluasi_monitoring (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  santri_id UUID REFERENCES santri(id) ON DELETE CASCADE,
  kelas_id UUID REFERENCES kelas(id) ON DELETE CASCADE,
  tanggal DATE DEFAULT CURRENT_DATE,
  level_alwasail INT CHECK (level_alwasail BETWEEN 1 AND 5),
  capaian_bab VARCHAR(255),
  kelancaran_baca VARCHAR(100),
  penguasaan_nahwu_shorof VARCHAR(100),
  catatan_pembimbing TEXT,
  rekomendasi_tindak_lanjut TEXT,
  evaluator_id UUID REFERENCES guru(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 14. PENGUMUMAN & INFORMASI
CREATE TABLE IF NOT EXISTS pengumuman (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  judul VARCHAR(255) NOT NULL,
  konten TEXT NOT NULL,
  tanggal DATE DEFAULT CURRENT_DATE,
  penulis VARCHAR(150),
  target_audience VARCHAR(50) DEFAULT 'Semua',
  kategori VARCHAR(50) DEFAULT 'Akademik',
  is_pinned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 15. ARSIP DOKUMEN
CREATE TABLE IF NOT EXISTS arsip_dokumen (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  judul VARCHAR(255) NOT NULL,
  nomor_surat VARCHAR(100),
  kategori VARCHAR(100) NOT NULL,
  ukuran VARCHAR(50),
  tanggal_unggah DATE DEFAULT CURRENT_DATE,
  pengunggah VARCHAR(150),
  ekstensi VARCHAR(20),
  deskripsi TEXT,
  url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- ========================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ========================================================
ALTER TABLE santri ENABLE ROW LEVEL SECURITY;
ALTER TABLE guru ENABLE ROW LEVEL SECURITY;
ALTER TABLE absensi ENABLE ROW LEVEL SECURITY;
ALTER TABLE nilai_raport ENABLE ROW LEVEL SECURITY;
ALTER TABLE evaluasi_monitoring ENABLE ROW LEVEL SECURITY;
ALTER TABLE pengumuman ENABLE ROW LEVEL SECURITY;

-- Helper Function to check role
CREATE OR REPLACE FUNCTION get_user_role() RETURNS user_role AS $$
  SELECT role FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER;

-- Policy: Admin full access
CREATE POLICY "Admin All Access" ON santri FOR ALL USING (get_user_role() = 'admin');
CREATE POLICY "Admin All Access Absensi" ON absensi FOR ALL USING (get_user_role() = 'admin');
CREATE POLICY "Admin All Access Nilai" ON nilai_raport FOR ALL USING (get_user_role() = 'admin');

-- Policy: Guru can read all santri and insert/update absensi & nilai
CREATE POLICY "Guru View Santri" ON santri FOR SELECT USING (get_user_role() IN ('admin', 'guru'));
CREATE POLICY "Guru Manage Absensi" ON absensi FOR ALL USING (get_user_role() IN ('admin', 'guru'));
CREATE POLICY "Guru Manage Nilai" ON nilai_raport FOR ALL USING (get_user_role() IN ('admin', 'guru'));

-- Policy: Santri & Wali view own records
CREATE POLICY "Santri View Own" ON santri FOR SELECT USING (
  id IN (SELECT santri_id FROM profiles WHERE id = auth.uid())
);
CREATE POLICY "Santri View Own Absensi" ON absensi FOR SELECT USING (
  santri_id IN (SELECT santri_id FROM profiles WHERE id = auth.uid())
);
CREATE POLICY "Santri View Own Nilai" ON nilai_raport FOR SELECT USING (
  santri_id IN (SELECT santri_id FROM profiles WHERE id = auth.uid())
);

-- Policy: Public read for pengumuman
CREATE POLICY "Read Pengumuman" ON pengumuman FOR SELECT USING (true);
`;
  }
}

export const db = new DatabaseService();
