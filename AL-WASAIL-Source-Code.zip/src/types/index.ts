export type UserRole = 'admin' | 'guru' | 'santri' | 'wali';

export interface UserAccount {
  id: string;
  username: string;
  fullName: string;
  role: UserRole;
  email: string;
  phone: string;
  avatarUrl?: string;
  santriId?: string; // If role is santri or wali
  guruId?: string;   // If role is guru
  status: 'active' | 'inactive';
  lastLogin?: string;
}

export interface Santri {
  id: string;
  nis: string;
  nisn: string;
  namaLengkap: string;
  namaPanggilan: string;
  jenisKelamin: 'L' | 'P';
  tempatLahir: string;
  tanggalLahir: string;
  jenjang: 'Ula' | 'Wustha' | 'Ulya';
  kelasId: string;
  namaKelas: string;
  asrama: string;
  kamar: string;
  namaWali: string;
  noHpWali: string;
  alamat: string;
  tahunMasuk: number;
  status: 'Aktif' | 'Alumni' | 'Cuti';
  levelBacaKitab: number; // 1: Dasar Tarkib, 2: Baca Berharokat, 3: I'rob Dasar, 4: Baca Kosongan, 5: Mahir Mandiri
  catatanMetodeAlWasail: string;
  targetKitab: string;
  fotoUrl?: string;
}

export interface Guru {
  id: string;
  nip: string;
  namaLengkap: string;
  gelar: string;
  spesialisasiKitab: string;
  noHp: string;
  email: string;
  alamat: string;
  kelasAmpu: string[]; // nama kelas
  statusKeaktifan: 'Aktif' | 'Cuti' | 'Purna';
  tanggalMulaiTugas: string;
  fotoUrl?: string;
}

export interface Kelas {
  id: string;
  kodeKelas: string;
  namaKelas: string;
  jenjang: 'Ula' | 'Wustha' | 'Ulya';
  waliKelasId: string;
  waliKelasNama: string;
  jumlahSantri: number;
  ruangan: string;
  targetCapaian: string;
}

export interface KitabKuning {
  id: string;
  kodeKitab: string;
  namaKitab: string;
  namaKitabArab: string;
  pengarang: string;
  fanIlmu: 'Nahwu' | 'Shorof' | 'Fiqih' | 'Aqidah' | 'Akhlak' | 'Hadits' | 'Tafsir';
  jenjang: 'Ula' | 'Wustha' | 'Ulya';
  targetBab: string;
  faseMetodeAlWasail: string;
  deskripsi: string;
  totalBaitAtauFasal: number;
}

export type StatusKehadiran = 'Hadir' | 'Izin' | 'Sakit' | 'Alfa';

export interface AbsensiRecord {
  id: string;
  santriId: string;
  santriNama: string;
  kelasId: string;
  namaKelas: string;
  tanggal: string; // YYYY-MM-DD
  status: StatusKehadiran;
  keterangan: string;
  guruId: string;
  guruNama: string;
  sesi: 'Pagi (Pengajian Kitab)' | 'Siang (Madrasah)' | 'Sore (Sorogan)' | 'Malam (Musyawarah)';
}

export interface NilaiRaport {
  id: string;
  santriId: string;
  santriNama: string;
  kelasId: string;
  namaKelas: string;
  semester: 'Ganjil' | 'Genap';
  tahunAjaran: string;
  kitabId: string;
  namaKitab: string;
  nilaiHafalan: number;        // 0-100
  nilaiMembaca: number;        // 0-100 (Fasahah & Kelancaran)
  nilaiTarkibIrob: number;     // 0-100 (Analisis Gramatikal Al-Wasail)
  nilaiMaknaPemahaman: number; // 0-100 (Murad & Kontekstual)
  nilaiUjian: number;          // 0-100 (Ikhtibar Akhir)
  nilaiAkhir: number;          // Rata-rata bobot
  predikat: 'Mumtaz (A)' | 'Jayyid Jiddan (B+)' | 'Jayyid (B)' | 'Maqbul (C)' | 'Rasib (D)';
  catatanUstadz: string;
}

export interface JadwalPelajaran {
  id: string;
  hari: 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat' | 'Sabtu' | 'Ahad';
  jamMulai: string;
  jamSelesai: string;
  kelasId: string;
  namaKelas: string;
  kitabId: string;
  namaKitab: string;
  guruId: string;
  guruNama: string;
  ruangan: string;
  sesi: string;
}

export interface PrestasiSantri {
  id: string;
  santriId: string;
  santriNama: string;
  namaEvent: string;
  kategori: 'MQK (Musabaqah Qiraatil Kutub)' | 'Tahfidz Al-Quran' | 'Pidato Bahasa Arab' | 'Cerdas Cermat Nahwu Shorof' | 'Karya Ilmiah Santri';
  tingkat: 'Pesantren' | 'Kabupaten/Kota' | 'Provinsi' | 'Nasional';
  juara: 'Juara 1' | 'Juara 2' | 'Juara 3' | 'Harapan 1' | 'Juara Favorit';
  tahun: number;
  penyelenggara: string;
  deskripsi: string;
  piagamUrl?: string;
}

export interface EvaluasiMonitoring {
  id: string;
  santriId: string;
  santriNama: string;
  kelasId: string;
  namaKelas: string;
  tanggal: string;
  levelAlWasail: number; // 1-5
  capaianBab: string;
  kelancaranBaca: 'Sangat Lancar' | 'Lancar' | 'Kurang Lancar' | 'Perlu Bimbingan Khusus';
  penguasaanNahwuShorof: 'Mumtaz (Sangat Baik)' | 'Jayyid (Baik)' | 'Cukup' | 'Kurang';
  catatanPembimbing: string;
  rekomendasiTindakLanjut: string;
  evaluatorId: string;
  evaluatorNama: string;
}

export interface Pengumuman {
  id: string;
  judul: string;
  konten: string;
  tanggal: string;
  penulis: string;
  targetAudience: 'Semua' | 'Santri' | 'Guru' | 'Wali Santri';
  kategori: 'Akademik' | 'Kegiatan' | 'Ujian Kitab' | 'Libur Pondok' | 'Penting';
  isPinned: boolean;
}

export interface ArsipDokumen {
  id: string;
  judul: string;
  nomorSurat: string;
  kategori: 'Kurikulum Al-Wasail' | 'Panduan Guru' | 'SK Pengurus' | 'Kalender Akademik' | 'Buku Pedoman' | 'Formulir' | 'Laporan Raport';
  ukuran: string;
  tanggalUnggah: string;
  pengunggah: string;
  ekstensi: 'PDF' | 'DOCX' | 'XLSX';
  deskripsi: string;
  downloadUrl?: string;
}

export interface LembagaProfil {
  nama: string;
  namaLengkap: string;
  slogan: string;
  desa: string;
  kecamatan: string;
  kabupaten: string;
  provinsi: string;
  kodePos: string;
  telepon: string;
  email: string;
  website: string;
  pengasuh: string;
  ketuaPengurus: string;
  tahunBerdiri: number;
  nspp: string; // Nomor Statistik Pondok Pesantren
  visi: string;
  misi: string[];
  deskripsiMetode: string;
  logoUrl: string;
  bannerUrl: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
  autoSync: boolean;
  lastSyncedAt?: string;
}
