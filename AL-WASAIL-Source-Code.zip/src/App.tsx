/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SplashScreen } from './components/common/SplashScreen';
import { Header } from './components/common/Header';
import { Sidebar, MENU_ITEMS } from './components/common/Sidebar';
import { MobileNav } from './components/common/MobileNav';
import { InstitutionalProfileModal } from './components/common/InstitutionalProfileModal';
import { ApkBuildModal } from './components/common/ApkBuildModal';
import { LoginView } from './views/LoginView';
import { DashboardView } from './views/DashboardView';
import { SantriView } from './views/SantriView';
import { GuruView } from './views/GuruView';
import { AkademikView } from './views/AkademikView';
import { AbsensiView } from './views/AbsensiView';
import { PenilaianRaportView } from './views/PenilaianRaportView';
import { JadwalView } from './views/JadwalView';
import { PrestasiView } from './views/PrestasiView';
import { EvaluasiView } from './views/EvaluasiView';
import { PengumumanView } from './views/PengumumanView';
import { ArsipDokumenView } from './views/ArsipDokumenView';
import { PengaturanView } from './views/PengaturanView';

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [showSplash, setShowSplash] = useState(true);
  const [activeMenu, setActiveMenu] = useState('dashboard');
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  if (!isAuthenticated) {
    return (
      <>
        <LoginView
          onSuccess={() => setActiveMenu('dashboard')}
          onOpenProfile={() => setIsProfileModalOpen(true)}
        />
        <InstitutionalProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
        />
      </>
    );
  }

  const currentMenuItem = MENU_ITEMS.find((m) => m.id === activeMenu);
  const currentTitle = currentMenuItem ? currentMenuItem.label : 'Dashboard';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row text-slate-800">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block shrink-0">
        <Sidebar
          activeMenu={activeMenu}
          onSelectMenu={(menuId) => setActiveMenu(menuId)}
          onOpenProfile={() => setIsProfileModalOpen(true)}
        />
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 pb-20 lg:pb-8">
        <Header
          onToggleMobileMenu={() => setIsMobileDrawerOpen((prev) => !prev)}
          onOpenProfile={() => setIsProfileModalOpen(true)}
          onOpenApkModal={() => setIsApkModalOpen(true)}
          currentMenuTitle={currentTitle}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeMenu === 'dashboard' && (
            <DashboardView
              onNavigate={(menuId) => setActiveMenu(menuId)}
              onOpenProfile={() => setIsProfileModalOpen(true)}
              onOpenApkModal={() => setIsApkModalOpen(true)}
            />
          )}

          {activeMenu === 'santri' && <SantriView />}
          {activeMenu === 'guru' && <GuruView />}
          {activeMenu === 'akademik' && <AkademikView />}
          {activeMenu === 'absensi' && <AbsensiView />}
          {activeMenu === 'nilai' && <PenilaianRaportView />}
          {activeMenu === 'jadwal' && <JadwalView />}
          {activeMenu === 'prestasi' && <PrestasiView />}
          {activeMenu === 'evaluasi' && <EvaluasiView />}
          {activeMenu === 'pengumuman' && <PengumumanView />}
          {activeMenu === 'dokumen' && <ArsipDokumenView />}
          {activeMenu === 'pengaturan' && (
            <PengaturanView onOpenApkModal={() => setIsApkModalOpen(true)} />
          )}
        </main>
      </div>

      {/* Mobile Navigation Bar & Drawer */}
      <MobileNav
        activeMenu={activeMenu}
        onSelectMenu={(menuId) => {
          if (menuId === '__OPEN_DRAWER__') {
            setIsMobileDrawerOpen(true);
          } else {
            setActiveMenu(menuId);
            setIsMobileDrawerOpen(false);
          }
        }}
        isDrawerOpen={isMobileDrawerOpen}
        onCloseDrawer={() => setIsMobileDrawerOpen(false)}
        onOpenProfile={() => setIsProfileModalOpen(true)}
      />

      {/* Modals */}
      <InstitutionalProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />

      <ApkBuildModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
