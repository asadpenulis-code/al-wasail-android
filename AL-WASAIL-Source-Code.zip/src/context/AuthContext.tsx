import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserAccount, UserRole } from '../types';
import { db } from '../services/db';

interface AuthContextType {
  currentUser: UserAccount | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  login: (username: string, password?: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  switchRole: (role: UserRole) => void;
  hasPermission: (allowedRoles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_STORAGE_KEY = 'alwasail_current_user_id';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);

  useEffect(() => {
    // Restore session
    const savedUserId = localStorage.getItem(AUTH_STORAGE_KEY);
    const users = db.getUsers();
    if (savedUserId) {
      const found = users.find(u => u.id === savedUserId);
      if (found) {
        setCurrentUser(found);
        return;
      }
    }
    // Default to admin for seamless first load
    const defaultAdmin = users.find(u => u.role === 'admin') || users[0];
    if (defaultAdmin) {
      setCurrentUser(defaultAdmin);
      localStorage.setItem(AUTH_STORAGE_KEY, defaultAdmin.id);
    }
  }, []);

  const login = async (username: string, _password?: string): Promise<{ success: boolean; message?: string }> => {
    const users = db.getUsers();
    const cleanUsername = username.trim().toLowerCase();
    const found = users.find(
      u => u.username.toLowerCase() === cleanUsername || u.email.toLowerCase() === cleanUsername
    );

    if (!found) {
      return { success: false, message: 'Nama pengguna atau email tidak ditemukan.' };
    }

    if (found.status === 'inactive') {
      return { success: false, message: 'Akun Anda sedang dinonaktifkan oleh Pengurus.' };
    }

    // Update last login
    db.updateUser(found.id, { lastLogin: new Date().toLocaleString('id-ID') + ' WIB' });
    setCurrentUser(found);
    localStorage.setItem(AUTH_STORAGE_KEY, found.id);
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem(AUTH_STORAGE_KEY);
  };

  const switchRole = (newRole: UserRole) => {
    const users = db.getUsers();
    const targetUser = users.find(u => u.role === newRole) || users[0];
    if (targetUser) {
      setCurrentUser(targetUser);
      localStorage.setItem(AUTH_STORAGE_KEY, targetUser.id);
    }
  };

  const hasPermission = (allowedRoles: UserRole[]): boolean => {
    if (!currentUser) return false;
    return allowedRoles.includes(currentUser.role);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role: currentUser?.role || null,
        isAuthenticated: !!currentUser,
        login,
        logout,
        switchRole,
        hasPermission,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
