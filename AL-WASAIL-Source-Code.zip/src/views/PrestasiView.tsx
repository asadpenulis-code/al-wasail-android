import React, { useState } from 'react';
import {
  Trophy,
  Award,
  Plus,
  Edit2,
  Trash2,
  Sparkles,
  PartyPopper,
  Search,
  Filter,
  X,
  Calendar,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { PrestasiSantri } from '../types';

export const PrestasiView: React.FC = () => {
  const { role } = useAuth();
  const [prestasiList, setPrestasiList] = useState<PrestasiSantri[]>(() => db.getPrestasi());
  const santriList = db.getSantri();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterTingkat, setFilterTingkat] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPrestasi, setEditingPrestasi] = useState<PrestasiSantri | null>(null);

  const [formData, setFormData] = useState<Omit<PrestasiSantri, 'id'>>({
    santriId: santriList[0]?.id || '',
    santriNama: santriList[0]?.namaLengkap || '',
    namaEvent: '',
    kategori: 'MQK (Musabaqah Qiraatil Kutub)',
    tingkat: 'Kabupaten/Kota',
    juara: 'Juara 1',
    tahun: 2026,
    penyelenggara: 'Kementerian Agama',
    deskripsi: '',
  });

  const refreshList = () => setPrestasiList(db.getPrestasi());
  const canEdit = role === 'admin' || role === 'guru';

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#0284c7', '#38bdf8', '#f59e0b', '#10b981'],
    });
  };

  const handleOpenAdd = () => {
    setEditingPrestasi(null);
    const firstSantri = santriList[0];
    setFormData({
      santriId: firstSantri?.id || '',
      santriNama: firstSantri?.namaLengkap || '',
      namaEvent: '',
      kategori: 'MQK (Musabaqah Qiraatil Kutub)',
      tingkat: 'Kabupaten/Kota',
      juara: 'Juara 1',
      tahun: 2026,
      penyelenggara: 'Forum Musabaqah Kitab Kuning Madura',
      deskripsi: 'Berhasil membaca kitab kosongan dengan ketepatan tarkib dan i\'rob sempurna.',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: PrestasiSantri) => {
    setEditingPrestasi(p);
    setFormData({
      santriId: p.santriId,
      santriNama: p.santriNama,
      namaEvent: p.namaEvent,
      kategori: p.kategori,
      tingkat: p.tingkat,
      juara: p.juara,
      tahun: p.tahun,
      penyelenggara: p.penyelenggara,
      deskripsi: p.deskripsi,
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const st = santriList.find((s) => s.id === formData.santriId);
    const completeData = {
      ...formData,
      santriNama: st ? st.namaLengkap : formData.santriNama,
    };

    if (editingPrestasi) {
      db.updatePrestasi(editingPrestasi.id, completeData);
    } else {
      db.createPrestasi(completeData);
      triggerConfetti();
    }
    refreshList();
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, namaEvent: string) => {
    if (confirm(`Hapus catatan prestasi "${namaEvent}"?`)) {
      db.deletePrestasi(id);
      refreshList();
    }
  };

  const filteredPrestasi = prestasiList.filter((p) => {
    const matchSearch =
      p.santriNama.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.namaEvent.toLowerCase().includes(searchQuery.toLowerCase());
    const matchTingkat = filterTingkat === 'all' || p.tingkat === filterTingkat;
    return matchSearch && matchTingkat;
  });

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-500" />
            <span>Prestasi Santri PP Al-Ihsan Jrangoan</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Rekam jejak kejuaraan baca kitab kuning (MQK), tahfidz, cerdas cermat, dan musabaqah ilmiah
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={triggerConfetti}
            className="px-3.5 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Rayakan Capaian Santri"
          >
            <PartyPopper className="w-4 h-4 text-amber-600" />
            <span>Selebrasi Juara</span>
          </button>

          {canEdit && (
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Prestasi</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari prestasi berdasarkan nama santri atau event lomba..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800"
          />
        </div>

        <select
          value={filterTingkat}
          onChange={(e) => setFilterTingkat(e.target.value)}
          className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 shrink-0 w-full sm:w-auto"
        >
          <option value="all">Semua Tingkatan</option>
          <option value="Pesantren">Tingkat Pesantren</option>
          <option value="Kabupaten/Kota">Tingkat Kabupaten/Kota</option>
          <option value="Provinsi">Tingkat Provinsi</option>
          <option value="Nasional">Tingkat Nasional</option>
        </select>
      </div>

      {/* Prestasi Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPrestasi.map((p) => (
          <div
            key={p.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-amber-300 transition-all p-5 flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 shrink-0">
                    <Trophy className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wide">
                      {p.tingkat} · {p.tahun}
                    </span>
                    <h3 className="text-sm font-extrabold text-slate-900">{p.juara}</h3>
                  </div>
                </div>

                {canEdit && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(p)}
                      className="p-1 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(p.id, p.namaEvent)}
                      className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-3">
                <span className="text-xs font-bold text-slate-800 block">{p.namaEvent}</span>
                <span className="text-[11px] text-sky-700 font-semibold block mt-0.5">{p.kategori}</span>
              </div>

              <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1 text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block">Santri Peraih Juara:</span>
                  <span className="font-bold text-slate-900">{p.santriNama}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Penyelenggara:</span>
                  <span className="text-slate-700">{p.penyelenggara}</span>
                </div>
                <p className="text-[11px] text-slate-500 italic pt-1 border-t border-slate-200">
                  "{p.deskripsi}"
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Pondok Pesantren Al-Ihsan</span>
              <button
                onClick={triggerConfetti}
                className="text-amber-600 font-bold hover:underline flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3" />
                <span>Beri Apresiasi</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingPrestasi ? 'Edit Prestasi Santri' : 'Catat Prestasi Baru'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Santri Berprestasi *</label>
                <select
                  value={formData.santriId}
                  onChange={(e) => setFormData({ ...formData, santriId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {santriList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.namaLengkap} ({s.nis} - {s.namaKelas})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Musabaqah / Perlombaan *</label>
                <input
                  type="text"
                  required
                  value={formData.namaEvent}
                  onChange={(e) => setFormData({ ...formData, namaEvent: e.target.value })}
                  placeholder="Contoh: Musabaqah Qira'atil Kutub (MQK) Jawa Timur"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kategori Cabang</label>
                  <select
                    value={formData.kategori}
                    onChange={(e) => setFormData({ ...formData, kategori: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="MQK (Musabaqah Qiraatil Kutub)">MQK (Baca Kitab Kuning)</option>
                    <option value="Tahfidz Al-Quran">Tahfidz Al-Quran</option>
                    <option value="Pidato Bahasa Arab">Pidato Bahasa Arab</option>
                    <option value="Cerdas Cermat Nahwu Shorof">Cerdas Cermat Nahwu</option>
                    <option value="Karya Ilmiah Santri">Karya Ilmiah Santri</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tingkat Penyelenggaraan</label>
                  <select
                    value={formData.tingkat}
                    onChange={(e) => setFormData({ ...formData, tingkat: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Pesantren">Tingkat Pesantren</option>
                    <option value="Kabupaten/Kota">Tingkat Kabupaten/Kota</option>
                    <option value="Provinsi">Tingkat Provinsi</option>
                    <option value="Nasional">Tingkat Nasional</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Peringkat / Juara *</label>
                  <select
                    value={formData.juara}
                    onChange={(e) => setFormData({ ...formData, juara: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Juara 1">Juara 1</option>
                    <option value="Juara 2">Juara 2</option>
                    <option value="Juara 3">Juara 3</option>
                    <option value="Harapan 1">Harapan 1</option>
                    <option value="Juara Favorit">Juara Favorit</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tahun Kejuaraan</label>
                  <input
                    type="number"
                    value={formData.tahun}
                    onChange={(e) => setFormData({ ...formData, tahun: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Instansi Penyelenggara</label>
                <input
                  type="text"
                  value={formData.penyelenggara}
                  onChange={(e) => setFormData({ ...formData, penyelenggara: e.target.value })}
                  placeholder="Contoh: Kemenag Sampang / RMI PBNU"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Deskripsi Catatan Prestasi</label>
                <textarea
                  rows={2}
                  value={formData.deskripsi}
                  onChange={(e) => setFormData({ ...formData, deskripsi: e.target.value })}
                  placeholder="Rincian kitab yang diujikan, nilai pembacaan kosongan..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Simpan Prestasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
