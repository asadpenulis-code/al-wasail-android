import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Plus,
  Edit2,
  Trash2,
  MapPin,
  GraduationCap,
  BookOpen,
  Filter,
  X,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { JadwalPelajaran } from '../types';

export const JadwalView: React.FC = () => {
  const { role } = useAuth();
  const [jadwalList, setJadwalList] = useState<JadwalPelajaran[]>(() => db.getJadwal());
  const kelasList = db.getKelas();
  const kitabList = db.getKitab();
  const guruList = db.getGuru();

  const [selectedHari, setSelectedHari] = useState<string>('all');
  const [selectedKelas, setSelectedKelas] = useState<string>('all');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingJadwal, setEditingJadwal] = useState<JadwalPelajaran | null>(null);

  const [formData, setFormData] = useState<Omit<JadwalPelajaran, 'id'>>({
    hari: 'Senin',
    jamMulai: '05:30',
    jamSelesai: '07:00',
    kelasId: kelasList[0]?.id || '',
    namaKelas: kelasList[0]?.namaKelas || '',
    kitabId: kitabList[0]?.id || '',
    namaKitab: kitabList[0]?.namaKitab || '',
    guruId: guruList[0]?.id || '',
    guruNama: guruList[0]?.namaLengkap || '',
    ruangan: 'Gedung Al-Wasail Lt. 1 Ruang 101',
    sesi: 'Pagi (Pengajian Kitab)',
  });

  const refreshList = () => setJadwalList(db.getJadwal());
  const canEdit = role === 'admin';

  const hariOptions: JadwalPelajaran['hari'][] = [
    'Senin',
    'Selasa',
    'Rabu',
    'Kamis',
    'Jumat',
    'Sabtu',
    'Ahad',
  ];

  const handleOpenAdd = () => {
    setEditingJadwal(null);
    const k = kelasList[0];
    const kt = kitabList[0];
    const g = guruList[0];
    setFormData({
      hari: 'Senin',
      jamMulai: '05:30',
      jamSelesai: '07:00',
      kelasId: k?.id || '',
      namaKelas: k?.namaKelas || '',
      kitabId: kt?.id || '',
      namaKitab: kt?.namaKitab || '',
      guruId: g?.id || '',
      guruNama: g ? `${g.namaLengkap}, ${g.gelar}` : '',
      ruangan: 'Gedung Al-Wasail Lt. 1 Ruang 101',
      sesi: 'Pagi (Pengajian Kitab)',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (j: JadwalPelajaran) => {
    setEditingJadwal(j);
    setFormData({
      hari: j.hari,
      jamMulai: j.jamMulai,
      jamSelesai: j.jamSelesai,
      kelasId: j.kelasId,
      namaKelas: j.namaKelas,
      kitabId: j.kitabId,
      namaKitab: j.namaKitab,
      guruId: j.guruId,
      guruNama: j.guruNama,
      ruangan: j.ruangan,
      sesi: j.sesi,
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const k = kelasList.find((x) => x.id === formData.kelasId);
    const kt = kitabList.find((x) => x.id === formData.kitabId);
    const g = guruList.find((x) => x.id === formData.guruId);

    const completeData = {
      ...formData,
      namaKelas: k ? k.namaKelas : formData.namaKelas,
      namaKitab: kt ? kt.namaKitab : formData.namaKitab,
      guruNama: g ? `${g.namaLengkap}, ${g.gelar}` : formData.guruNama,
    };

    if (editingJadwal) {
      db.updateJadwal(editingJadwal.id, completeData);
    } else {
      db.createJadwal(completeData);
    }
    refreshList();
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, namaKitab: string) => {
    if (confirm(`Hapus jadwal pengajian "${namaKitab}"?`)) {
      db.deleteJadwal(id);
      refreshList();
    }
  };

  const filteredJadwal = jadwalList.filter((j) => {
    const matchHari = selectedHari === 'all' || j.hari === selectedHari;
    const matchKelas = selectedKelas === 'all' || j.kelasId === selectedKelas;
    return matchHari && matchKelas;
  });

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-sky-600" />
            <span>Jadwal Pengajian & Pelajaran Kitab</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Jadwal mingguan pengajian wetonan, sorogan Metode Al-Wasail, dan musyawarah malam
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Jadwal</span>
          </button>
        )}
      </div>

      {/* Filter Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1.5">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-bold text-slate-700">Filter Hari:</span>
        </div>

        <div className="flex flex-wrap items-center gap-1">
          <button
            onClick={() => setSelectedHari('all')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
              selectedHari === 'all' ? 'bg-sky-600 text-white shadow-2xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Semua Hari
          </button>
          {hariOptions.map((h) => (
            <button
              key={h}
              onClick={() => setSelectedHari(h)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                selectedHari === h ? 'bg-sky-600 text-white shadow-2xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {h}
            </button>
          ))}
        </div>

        <div className="ml-auto">
          <select
            value={selectedKelas}
            onChange={(e) => setSelectedKelas(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-1.5 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
          >
            <option value="all">Semua Rombel Kelas</option>
            {kelasList.map((k) => (
              <option key={k.id} value={k.id}>
                {k.namaKelas}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Jadwal Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredJadwal.length === 0 ? (
          <div className="col-span-full p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-xs">
            Tidak ada jadwal pengajian pada hari atau kelas yang dipilih.
          </div>
        ) : (
          filteredJadwal.map((j) => (
            <div
              key={j.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 transition-all p-5 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-sky-600 text-white font-bold text-xs">
                      {j.hari}
                    </span>
                    <span className="text-xs font-mono font-semibold text-slate-700 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-sky-600" />
                      <span>{j.jamMulai} - {j.jamSelesai} WIB</span>
                    </span>
                  </div>

                  {canEdit && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(j)}
                        className="p-1 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(j.id, j.namaKitab)}
                        className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="mt-3">
                  <span className="text-[10px] font-bold text-sky-700 uppercase">{j.sesi}</span>
                  <h3 className="text-sm font-bold text-slate-900 mt-0.5">{j.namaKitab}</h3>
                  <span className="text-xs text-slate-500 block">{j.namaKelas}</span>
                </div>

                <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                  <div className="flex items-center gap-2 text-slate-700 font-medium">
                    <GraduationCap className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                    <span>{j.guruNama}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{j.ruangan}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>PP Al-Ihsan Jrangoan</span>
                <span className="text-sky-700 font-semibold">Al-Wasail System</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingJadwal ? 'Edit Jadwal Pengajian' : 'Tambah Jadwal Pengajian'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Hari *</label>
                  <select
                    value={formData.hari}
                    onChange={(e) => setFormData({ ...formData, hari: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {hariOptions.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jam Mulai</label>
                  <input
                    type="time"
                    required
                    value={formData.jamMulai}
                    onChange={(e) => setFormData({ ...formData, jamMulai: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jam Selesai</label>
                  <input
                    type="time"
                    required
                    value={formData.jamSelesai}
                    onChange={(e) => setFormData({ ...formData, jamSelesai: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Rombel Kelas *</label>
                <select
                  value={formData.kelasId}
                  onChange={(e) => setFormData({ ...formData, kelasId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {kelasList.map((k) => (
                    <option key={k.id} value={k.id}>
                      {k.namaKelas}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Kitab Kuning *</label>
                <select
                  value={formData.kitabId}
                  onChange={(e) => setFormData({ ...formData, kitabId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {kitabList.map((kt) => (
                    <option key={kt.id} value={kt.id}>
                      {kt.namaKitab} ({kt.fanIlmu})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ustadz Pengampu *</label>
                <select
                  value={formData.guruId}
                  onChange={(e) => setFormData({ ...formData, guruId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {guruList.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.namaLengkap}, {g.gelar}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Sesi Pengajian</label>
                <select
                  value={formData.sesi}
                  onChange={(e) => setFormData({ ...formData, sesi: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value="Pagi (Pengajian Kitab)">Pagi (Pengajian Kitab)</option>
                  <option value="Siang (Madrasah)">Siang (Madrasah)</option>
                  <option value="Sore (Sorogan)">Sore (Sorogan)</option>
                  <option value="Malam (Musyawarah)">Malam (Musyawarah Bahtsul Masail)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ruangan</label>
                <input
                  type="text"
                  value={formData.ruangan}
                  onChange={(e) => setFormData({ ...formData, ruangan: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Simpan Jadwal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
