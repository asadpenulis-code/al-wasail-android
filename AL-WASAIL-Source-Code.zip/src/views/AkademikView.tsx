import React, { useState } from 'react';
import {
  BookOpen,
  Layers,
  GraduationCap,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Award,
  Sparkles,
  X,
  ChevronRight,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { KitabKuning, Kelas } from '../types';

export const AkademikView: React.FC = () => {
  const { role } = useAuth();
  const [activeTab, setActiveTab] = useState<'kitab' | 'kelas' | 'metode'>('kitab');
  const [kitabList, setKitabList] = useState<KitabKuning[]>(() => db.getKitab());
  const [kelasList, setKelasList] = useState<Kelas[]>(() => db.getKelas());
  const guruList = db.getGuru();
  const lembaga = db.getLembaga();

  // Modal states for Kitab
  const [isKitabModalOpen, setIsKitabModalOpen] = useState(false);
  const [editingKitab, setEditingKitab] = useState<KitabKuning | null>(null);
  const [kitabForm, setKitabForm] = useState<Omit<KitabKuning, 'id'>>({
    kodeKitab: '',
    namaKitab: '',
    namaKitabArab: '',
    pengarang: '',
    fanIlmu: 'Nahwu',
    jenjang: 'Ula',
    targetBab: '',
    faseMetodeAlWasail: 'Fase 1: Logika Tarkib & Tanda I\'rob',
    deskripsi: '',
    totalBaitAtauFasal: 50,
  });

  // Modal states for Kelas
  const [isKelasModalOpen, setIsKelasModalOpen] = useState(false);
  const [editingKelas, setEditingKelas] = useState<Kelas | null>(null);
  const [kelasForm, setKelasForm] = useState<Omit<Kelas, 'id'>>({
    kodeKelas: '',
    namaKelas: '',
    jenjang: 'Wustha',
    waliKelasId: guruList[0]?.id || '',
    waliKelasNama: guruList[0]?.namaLengkap || '',
    jumlahSantri: 25,
    ruangan: 'Gedung Al-Wasail',
    targetCapaian: '',
  });

  const canEdit = role === 'admin';

  const refreshKitab = () => setKitabList(db.getKitab());
  const refreshKelas = () => setKelasList(db.getKelas());

  const handleOpenAddKitab = () => {
    setEditingKitab(null);
    setKitabForm({
      kodeKitab: `KTB-${String(kitabList.length + 1).padStart(2, '0')}`,
      namaKitab: '',
      namaKitabArab: '',
      pengarang: '',
      fanIlmu: 'Nahwu',
      jenjang: 'Ula',
      targetBab: '',
      faseMetodeAlWasail: 'Fase 1: Logika Tarkib & Tanda I\'rob',
      deskripsi: '',
      totalBaitAtauFasal: 100,
    });
    setIsKitabModalOpen(true);
  };

  const handleOpenEditKitab = (k: KitabKuning) => {
    setEditingKitab(k);
    setKitabForm({
      kodeKitab: k.kodeKitab,
      namaKitab: k.namaKitab,
      namaKitabArab: k.namaKitabArab,
      pengarang: k.pengarang,
      fanIlmu: k.fanIlmu,
      jenjang: k.jenjang,
      targetBab: k.targetBab,
      faseMetodeAlWasail: k.faseMetodeAlWasail,
      deskripsi: k.deskripsi,
      totalBaitAtauFasal: k.totalBaitAtauFasal,
    });
    setIsKitabModalOpen(true);
  };

  const handleSaveKitab = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingKitab) {
      db.updateKitab(editingKitab.id, kitabForm);
    } else {
      db.createKitab(kitabForm);
    }
    refreshKitab();
    setIsKitabModalOpen(false);
  };

  const handleDeleteKitab = (id: string, nama: string) => {
    if (confirm(`Hapus kitab "${nama}" dari kurikulum?`)) {
      db.deleteKitab(id);
      refreshKitab();
    }
  };

  const handleOpenAddKelas = () => {
    setEditingKelas(null);
    const firstGuru = guruList[0];
    setKelasForm({
      kodeKelas: `KLS-${String(kelasList.length + 1).padStart(2, '0')}`,
      namaKelas: '',
      jenjang: 'Wustha',
      waliKelasId: firstGuru?.id || '',
      waliKelasNama: firstGuru ? `${firstGuru.namaLengkap}, ${firstGuru.gelar}` : '',
      jumlahSantri: 20,
      ruangan: 'Gedung Al-Wasail Lt. 2',
      targetCapaian: 'Penguasaan baca kitab gundul & nadhom',
    });
    setIsKelasModalOpen(true);
  };

  const handleOpenEditKelas = (k: Kelas) => {
    setEditingKelas(k);
    setKelasForm({
      kodeKelas: k.kodeKelas,
      namaKelas: k.namaKelas,
      jenjang: k.jenjang,
      waliKelasId: k.waliKelasId,
      waliKelasNama: k.waliKelasNama,
      jumlahSantri: k.jumlahSantri,
      ruangan: k.ruangan,
      targetCapaian: k.targetCapaian,
    });
    setIsKelasModalOpen(true);
  };

  const handleSaveKelas = (e: React.FormEvent) => {
    e.preventDefault();
    const g = guruList.find((x) => x.id === kelasForm.waliKelasId);
    const completeData = {
      ...kelasForm,
      waliKelasNama: g ? `${g.namaLengkap}, ${g.gelar}` : kelasForm.waliKelasNama,
    };

    if (editingKelas) {
      db.updateKelas(editingKelas.id, completeData);
    } else {
      db.createKelas(completeData);
    }
    refreshKelas();
    setIsKelasModalOpen(false);
  };

  const handleDeleteKelas = (id: string, nama: string) => {
    if (confirm(`Hapus kelas "${nama}"?`)) {
      db.deleteKelas(id);
      refreshKelas();
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-sky-600" />
            <span>Akademik & Kurikulum Kitab Kuning</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Silabus akselerasi Metode Al-Wasail, mata pelajaran kitab salafiyah, dan manajemen rombel kelas
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {activeTab === 'kitab' && canEdit && (
            <button
              onClick={handleOpenAddKitab}
              className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Kitab</span>
            </button>
          )}

          {activeTab === 'kelas' && canEdit && (
            <button
              onClick={handleOpenAddKelas}
              className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Rombel Kelas</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab('kitab')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'kitab' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Koleksi Kitab Kuning ({kitabList.length})
        </button>
        <button
          onClick={() => setActiveTab('kelas')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'kelas' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Rombongan Belajar ({kelasList.length})
        </button>
        <button
          onClick={() => setActiveTab('metode')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'metode' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Pilar Metode Al-Wasail
        </button>
      </div>

      {/* Tab 1: Kitab Kuning */}
      {activeTab === 'kitab' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {kitabList.map((k) => (
            <div
              key={k.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 transition-all p-5 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-100 uppercase">
                      {k.fanIlmu} · Tingkat {k.jenjang}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-2">{k.namaKitab}</h3>
                    {k.namaKitabArab && (
                      <p className="font-arabic text-lg text-sky-950 font-bold mt-1 text-right dir-rtl leading-relaxed">
                        {k.namaKitabArab}
                      </p>
                    )}
                    <span className="text-xs text-slate-500 block mt-1">Mu’allif: {k.pengarang}</span>
                  </div>

                  {canEdit && (
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => handleOpenEditKitab(k)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50"
                        title="Edit Kitab"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteKitab(k.id, k.namaKitab)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                        title="Hapus Kitab"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Fase Metode Al-Wasail:</span>
                    <span className="font-semibold text-slate-800">{k.faseMetodeAlWasail}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Target Capaian Pembelajaran:</span>
                    <span className="text-slate-700">{k.targetBab}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 italic leading-relaxed pt-1 border-t border-slate-200">
                    "{k.deskripsi}"
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span className="font-mono">Kode: {k.kodeKitab}</span>
                <span className="font-semibold font-mono text-slate-700">{k.totalBaitAtauFasal} Fasal/Bait</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Rombongan Belajar (Kelas) */}
      {activeTab === 'kelas' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {kelasList.map((kls) => (
            <div
              key={kls.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 transition-all p-5 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between">
                  <span className="text-[10px] font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-100 uppercase">
                    Marhalah {kls.jenjang}
                  </span>
                  {canEdit && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEditKelas(kls)}
                        className="p-1 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteKelas(kls.id, kls.namaKelas)}
                        className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                <h3 className="font-bold text-slate-900 text-sm mt-2">{kls.namaKelas}</h3>
                <span className="text-xs text-slate-500 block mt-0.5">Kode: {kls.kodeKelas} · {kls.ruangan}</span>

                <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                  <div>
                    <span className="text-slate-400 text-[10px] block">Wali Kelas Pengampu:</span>
                    <span className="font-semibold text-slate-800">{kls.waliKelasNama}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Target Capaian Rombel:</span>
                    <span className="text-slate-600">{kls.targetCapaian}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-500">Kapasitas Santri:</span>
                <span className="font-mono text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                  {kls.jumlahSantri} Santri
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Pilar Metode Al-Wasail */}
      {activeTab === 'metode' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6 space-y-6">
          <div className="p-4 bg-gradient-to-r from-sky-600 to-sky-800 text-white rounded-2xl">
            <h2 className="text-lg font-bold">Metodologi Al-Wasail: Akselerasi Baca Kitab Kuning</h2>
            <p className="text-xs text-sky-100 mt-1 max-w-2xl leading-relaxed">
              Dikembangkan di Pondok Pesantren Al-Ihsan Jrangoan untuk mengatasi kendala klasik santri dalam membaca kitab kuning gundul melalui sistematika gramatika yang terukur dan mudah dipahami.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-sky-50/70 border border-sky-200 space-y-2">
              <span className="text-xs font-bold text-sky-800 uppercase">Pilar 1: Logika Tarkib</span>
              <p className="text-xs text-slate-600 leading-relaxed">
                Santri diajarkan memetakan kata dalam kalimat menjadi 3 unsur esensial: Isim, Fi'il, atau Huruf. Setiap posisi kata memiliki status logika (Subjek, Predikat, Objek, Keterangan).
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-sky-50/70 border border-sky-200 space-y-2">
              <span className="text-xs font-bold text-sky-800 uppercase">Pilar 2: Rumus I'rob Cepat</span>
              <p className="text-xs text-slate-600 leading-relaxed">
                Menghubungkan tanda i'rob (Rofa', Nashob, Jer, Jazm) dengan bentuk kata (Mufrad, Tatsniyah, Jama' Taksir, Asma'ul Khomsah) melalui tabel visualisasi ringkas Al-Wasail.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-sky-50/70 border border-sky-200 space-y-2">
              <span className="text-xs font-bold text-sky-800 uppercase">Pilar 3: Praktik Kitab Gundul</span>
              <p className="text-xs text-slate-600 leading-relaxed">
                Sejak semester awal, santri langsung dibiasakan membaca teks asli tanpa harokat (kitab kosongan) menggunakan nalar Al-Wasail, bukan sekadar menghafal tanpa penalaran gramatikal.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Kitab Modal */}
      {isKitabModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingKitab ? 'Edit Kurikulum Kitab' : 'Tambah Kitab Kuning'}
              </h3>
              <button onClick={() => setIsKitabModalOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveKitab} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Kitab (Latin) *</label>
                <input
                  type="text"
                  required
                  value={kitabForm.namaKitab}
                  onChange={(e) => setKitabForm({ ...kitabForm, namaKitab: e.target.value })}
                  placeholder="Contoh: Nadhom Al-Imrithi"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Kitab (Teks Arab)</label>
                <input
                  type="text"
                  value={kitabForm.namaKitabArab}
                  onChange={(e) => setKitabForm({ ...kitabForm, namaKitabArab: e.target.value })}
                  placeholder="Contoh: متن الآجرومية"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-right font-arabic text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pengarang / Muallif *</label>
                <input
                  type="text"
                  required
                  value={kitabForm.pengarang}
                  onChange={(e) => setKitabForm({ ...kitabForm, pengarang: e.target.value })}
                  placeholder="Contoh: Syaikh Yahya Al-Imrithi"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Fan Ilmu *</label>
                  <select
                    value={kitabForm.fanIlmu}
                    onChange={(e) => setKitabForm({ ...kitabForm, fanIlmu: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Nahwu">Nahwu</option>
                    <option value="Shorof">Shorof</option>
                    <option value="Fiqih">Fiqih</option>
                    <option value="Aqidah">Aqidah</option>
                    <option value="Akhlak">Akhlak</option>
                    <option value="Hadits">Hadits</option>
                    <option value="Tafsir">Tafsir</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenjang Marhalah *</label>
                  <select
                    value={kitabForm.jenjang}
                    onChange={(e) => setKitabForm({ ...kitabForm, jenjang: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Ula">Tingkat Ula</option>
                    <option value="Wustha">Tingkat Wustha</option>
                    <option value="Ulya">Tingkat Ulya</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Fase Metode Al-Wasail</label>
                <input
                  type="text"
                  value={kitabForm.faseMetodeAlWasail}
                  onChange={(e) => setKitabForm({ ...kitabForm, faseMetodeAlWasail: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Bab Pembelajaran</label>
                <input
                  type="text"
                  value={kitabForm.targetBab}
                  onChange={(e) => setKitabForm({ ...kitabForm, targetBab: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Total Bait / Fasal</label>
                <input
                  type="number"
                  value={kitabForm.totalBaitAtauFasal}
                  onChange={(e) => setKitabForm({ ...kitabForm, totalBaitAtauFasal: Number(e.target.value) })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Deskripsi Singkat</label>
                <textarea
                  rows={2}
                  value={kitabForm.deskripsi}
                  onChange={(e) => setKitabForm({ ...kitabForm, deskripsi: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsKitabModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Simpan Kitab
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Kelas Modal */}
      {isKelasModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingKelas ? 'Edit Rombel Kelas' : 'Tambah Rombel Kelas'}
              </h3>
              <button onClick={() => setIsKelasModalOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveKelas} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Rombel Kelas *</label>
                <input
                  type="text"
                  required
                  value={kelasForm.namaKelas}
                  onChange={(e) => setKelasForm({ ...kelasForm, namaKelas: e.target.value })}
                  placeholder="Contoh: Tingkat Wustha - Kelas B (Putra)"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kode Kelas *</label>
                  <input
                    type="text"
                    required
                    value={kelasForm.kodeKelas}
                    onChange={(e) => setKelasForm({ ...kelasForm, kodeKelas: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenjang Marhalah</label>
                  <select
                    value={kelasForm.jenjang}
                    onChange={(e) => setKelasForm({ ...kelasForm, jenjang: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Ula">Ula</option>
                    <option value="Wustha">Wustha</option>
                    <option value="Ulya">Ulya</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Wali Kelas Pengampu</label>
                <select
                  value={kelasForm.waliKelasId}
                  onChange={(e) => setKelasForm({ ...kelasForm, waliKelasId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {guruList.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.namaLengkap}, {g.gelar}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ruangan Belajar</label>
                <input
                  type="text"
                  value={kelasForm.ruangan}
                  onChange={(e) => setKelasForm({ ...kelasForm, ruangan: e.target.value })}
                  placeholder="Contoh: Gedung Al-Wasail Lt. 2 Ruang 202"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Capaian</label>
                <input
                  type="text"
                  value={kelasForm.targetCapaian}
                  onChange={(e) => setKelasForm({ ...kelasForm, targetCapaian: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsKelasModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Simpan Rombel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
