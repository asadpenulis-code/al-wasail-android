import React, { useState } from 'react';
import {
  Settings,
  Building2,
  Users,
  Database,
  Save,
  Download,
  Upload,
  RotateCcw,
  Smartphone,
  Copy,
  Check,
  CheckCircle2,
  AlertCircle,
  Shield,
  Key,
  Globe,
  Plus,
  Trash2,
  Lock,
} from 'lucide-react';
import { db } from '../services/db';
import { testSupabaseConnection } from '../services/supabase';
import { useAuth } from '../context/AuthContext';
import { LembagaProfil, UserAccount, UserRole, SupabaseConfig } from '../types';

interface PengaturanViewProps {
  onOpenApkModal: () => void;
}

export const PengaturanView: React.FC<PengaturanViewProps> = ({ onOpenApkModal }) => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'profil' | 'users' | 'supabase' | 'backup'>('profil');

  // Profil Form State
  const [lembagaData, setLembagaData] = useState<LembagaProfil>(() => db.getLembaga());
  const [lembagaSaveMsg, setLembagaSaveMsg] = useState('');

  // User Accounts State
  const [userList, setUserList] = useState<UserAccount[]>(() => db.getUsers());
  const [newUserModal, setNewUserModal] = useState(false);
  const [newUserForm, setNewUserForm] = useState({
    username: '',
    fullName: '',
    role: 'santri' as UserRole,
    email: '',
    phone: '',
  });

  // Supabase Config State
  const [supabaseCfg, setSupabaseCfg] = useState<SupabaseConfig>(() => db.getSupabaseConfig());
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedSQL, setCopiedSQL] = useState(false);

  // Backup & Restore
  const [restoreMsg, setRestoreMsg] = useState<{ success: boolean; text: string } | null>(null);

  // Handlers for Profil
  const handleSaveLembaga = (e: React.FormEvent) => {
    e.preventDefault();
    db.updateLembaga(lembagaData);
    setLembagaSaveMsg('Profil lembaga dan metode Al-Wasail berhasil diperbarui!');
    setTimeout(() => setLembagaSaveMsg(''), 3000);
  };

  // Handlers for User Management
  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserForm.username.trim() || !newUserForm.fullName.trim()) return;

    db.createUser({
      username: newUserForm.username.trim().toLowerCase(),
      fullName: newUserForm.fullName.trim(),
      role: newUserForm.role,
      email: newUserForm.email.trim() || `${newUserForm.username}@alihsan.id`,
      phone: newUserForm.phone.trim() || '081234567890',
      status: 'active',
      lastLogin: 'Belum pernah',
    });

    setUserList(db.getUsers());
    setNewUserModal(false);
    setNewUserForm({ username: '', fullName: '', role: 'santri', email: '', phone: '' });
  };

  const handleDeleteUser = (id: string, name: string) => {
    if (confirm(`Hapus akun pengguna "${name}"?`)) {
      db.deleteUser(id);
      setUserList(db.getUsers());
    }
  };

  // Handlers for Supabase
  const handleSaveSupabase = (e: React.FormEvent) => {
    e.preventDefault();
    db.saveSupabaseConfig(supabaseCfg);
    setTestResult({ success: true, message: 'Konfigurasi Supabase tersimpan di aplikasi.' });
  };

  const handleTestSupabase = async () => {
    if (!supabaseCfg.url || !supabaseCfg.anonKey) {
      setTestResult({
        success: false,
        message: 'Mohon isi Supabase Project URL dan Anon Key terlebih dahulu.',
      });
      return;
    }

    setIsTesting(true);
    setTestResult(null);
    const res = await testSupabaseConnection(supabaseCfg.url, supabaseCfg.anonKey);
    setIsTesting(false);
    setTestResult(res);

    if (res.success) {
      db.saveSupabaseConfig({ isConnected: true });
      setSupabaseCfg((prev) => ({ ...prev, isConnected: true }));
    }
  };

  const handleCopySQL = () => {
    const sql = db.generateSupabaseSQL();
    navigator.clipboard.writeText(sql);
    setCopiedSQL(true);
    setTimeout(() => setCopiedSQL(false), 2500);
  };

  // Handlers for Backup & Restore
  const handleDownloadBackup = () => {
    const jsonStr = db.exportDatabaseJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_alwasail_alihsan_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = db.importDatabaseJSON(content);
      if (success) {
        setRestoreMsg({ success: true, text: 'Database berhasil dipulihkan dari file backup!' });
        setUserList(db.getUsers());
        setLembagaData(db.getLembaga());
      } else {
        setRestoreMsg({ success: false, text: 'Format file backup tidak valid.' });
      }
    };
    reader.readAsText(file);
  };

  const handleResetData = () => {
    if (confirm('PERINGATAN: Apakah Anda yakin ingin mengatur ulang data ke setelan awal pabrik? Seluruh modifikasi lokal akan dikembalikan.')) {
      db.resetToDefaultData();
      setUserList(db.getUsers());
      setLembagaData(db.getLembaga());
      setRestoreMsg({ success: true, text: 'Data sistem berhasil direset ke setelan awal bawaan.' });
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Settings className="w-6 h-6 text-sky-600" />
            <span>Pengaturan Sistem & Database AL-WASAIL</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Konfigurasi profil pesantren, integrasi database Supabase, akun pengguna RBAC, dan backup
          </p>
        </div>

        <button
          onClick={onOpenApkModal}
          className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <Smartphone className="w-4 h-4 text-sky-400" />
          <span>Panduan APK Android</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab('profil')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'profil' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Profil Lembaga</span>
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'users' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Akun & Hak Akses ({userList.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('supabase')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'supabase' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>Integrasi Supabase & RLS</span>
        </button>
        <button
          onClick={() => setActiveTab('backup')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'backup' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Backup & Pulihkan</span>
        </button>
      </div>

      {/* Tab 1: Profil Lembaga */}
      {activeTab === 'profil' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6">
          {lembagaSaveMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{lembagaSaveMsg}</span>
            </div>
          )}

          <form onSubmit={handleSaveLembaga} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Aplikasi *</label>
                <input
                  type="text"
                  required
                  value={lembagaData.nama}
                  onChange={(e) => setLembagaData({ ...lembagaData, nama: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap Lembaga *</label>
                <input
                  type="text"
                  required
                  value={lembagaData.namaLengkap}
                  onChange={(e) => setLembagaData({ ...lembagaData, namaLengkap: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Slogan Resmi *</label>
                <input
                  type="text"
                  required
                  value={lembagaData.slogan}
                  onChange={(e) => setLembagaData({ ...lembagaData, slogan: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nomor Statistik Pesantren (NSPP)</label>
                <input
                  type="text"
                  value={lembagaData.nspp}
                  onChange={(e) => setLembagaData({ ...lembagaData, nspp: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pengasuh Pesantren</label>
                <input
                  type="text"
                  value={lembagaData.pengasuh}
                  onChange={(e) => setLembagaData({ ...lembagaData, pengasuh: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ketua Pengurus</label>
                <input
                  type="text"
                  value={lembagaData.ketuaPengurus}
                  onChange={(e) => setLembagaData({ ...lembagaData, ketuaPengurus: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Desa</label>
                <input
                  type="text"
                  value={lembagaData.desa}
                  onChange={(e) => setLembagaData({ ...lembagaData, desa: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Kecamatan & Kabupaten</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={lembagaData.kecamatan}
                    onChange={(e) => setLembagaData({ ...lembagaData, kecamatan: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                  <input
                    type="text"
                    value={lembagaData.kabupaten}
                    onChange={(e) => setLembagaData({ ...lembagaData, kabupaten: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nomor Telepon / Hotline</label>
                <input
                  type="text"
                  value={lembagaData.telepon}
                  onChange={(e) => setLembagaData({ ...lembagaData, telepon: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email Resmi</label>
                <input
                  type="email"
                  value={lembagaData.email}
                  onChange={(e) => setLembagaData({ ...lembagaData, email: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Deskripsi & Keunggulan Metode Al-Wasail</label>
                <textarea
                  rows={3}
                  value={lembagaData.deskripsiMetode}
                  onChange={(e) => setLembagaData({ ...lembagaData, deskripsiMetode: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Visi Pesantren</label>
                <textarea
                  rows={2}
                  value={lembagaData.visi}
                  onChange={(e) => setLembagaData({ ...lembagaData, visi: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Perubahan Lembaga</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab 2: Akun Pengguna & RBAC */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">Manajemen Akun & Role Based Access Control</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Pengelolaan kredensial untuk 4 kategori hak akses: Pengurus/Admin, Dewan Guru, Santri, dan Wali Santri
              </p>
            </div>

            <button
              onClick={() => setNewUserModal(true)}
              className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Akun Baru</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Nama Lengkap</th>
                  <th className="py-3 px-4">Username Akun</th>
                  <th className="py-3 px-4">Peran Hak Akses</th>
                  <th className="py-3 px-4">Email / Kontak</th>
                  <th className="py-3 px-4">Aktivitas Terakhir</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {userList.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-bold text-slate-900">{u.fullName}</td>
                    <td className="py-3 px-4 font-mono text-sky-700 font-semibold">{u.username}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold ${
                          u.role === 'admin'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : u.role === 'guru'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : u.role === 'santri'
                            ? 'bg-sky-50 text-sky-700 border border-sky-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {u.role.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      <div>{u.email}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{u.phone}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-500 text-[11px] font-mono">
                      {u.lastLogin || '-'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {u.id !== currentUser?.id && (
                        <button
                          onClick={() => handleDeleteUser(u.id, u.fullName)}
                          className="p-1 rounded text-slate-400 hover:text-rose-600"
                          title="Hapus Akun"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Integrasi Supabase & RLS */}
      {activeTab === 'supabase' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6 space-y-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-600" />
                <span>Koneksi Database Supabase & Row Level Security</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
                Aplikasi AL-WASAIL telah dilengkapi dengan database permanen terstruktur. Anda dapat menghubungkan proyek Supabase PostgreSQL Anda untuk sinkronisasi cloud realtime lintas perangkat.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span
                className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
                  supabaseCfg.isConnected
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-slate-100 text-slate-600 border-slate-200'
                }`}
              >
                <div
                  className={`w-2 h-2 rounded-full ${
                    supabaseCfg.isConnected ? 'bg-emerald-500' : 'bg-slate-400'
                  }`}
                />
                <span>{supabaseCfg.isConnected ? 'Terhubung ke Supabase' : 'Mode Offline / Persistent DB'}</span>
              </span>
            </div>
          </div>

          {/* Test connection result banner */}
          {testResult && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                testResult.success
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}
            >
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <span>{testResult.message}</span>
            </div>
          )}

          {/* Configuration Form */}
          <form onSubmit={handleSaveSupabase} className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 block">Supabase Project URL</label>
              <input
                type="url"
                value={supabaseCfg.url}
                onChange={(e) => setSupabaseCfg({ ...supabaseCfg, url: e.target.value })}
                placeholder="https://xyzcompany.supabase.co"
                className="w-full p-2.5 bg-white border border-slate-200 rounded-xl font-mono text-slate-800"
              />
              <span className="text-[10px] text-slate-400">
                Dapat ditemukan pada Dashboard Supabase &gt; Project Settings &gt; API &gt; Project URL
              </span>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700 block">Supabase Anon Public API Key</label>
              <input
                type="password"
                value={supabaseCfg.anonKey}
                onChange={(e) => setSupabaseCfg({ ...supabaseCfg, anonKey: e.target.value })}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                className="w-full p-2.5 bg-white border border-slate-200 rounded-xl font-mono text-slate-800"
              />
              <span className="text-[10px] text-slate-400">
                Dapat ditemukan pada Dashboard Supabase &gt; Project Settings &gt; API &gt; anon public
              </span>
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleTestSupabase}
                disabled={isTesting}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl transition-colors flex items-center gap-1.5"
              >
                <span>{isTesting ? 'Menguji Koneksi...' : 'Uji Koneksi Supabase'}</span>
              </button>

              <button
                type="submit"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition-colors flex items-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Simpan Kredensial</span>
              </button>

              <button
                type="button"
                onClick={handleCopySQL}
                className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-semibold rounded-xl transition-colors flex items-center gap-1.5 ml-auto"
              >
                {copiedSQL ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700">Skrip SQL Tersalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Salin SQL Migration & RLS</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Guide Card */}
          <div className="p-4 bg-sky-50 rounded-2xl border border-sky-100 space-y-2 text-xs">
            <span className="font-bold text-sky-900 block">Cara Memasang Database Supabase:</span>
            <ol className="list-decimal list-inside space-y-1 text-slate-700">
              <li>Buat proyek baru di <strong>supabase.com</strong>.</li>
              <li>Buka menu <strong>SQL Editor</strong> di dashboard Supabase.</li>
              <li>Klik tombol <strong>"Salin SQL Migration & RLS"</strong> di atas, lalu tempel (paste) dan jalankan di SQL Editor Supabase.</li>
              <li>Salin <strong>Project URL</strong> dan <strong>Anon Key</strong> dari Project Settings &gt; API ke form di atas, lalu klik <strong>Simpan Kredensial</strong>.</li>
            </ol>
          </div>
        </div>
      )}

      {/* Tab 4: Backup & Restore */}
      {activeTab === 'backup' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <RotateCcw className="w-5 h-5 text-sky-600" />
              <span>Cadangkan, Pulihkan, & Reset Database</span>
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Amankan seluruh berkas santri, asatidz, absensi, dan nilai kitab kuning ke dalam berkas cadangan JSON
            </p>
          </div>

          {restoreMsg && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
                restoreMsg.success
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-rose-50 border-rose-200 text-rose-800'
              }`}
            >
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{restoreMsg.text}</span>
            </div>
          )}

          {/* Source Code ZIP Download Banner */}
          <div className="p-5 bg-gradient-to-r from-sky-50 via-sky-100/50 to-indigo-50 rounded-2xl border border-sky-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-sky-900 block flex items-center gap-2">
                <Download className="w-4 h-4 text-sky-600" />
                <span>Unduh Seluruh Kode Sumber Lengkap (Source Code .ZIP)</span>
                <span className="text-[10px] font-mono text-sky-700 bg-white px-2 py-0.5 rounded border border-sky-200">
                  1.67 MB
                </span>
              </span>
              <p className="text-xs text-slate-600 mt-1 max-w-xl">
                Unduh seluruh proyek dalam satu arsip ZIP siap pakai. Berisi file konfigurasi Vite, Tailwind CSS, TypeScript, manifest PWA, service worker, Capacitor Android, dan seluruh 12 modul lengkap.
              </p>
            </div>
            <a
              href="/AL-WASAIL-Source-Code.zip"
              download="AL-WASAIL-Source-Code.zip"
              className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2 shrink-0 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Unduh ZIP Proyek</span>
            </a>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
              <div>
                <span className="text-xs font-bold text-slate-900 block">Ekspor Cadangan Lengkap</span>
                <p className="text-[11px] text-slate-500 mt-1">
                  Unduh seluruh database (12 modul) ke dalam file JSON terenkripsi dan terstruktur.
                </p>
              </div>
              <button
                onClick={handleDownloadBackup}
                className="w-full py-2 px-3 bg-sky-600 hover:bg-sky-700 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh File Cadangan</span>
              </button>
            </div>

            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
              <div>
                <span className="text-xs font-bold text-slate-900 block">Pulihkan dari Berkas JSON</span>
                <p className="text-[11px] text-slate-500 mt-1">
                  Unggah berkas cadangan JSON yang telah diekspor sebelumnya untuk mengembalikan data.
                </p>
              </div>
              <label className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors text-center">
                <Upload className="w-3.5 h-3.5" />
                <span>Pilih Berkas JSON</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileRestore}
                  className="hidden"
                />
              </label>
            </div>

            <div className="p-5 bg-rose-50/50 rounded-2xl border border-rose-200 flex flex-col justify-between space-y-3">
              <div>
                <span className="text-xs font-bold text-rose-900 block">Setel Ulang Data Awal</span>
                <p className="text-[11px] text-slate-500 mt-1">
                  Kembalikan seluruh data ke contoh riil Pondok Pesantren Al-Ihsan Jrangoan.
                </p>
              </div>
              <button
                onClick={handleResetData}
                className="w-full py-2 px-3 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Setelan Pabrik</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Tambah Akun Pengguna */}
      {newUserModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">Buat Akun Pengguna Baru</h3>
              <button onClick={() => setNewUserModal(false)} className="text-sky-200 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap Pengguna *</label>
                <input
                  type="text"
                  required
                  value={newUserForm.fullName}
                  onChange={(e) => setNewUserForm({ ...newUserForm, fullName: e.target.value })}
                  placeholder="Contoh: Ustadz Zainul Hasan"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Username Login *</label>
                <input
                  type="text"
                  required
                  value={newUserForm.username}
                  onChange={(e) => setNewUserForm({ ...newUserForm, username: e.target.value })}
                  placeholder="Contoh: ustadz.zainul"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Peran Hak Akses (RBAC) *</label>
                <select
                  value={newUserForm.role}
                  onChange={(e) => setNewUserForm({ ...newUserForm, role: e.target.value as UserRole })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="admin">Pengurus / Admin (Akses Penuh)</option>
                  <option value="guru">Dewan Guru / Asatidz (Absensi & Nilai)</option>
                  <option value="santri">Santri (Jadwal, Nilai & Absensi)</option>
                  <option value="wali">Wali Santri (Pantau Raport & Absensi)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email</label>
                <input
                  type="email"
                  value={newUserForm.email}
                  onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                  placeholder="email@alihsan-jrangoan.sch.id"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nomor WhatsApp</label>
                <input
                  type="text"
                  value={newUserForm.phone}
                  onChange={(e) => setNewUserForm({ ...newUserForm, phone: e.target.value })}
                  placeholder="081234567890"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setNewUserModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Buat Akun
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
