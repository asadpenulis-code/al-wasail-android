import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Edit2,
  Trash2,
  Eye,
  Filter,
  Download,
  CheckCircle2,
  X,
  Phone,
  Home,
  BookOpen,
  Award,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { Santri } from '../types';

export const SantriView: React.FC = () => {
  const { role } = useAuth();
  const [santriList, setSantriList] = useState<Santri[]>(() => db.getSantri());
  const kelasList = db.getKelas();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterJenjang, setFilterJenjang] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSantri, setEditingSantri] = useState<Santri | null>(null);
  const [selectedSantri, setSelectedSantri] = useState<Santri | null>(null);

  // Form state
  const [formData, setFormData] = useState<Omit<Santri, 'id'>>({
    nis: '',
    nisn: '',
    namaLengkap: '',
    namaPanggilan: '',
    jenisKelamin: 'L',
    tempatLahir: '',
    tanggalLahir: '2008-01-01',
    jenjang: 'Wustha',
    kelasId: kelasList[0]?.id || '',
    namaKelas: kelasList[0]?.namaKelas || '',
    asrama: 'Asrama Putra Al-Ihsan',
    kamar: 'Kamar Abu Bakar No. 01',
    namaWali: '',
    noHpWali: '',
    alamat: '',
    tahunMasuk: 2024,
    status: 'Aktif',
    levelBacaKitab: 3,
    catatanMetodeAlWasail: '',
    targetKitab: '',
  });

  const refreshList = () => {
    setSantriList(db.getSantri());
  };

  const handleOpenAdd = () => {
    setEditingSantri(null);
    setFormData({
      nis: `2026.${String(santriList.length + 1).padStart(2, '0')}.0${Math.floor(Math.random() * 900 + 100)}`,
      nisn: `00${Math.floor(Math.random() * 90000000 + 10000000)}`,
      namaLengkap: '',
      namaPanggilan: '',
      jenisKelamin: 'L',
      tempatLahir: 'Sampang',
      tanggalLahir: '2008-05-15',
      jenjang: 'Wustha',
      kelasId: kelasList[0]?.id || '',
      namaKelas: kelasList[0]?.namaKelas || '',
      asrama: 'Asrama Putra Al-Ihsan',
      kamar: 'Kamar Abu Bakar No. 01',
      namaWali: '',
      noHpWali: '081234567890',
      alamat: 'Kabupaten Sampang, Madura',
      tahunMasuk: 2026,
      status: 'Aktif',
      levelBacaKitab: 3,
      catatanMetodeAlWasail: 'Mampu mengidentifikasi tarkib dasar dan tanda i\'rob.',
      targetKitab: 'Nadhom Al-Imrithi & Fathul Qorib',
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (s: Santri) => {
    setEditingSantri(s);
    setFormData({
      nis: s.nis,
      nisn: s.nisn,
      namaLengkap: s.namaLengkap,
      namaPanggilan: s.namaPanggilan,
      jenisKelamin: s.jenisKelamin,
      tempatLahir: s.tempatLahir,
      tanggalLahir: s.tanggalLahir,
      jenjang: s.jenjang,
      kelasId: s.kelasId,
      namaKelas: s.namaKelas,
      asrama: s.asrama,
      kamar: s.kamar,
      namaWali: s.namaWali,
      noHpWali: s.noHpWali,
      alamat: s.alamat,
      tahunMasuk: s.tahunMasuk,
      status: s.status,
      levelBacaKitab: s.levelBacaKitab,
      catatanMetodeAlWasail: s.catatanMetodeAlWasail,
      targetKitab: s.targetKitab,
    });
    setIsFormOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedKls = kelasList.find((k) => k.id === formData.kelasId);
    const completeData = {
      ...formData,
      namaKelas: selectedKls ? selectedKls.namaKelas : formData.namaKelas,
    };

    if (editingSantri) {
      db.updateSantri(editingSantri.id, completeData);
    } else {
      db.createSantri(completeData);
    }
    refreshList();
    setIsFormOpen(false);
  };

  const handleDelete = (id: string, nama: string) => {
    if (confirm(`Apakah Anda yakin ingin menghapus data santri "${nama}"? Data yang dihapus tidak dapat dipulihkan.`)) {
      db.deleteSantri(id);
      refreshList();
    }
  };

  const exportCSV = () => {
    const headers = 'NIS,Nama Lengkap,Panggilan,L/P,Jenjang,Kelas,Wali,No HP Wali,Level Al-Wasail,Status\n';
    const rows = santriList
      .map(
        (s) =>
          `"${s.nis}","${s.namaLengkap}","${s.namaPanggilan}","${s.jenisKelamin}","${s.jenjang}","${s.namaKelas}","${s.namaWali}","${s.noHpWali}","Level ${s.levelBacaKitab}","${s.status}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `data_santri_alwasail_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  // Filter and search
  const filteredSantri = santriList.filter((s) => {
    const matchSearch =
      s.namaLengkap.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.nis.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.namaWali.toLowerCase().includes(searchQuery.toLowerCase());
    const matchJenjang = filterJenjang === 'all' || s.jenjang === filterJenjang;
    const matchStatus = filterStatus === 'all' || s.status === filterStatus;
    return matchSearch && matchJenjang && matchStatus;
  });

  const canEdit = role === 'admin' || role === 'guru';

  return (
    <div className="space-y-5">
      {/* Page Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-6 h-6 text-sky-600" />
            <span>Data Santri PP Al-Ihsan Jrangoan</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Pengelolaan biodata santri, kelas, capaian akselerasi Metode Al-Wasail, dan wali santri
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={exportCSV}
            className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Ekspor CSV</span>
          </button>

          {canEdit && (
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Santri</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Box */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari santri berdasarkan nama, NIS, atau nama wali..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800"
          />
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={filterJenjang}
              onChange={(e) => setFilterJenjang(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
            >
              <option value="all">Semua Jenjang</option>
              <option value="Ula">Tingkat Ula</option>
              <option value="Wustha">Tingkat Wustha</option>
              <option value="Ulya">Tingkat Ulya</option>
            </select>
          </div>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
          >
            <option value="all">Semua Status</option>
            <option value="Aktif">Aktif</option>
            <option value="Alumni">Alumni</option>
            <option value="Cuti">Cuti</option>
          </select>
        </div>
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Santri</th>
                <th className="py-3.5 px-4">NIS / Jenjang</th>
                <th className="py-3.5 px-4">Kelas & Asrama</th>
                <th className="py-3.5 px-4">Capaian Al-Wasail</th>
                <th className="py-3.5 px-4">Wali Santri</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSantri.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    Tidak ditemukan data santri yang sesuai kriteria pencarian.
                  </td>
                </tr>
              ) : (
                filteredSantri.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-700 font-bold flex items-center justify-center shrink-0">
                          {s.namaPanggilan.charAt(0)}
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 block">{s.namaLengkap}</span>
                          <span className="text-[11px] text-slate-500">Panggilan: {s.namaPanggilan} ({s.jenisKelamin === 'L' ? 'Putra' : 'Putri'})</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-mono text-slate-700 block font-medium">{s.nis}</span>
                      <span className="text-[11px] text-sky-600 font-semibold">{s.jenjang}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-medium text-slate-800 block truncate max-w-[160px]">{s.namaKelas}</span>
                      <span className="text-[11px] text-slate-500 block truncate max-w-[160px]">{s.kamar}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-full bg-sky-50 text-sky-700 font-bold border border-sky-100 font-mono">
                          Level {s.levelBacaKitab}
                        </span>
                        <span className="text-[11px] text-slate-500 truncate max-w-[130px]" title={s.targetKitab}>
                          {s.targetKitab}
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-medium text-slate-800 block">{s.namaWali}</span>
                      <span className="text-[11px] text-slate-500 font-mono">{s.noHpWali}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          s.status === 'Aktif'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {s.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedSantri(s)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-sky-600 hover:bg-sky-50 transition-colors"
                          title="Lihat Detail Profil"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {canEdit && (
                          <>
                            <button
                              onClick={() => handleOpenEdit(s)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                              title="Edit Data"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(s.id, s.namaLengkap)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              title="Hapus Data"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedSantri && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-[11px] font-bold text-sky-700 uppercase">Biodata Resmi Santri</span>
                <h3 className="text-lg font-bold text-slate-900">{selectedSantri.namaLengkap}</h3>
              </div>
              <button
                onClick={() => setSelectedSantri(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-2.5 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Nomor Induk Santri (NIS)</span>
                <span className="font-mono font-bold text-slate-800">{selectedSantri.nis}</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block text-[10px]">NISN Nasional</span>
                <span className="font-mono font-bold text-slate-800">{selectedSantri.nisn || '-'}</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Tempat, Tanggal Lahir</span>
                <span className="font-medium text-slate-800">{selectedSantri.tempatLahir}, {selectedSantri.tanggalLahir}</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Kelas & Jenjang</span>
                <span className="font-medium text-slate-800">{selectedSantri.namaKelas} ({selectedSantri.jenjang})</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl col-span-2">
                <span className="text-slate-400 block text-[10px]">Asrama & Kamar</span>
                <span className="font-medium text-slate-800">{selectedSantri.asrama} — {selectedSantri.kamar}</span>
              </div>
            </div>

            {/* Al-Wasail Progress Card */}
            <div className="p-4 bg-sky-50/80 rounded-xl border border-sky-100 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-sky-600" />
                  <span>Progres Metode AL-WASAIL</span>
                </span>
                <span className="px-2 py-0.5 rounded-full bg-sky-600 text-white font-mono font-bold text-[10px]">
                  Level {selectedSantri.levelBacaKitab}
                </span>
              </div>
              <p className="text-xs text-slate-700">
                <strong>Target Kitab:</strong> {selectedSantri.targetKitab}
              </p>
              <p className="text-xs text-slate-600 italic">
                "{selectedSantri.catatanMetodeAlWasail}"
              </p>
            </div>

            {/* Wali & Kontak */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 block">Wali Santri</span>
                <span className="text-xs font-bold text-slate-800">{selectedSantri.namaWali}</span>
                <span className="text-[11px] text-slate-500 block">{selectedSantri.alamat}</span>
              </div>
              <a
                href={`https://wa.me/${selectedSantri.noHpWali.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium flex items-center gap-1.5 shadow-2xs"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Hubungi Wali</span>
              </a>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedSantri(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingSantri ? 'Edit Data Santri' : 'Tambah Santri Baru'}
              </h3>
              <button
                onClick={() => setIsFormOpen(false)}
                className="p-1 rounded-lg text-sky-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap Santri *</label>
                  <input
                    type="text"
                    required
                    value={formData.namaLengkap}
                    onChange={(e) => setFormData({ ...formData, namaLengkap: e.target.value })}
                    placeholder="Contoh: Muhammad Ilham"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Panggilan *</label>
                  <input
                    type="text"
                    required
                    value={formData.namaPanggilan}
                    onChange={(e) => setFormData({ ...formData, namaPanggilan: e.target.value })}
                    placeholder="Contoh: Ilham"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nomor Induk Santri (NIS) *</label>
                  <input
                    type="text"
                    required
                    value={formData.nis}
                    onChange={(e) => setFormData({ ...formData, nis: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenis Kelamin</label>
                  <select
                    value={formData.jenisKelamin}
                    onChange={(e) => setFormData({ ...formData, jenisKelamin: e.target.value as 'L' | 'P' })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="L">Laki-laki (Santri Putra)</option>
                    <option value="P">Perempuan (Santri Putri)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenjang Pendidikan</label>
                  <select
                    value={formData.jenjang}
                    onChange={(e) => setFormData({ ...formData, jenjang: e.target.value as 'Ula' | 'Wustha' | 'Ulya' })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Ula">Marhalah Ula (Dasar)</option>
                    <option value="Wustha">Marhalah Wustha (Menengah)</option>
                    <option value="Ulya">Marhalah Ulya (Atas / Lanjutan)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Pilih Rombel / Kelas</label>
                  <select
                    value={formData.kelasId}
                    onChange={(e) => setFormData({ ...formData, kelasId: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {kelasList.map((k) => (
                      <option key={k.id} value={k.id}>
                        {k.namaKelas}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tempat Lahir</label>
                  <input
                    type="text"
                    value={formData.tempatLahir}
                    onChange={(e) => setFormData({ ...formData, tempatLahir: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tanggal Lahir</label>
                  <input
                    type="date"
                    value={formData.tanggalLahir}
                    onChange={(e) => setFormData({ ...formData, tanggalLahir: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Asrama</label>
                  <input
                    type="text"
                    value={formData.asrama}
                    onChange={(e) => setFormData({ ...formData, asrama: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kamar</label>
                  <input
                    type="text"
                    value={formData.kamar}
                    onChange={(e) => setFormData({ ...formData, kamar: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Wali Santri *</label>
                  <input
                    type="text"
                    required
                    value={formData.namaWali}
                    onChange={(e) => setFormData({ ...formData, namaWali: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nomor WhatsApp Wali *</label>
                  <input
                    type="text"
                    required
                    value={formData.noHpWali}
                    onChange={(e) => setFormData({ ...formData, noHpWali: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Alamat Asal Santri</label>
                  <input
                    type="text"
                    value={formData.alamat}
                    onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Level Metode Al-Wasail (1-5)</label>
                  <select
                    value={formData.levelBacaKitab}
                    onChange={(e) => setFormData({ ...formData, levelBacaKitab: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value={1}>Level 1: Dasar Tarkib & Tanda I'rob</option>
                    <option value={2}>Level 2: Baca Berharokat & Pola Isim</option>
                    <option value={3}>Level 3: I'rob Lanjutan & Harokat Minim</option>
                    <option value={4}>Level 4: Baca Kitab Kosongan (Gundul)</option>
                    <option value={5}>Level 5: Mahir Mandiri & Bahtsul Masail</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Kitab Kuning</label>
                  <input
                    type="text"
                    value={formData.targetKitab}
                    onChange={(e) => setFormData({ ...formData, targetKitab: e.target.value })}
                    placeholder="Contoh: Nadhom Imrithi & Fathul Qorib"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Catatan Evaluasi Metode Al-Wasail</label>
                  <textarea
                    rows={2}
                    value={formData.catatanMetodeAlWasail}
                    onChange={(e) => setFormData({ ...formData, catatanMetodeAlWasail: e.target.value })}
                    placeholder="Deskripsi progres kelancaran membaca, pemahaman tarkib, atau kendala santri..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold shadow-xs"
                >
                  Simpan Data Santri
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
