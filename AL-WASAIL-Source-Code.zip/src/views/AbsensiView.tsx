import React, { useState } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  Clock,
  Filter,
  Save,
  Download,
  AlertCircle,
  Users,
  Search,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { AbsensiRecord, StatusKehadiran } from '../types';

export const AbsensiView: React.FC = () => {
  const { role, currentUser } = useAuth();
  const kelasList = db.getKelas();
  const santriList = db.getSantri();
  const guruList = db.getGuru();
  const [absensiList, setAbsensiList] = useState<AbsensiRecord[]>(() => db.getAbsensi());

  // Active filters
  const [selectedKelasId, setSelectedKelasId] = useState(kelasList[0]?.id || '');
  const [selectedTanggal, setSelectedTanggal] = useState(new Date().toISOString().split('T')[0]);
  const [selectedSesi, setSelectedSesi] = useState<AbsensiRecord['sesi']>('Pagi (Pengajian Kitab)');
  const [searchFilter, setSearchFilter] = useState('');
  const [viewMode, setViewMode] = useState<'input' | 'rekap'>('input');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  // Selected kelas details
  const currentKelas = kelasList.find((k) => k.id === selectedKelasId) || kelasList[0];
  const santriDiKelas = santriList.filter((s) => s.kelasId === selectedKelasId);

  // Editable local attendance rows for selected date, class & session
  const [attendanceSheet, setAttendanceSheet] = useState<Record<string, { status: StatusKehadiran; keterangan: string }>>(() => {
    const map: Record<string, { status: StatusKehadiran; keterangan: string }> = {};
    santriList.forEach((s) => {
      // Find existing record
      const existing = absensiList.find(
        (a) => a.santriId === s.id && a.tanggal === selectedTanggal && a.sesi === selectedSesi
      );
      map[s.id] = {
        status: existing ? existing.status : 'Hadir',
        keterangan: existing ? existing.keterangan : '',
      };
    });
    return map;
  });

  const handleUpdateStatus = (santriId: string, status: StatusKehadiran) => {
    setAttendanceSheet((prev) => ({
      ...prev,
      [santriId]: {
        ...prev[santriId],
        status,
      },
    }));
  };

  const handleUpdateKeterangan = (santriId: string, keterangan: string) => {
    setAttendanceSheet((prev) => ({
      ...prev,
      [santriId]: {
        ...prev[santriId],
        keterangan,
      },
    }));
  };

  const handleMarkAllHadir = () => {
    const updated: Record<string, { status: StatusKehadiran; keterangan: string }> = { ...attendanceSheet };
    santriDiKelas.forEach((s) => {
      updated[s.id] = {
        status: 'Hadir',
        keterangan: updated[s.id]?.keterangan || '',
      };
    });
    setAttendanceSheet(updated);
  };

  const handleSaveAttendance = () => {
    const activeGuru = guruList[0];
    const recordsToSave = santriDiKelas.map((s) => ({
      santriId: s.id,
      santriNama: s.namaLengkap,
      kelasId: currentKelas.id,
      namaKelas: currentKelas.namaKelas,
      tanggal: selectedTanggal,
      status: attendanceSheet[s.id]?.status || 'Hadir',
      keterangan: attendanceSheet[s.id]?.keterangan || '',
      guruId: activeGuru?.id || 'guru-1',
      guruNama: activeGuru ? activeGuru.namaLengkap : 'Ustadz Pengampu',
      sesi: selectedSesi,
    }));

    db.saveBatchAbsensi(recordsToSave);
    setAbsensiList(db.getAbsensi());
    setSaveSuccessMsg('Presensi santri berhasil disimpan ke database!');
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  // Export Rekap to CSV
  const handleExportRekap = () => {
    const headers = 'Tanggal,Sesi,Kelas,Nama Santri,Status,Keterangan,Guru Pengampu\n';
    const rows = absensiList
      .map(
        (a) =>
          `"${a.tanggal}","${a.sesi}","${a.namaKelas}","${a.santriNama}","${a.status}","${a.keterangan}","${a.guruNama}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `rekap_absensi_alwasail_${selectedTanggal}.csv`;
    link.click();
  };

  // Can edit if Admin or Guru
  const canEdit = role === 'admin' || role === 'guru';

  // Rekap Stats
  const statusColors: Record<StatusKehadiran, { bg: string; text: string; activeBg: string }> = {
    Hadir: { bg: 'bg-emerald-50', text: 'text-emerald-700', activeBg: 'bg-emerald-600 text-white' },
    Izin: { bg: 'bg-sky-50', text: 'text-sky-700', activeBg: 'bg-sky-600 text-white' },
    Sakit: { bg: 'bg-amber-50', text: 'text-amber-700', activeBg: 'bg-amber-600 text-white' },
    Alfa: { bg: 'bg-rose-50', text: 'text-rose-700', activeBg: 'bg-rose-600 text-white' },
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <CalendarCheck className="w-6 h-6 text-sky-600" />
            <span>Absensi & Presensi Pengajian Santri</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Pencatatan real-time kehadiran pengajian kitab kuning, sorogan Al-Wasail, dan madrasah
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleExportRekap}
            className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Ekspor Rekap CSV</span>
          </button>

          <div className="p-1 bg-slate-200/70 rounded-xl flex items-center gap-1">
            <button
              onClick={() => setViewMode('input')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                viewMode === 'input' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Input Presensi
            </button>
            <button
              onClick={() => setViewMode('rekap')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                viewMode === 'rekap' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Riwayat Rekap
            </button>
          </div>
        </div>
      </div>

      {saveSuccessMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold">{saveSuccessMsg}</span>
        </div>
      )}

      {/* Control Strip for Input Mode */}
      {viewMode === 'input' && (
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                Pilih Rombel / Kelas
              </label>
              <select
                value={selectedKelasId}
                onChange={(e) => setSelectedKelasId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                {kelasList.map((k) => (
                  <option key={k.id} value={k.id}>
                    {k.namaKelas}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                Tanggal Pengajian
              </label>
              <input
                type="date"
                value={selectedTanggal}
                onChange={(e) => setSelectedTanggal(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                Sesi Pembelajaran
              </label>
              <select
                value={selectedSesi}
                onChange={(e) => setSelectedSesi(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
              >
                <option value="Pagi (Pengajian Kitab)">Pagi (Pengajian Kitab Kuning)</option>
                <option value="Siang (Madrasah)">Siang (Madrasah Diniyah)</option>
                <option value="Sore (Sorogan)">Sore (Sorogan Metode Al-Wasail)</option>
                <option value="Malam (Musyawarah)">Malam (Musyawarah Bahtsul Masail)</option>
              </select>
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-100">
            <span className="text-xs text-slate-500">
              Menampilkan <strong>{santriDiKelas.length} santri</strong> terdaftar di {currentKelas?.namaKelas}.
            </span>

            {canEdit && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleMarkAllHadir}
                  className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-semibold transition-colors"
                >
                  Tandai Semua Hadir
                </button>
                <button
                  type="button"
                  onClick={handleSaveAttendance}
                  className="px-4 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan Presensi</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Attendance Table */}
      {viewMode === 'input' ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">No</th>
                  <th className="py-3 px-4">Nama Santri</th>
                  <th className="py-3 px-4">NIS</th>
                  <th className="py-3 px-4">Status Kehadiran</th>
                  <th className="py-3 px-4">Keterangan / Alasan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {santriDiKelas.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      Belum ada santri terdaftar di rombel kelas ini.
                    </td>
                  </tr>
                ) : (
                  santriDiKelas.map((s, idx) => {
                    const currentRecord = attendanceSheet[s.id] || { status: 'Hadir', keterangan: '' };
                    return (
                      <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4 font-mono text-slate-400 w-10">{idx + 1}</td>
                        <td className="py-3 px-4">
                          <span className="font-bold text-slate-900 block">{s.namaLengkap}</span>
                          <span className="text-[11px] text-slate-500">Panggilan: {s.namaPanggilan}</span>
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-600">{s.nis}</td>
                        <td className="py-3 px-4">
                          {canEdit ? (
                            <div className="inline-flex rounded-lg p-0.5 bg-slate-100 border border-slate-200">
                              {(['Hadir', 'Izin', 'Sakit', 'Alfa'] as StatusKehadiran[]).map((st) => (
                                <button
                                  key={st}
                                  type="button"
                                  onClick={() => handleUpdateStatus(s.id, st)}
                                  className={`px-2.5 py-1 text-xs font-bold rounded-md transition-all ${
                                    currentRecord.status === st
                                      ? statusColors[st].activeBg + ' shadow-2xs'
                                      : 'text-slate-600 hover:text-slate-900'
                                  }`}
                                >
                                  {st}
                                </button>
                              ))}
                            </div>
                          ) : (
                            <span
                              className={`px-2.5 py-1 rounded-md text-xs font-bold ${
                                statusColors[currentRecord.status].bg + ' ' + statusColors[currentRecord.status].text
                              }`}
                            >
                              {currentRecord.status}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {canEdit ? (
                            <input
                              type="text"
                              value={currentRecord.keterangan}
                              onChange={(e) => handleUpdateKeterangan(s.id, e.target.value)}
                              placeholder="Keterangan (misal: sakit, tugas pondok)..."
                              className="w-full max-w-xs p-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                            />
                          ) : (
                            <span className="text-slate-600">{currentRecord.keterangan || '-'}</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Rekap Mode */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Histori Presensi Santri Lengkap</h3>
            <span className="text-xs text-slate-500 font-mono">{absensiList.length} Catatan Tersimpan</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Tanggal & Sesi</th>
                  <th className="py-3 px-4">Santri</th>
                  <th className="py-3 px-4">Kelas</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Keterangan</th>
                  <th className="py-3 px-4">Ustadz Pencatat</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {absensiList.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">
                      <span className="font-mono font-medium text-slate-800 block">{a.tanggal}</span>
                      <span className="text-[10px] text-slate-500">{a.sesi}</span>
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">{a.santriNama}</td>
                    <td className="py-3 px-4 text-slate-700">{a.namaKelas}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold ${
                          statusColors[a.status].bg + ' ' + statusColors[a.status].text
                        }`}
                      >
                        {a.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{a.keterangan || '-'}</td>
                    <td className="py-3 px-4 text-slate-700">{a.guruNama}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
