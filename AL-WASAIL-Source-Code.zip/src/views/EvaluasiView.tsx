import React, { useState } from 'react';
import {
  LineChart,
  Plus,
  Edit2,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  Filter,
  Search,
  X,
  Sparkles,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { EvaluasiMonitoring } from '../types';

export const EvaluasiView: React.FC = () => {
  const { role } = useAuth();
  const [evaluasiList, setEvaluasiList] = useState<EvaluasiMonitoring[]>(() => db.getEvaluasi());
  const santriList = db.getSantri();
  const guruList = db.getGuru();
  const kelasList = db.getKelas();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterLevel, setFilterLevel] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEvaluasi, setEditingEvaluasi] = useState<EvaluasiMonitoring | null>(null);

  const [formData, setFormData] = useState<Omit<EvaluasiMonitoring, 'id'>>({
    santriId: santriList[0]?.id || '',
    santriNama: santriList[0]?.namaLengkap || '',
    kelasId: santriList[0]?.kelasId || '',
    namaKelas: santriList[0]?.namaKelas || '',
    tanggal: new Date().toISOString().split('T')[0],
    levelAlWasail: 3,
    capaianBab: 'Nadhom Imrithi Bab Kalam s/d Bab Fa\'il',
    kelancaranBaca: 'Lancar',
    penguasaanNahwuShorof: 'Jayyid (Baik)',
    catatanPembimbing: 'Kelancaran membaca kitab kosongan memuaskan.',
    rekomendasiTindakLanjut: 'Diberikan pengayaan bab tarkib majrurat.',
    evaluatorId: guruList[0]?.id || 'guru-1',
    evaluatorNama: guruList[0]?.namaLengkap || 'Ustadz Penguji',
  });

  const refreshList = () => setEvaluasiList(db.getEvaluasi());
  const canEdit = role === 'admin' || role === 'guru';

  const handleOpenAdd = () => {
    setEditingEvaluasi(null);
    const s = santriList[0];
    const g = guruList[0];
    setFormData({
      santriId: s?.id || '',
      santriNama: s?.namaLengkap || '',
      kelasId: s?.kelasId || '',
      namaKelas: s?.namaKelas || '',
      tanggal: new Date().toISOString().split('T')[0],
      levelAlWasail: s ? s.levelBacaKitab : 3,
      capaianBab: 'Fathul Qorib bab Sholat',
      kelancaranBaca: 'Lancar',
      penguasaanNahwuShorof: 'Jayyid (Baik)',
      catatanPembimbing: 'Mampu membedakan isim fail dan isim maf\'ul saat membaca teks kosongan.',
      rekomendasiTindakLanjut: 'Latihan membaca bab muamalah mandiri.',
      evaluatorId: g?.id || '',
      evaluatorNama: g ? `${g.namaLengkap}, ${g.gelar}` : '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (ev: EvaluasiMonitoring) => {
    setEditingEvaluasi(ev);
    setFormData({
      santriId: ev.santriId,
      santriNama: ev.santriNama,
      kelasId: ev.kelasId,
      namaKelas: ev.namaKelas,
      tanggal: ev.tanggal,
      levelAlWasail: ev.levelAlWasail,
      capaianBab: ev.capaianBab,
      kelancaranBaca: ev.kelancaranBaca,
      penguasaanNahwuShorof: ev.penguasaanNahwuShorof,
      catatanPembimbing: ev.catatanPembimbing,
      rekomendasiTindakLanjut: ev.rekomendasiTindakLanjut,
      evaluatorId: ev.evaluatorId,
      evaluatorNama: ev.evaluatorNama,
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const st = santriList.find((s) => s.id === formData.santriId);
    const g = guruList.find((x) => x.id === formData.evaluatorId);
    const completeData = {
      ...formData,
      santriNama: st ? st.namaLengkap : formData.santriNama,
      kelasId: st ? st.kelasId : formData.kelasId,
      namaKelas: st ? st.namaKelas : formData.namaKelas,
      evaluatorNama: g ? `${g.namaLengkap}, ${g.gelar}` : formData.evaluatorNama,
    };

    if (editingEvaluasi) {
      db.updateEvaluasi(editingEvaluasi.id, completeData);
    } else {
      db.createEvaluasi(completeData);
    }

    // Also update santri level in santri record
    if (st) {
      db.updateSantri(st.id, { levelBacaKitab: formData.levelAlWasail });
    }

    refreshList();
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, namaSantri: string) => {
    if (confirm(`Hapus catatan evaluasi santri "${namaSantri}"?`)) {
      db.deleteEvaluasi(id);
      refreshList();
    }
  };

  const filteredEvaluasi = evaluasiList.filter((e) => {
    const matchSearch =
      e.santriNama.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.capaianBab.toLowerCase().includes(searchQuery.toLowerCase());
    const matchLevel = filterLevel === 'all' || e.levelAlWasail.toString() === filterLevel;
    return matchSearch && matchLevel;
  });

  // Santri requiring remedial/special mentoring
  const needMentoring = evaluasiList.filter(
    (e) => e.kelancaranBaca === 'Perlu Bimbingan Khusus' || e.kelancaranBaca === 'Kurang Lancar'
  );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <LineChart className="w-6 h-6 text-sky-600" />
            <span>Evaluasi & Monitoring Metode AL-WASAIL</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Pemantauan diagnostik kemampuan membaca kitab kuning tanpa harokat santri PP Al-Ihsan Jrangoan
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Catat Evaluasi Klinis</span>
          </button>
        )}
      </div>

      {/* Warning Spotlight for Santri Needing Guidance */}
      {needMentoring.length > 0 && (
        <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900">
            <span className="font-bold block text-sm">
              Perhatian: {needMentoring.length} Santri Memerlukan Bimbingan Intensif (Ta'ziz)
            </span>
            <p className="mt-0.5 text-slate-700">
              Santri terdeteksi mengalami kendala pada pemisahan kalimah isim/fi'il atau harokat akhir. Jadwalkan bimbingan sorogan khusus ba'da Ashar sesuai rekomendasi ustadz penguji.
            </p>
          </div>
        </div>
      )}

      {/* Search and Level Filter */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari evaluasi berdasarkan nama santri atau bab kitab..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800"
          />
        </div>

        <select
          value={filterLevel}
          onChange={(e) => setFilterLevel(e.target.value)}
          className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 shrink-0 w-full sm:w-auto"
        >
          <option value="all">Semua Level Al-Wasail</option>
          <option value="1">Level 1: Dasar Tarkib</option>
          <option value="2">Level 2: Teks Berharokat</option>
          <option value="3">Level 3: Harokat Minim</option>
          <option value="4">Level 4: Kitab Kosongan</option>
          <option value="5">Level 5: Mahir Mandiri</option>
        </select>
      </div>

      {/* Evaluasi Records Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEvaluasi.map((ev) => (
          <div
            key={ev.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 transition-all p-5 flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <span className="px-2 py-0.5 rounded-full bg-sky-50 text-sky-700 font-mono font-bold text-[10px] border border-sky-100">
                    Metode Al-Wasail · Level {ev.levelAlWasail}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 mt-1">{ev.santriNama}</h3>
                  <span className="text-[11px] text-slate-500 block">{ev.namaKelas}</span>
                </div>

                {canEdit && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(ev)}
                      className="p-1 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(ev.id, ev.santriNama)}
                      className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2 text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block">Capaian Materi / Bab:</span>
                  <span className="font-semibold text-slate-800">{ev.capaianBab}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <span className="text-slate-400 text-[10px] block">Kelancaran Baca:</span>
                    <span className="font-bold text-slate-700">{ev.kelancaranBaca}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Penguasaan Nahwu:</span>
                    <span className="font-bold text-sky-700">{ev.penguasaanNahwuShorof}</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-200">
                  <span className="text-slate-400 text-[10px] block">Catatan Pembimbing:</span>
                  <p className="text-[11px] text-slate-600 italic">"{ev.catatanPembimbing}"</p>
                </div>
                <div className="pt-1">
                  <span className="text-slate-400 text-[10px] block">Rekomendasi Tindak Lanjut:</span>
                  <p className="text-[11px] text-emerald-700 font-medium">{ev.rekomendasiTindakLanjut}</p>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Penguji: {ev.evaluatorNama}</span>
              <span className="font-mono">{ev.tanggal}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingEvaluasi ? 'Edit Evaluasi Santri' : 'Catat Evaluasi Klinis Al-Wasail'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pilih Santri yang Dievaluasi *</label>
                <select
                  value={formData.santriId}
                  onChange={(e) => setFormData({ ...formData, santriId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {santriList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.namaLengkap} ({s.nis} - {s.namaKelas})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tanggal Evaluasi</label>
                  <input
                    type="date"
                    required
                    value={formData.tanggal}
                    onChange={(e) => setFormData({ ...formData, tanggal: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Level Metode Al-Wasail</label>
                  <select
                    value={formData.levelAlWasail}
                    onChange={(e) => setFormData({ ...formData, levelAlWasail: Number(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value={1}>Level 1: Dasar Tarkib</option>
                    <option value={2}>Level 2: Teks Berharokat</option>
                    <option value={3}>Level 3: Harokat Minim</option>
                    <option value={4}>Level 4: Kitab Kosongan (Gundul)</option>
                    <option value={5}>Level 5: Mahir Mandiri</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Capaian Bab / Materi Uji</label>
                <input
                  type="text"
                  required
                  value={formData.capaianBab}
                  onChange={(e) => setFormData({ ...formData, capaianBab: e.target.value })}
                  placeholder="Contoh: Fathul Qorib Bab Jinayat atau Imrithi bait 150-200"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kelancaran Membaca</label>
                  <select
                    value={formData.kelancaranBaca}
                    onChange={(e) => setFormData({ ...formData, kelancaranBaca: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Sangat Lancar">Sangat Lancar</option>
                    <option value="Lancar">Lancar</option>
                    <option value="Kurang Lancar">Kurang Lancar</option>
                    <option value="Perlu Bimbingan Khusus">Perlu Bimbingan Khusus</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Penguasaan Nahwu & Shorof</label>
                  <select
                    value={formData.penguasaanNahwuShorof}
                    onChange={(e) => setFormData({ ...formData, penguasaanNahwuShorof: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Mumtaz (Sangat Baik)">Mumtaz (Sangat Baik)</option>
                    <option value="Jayyid (Baik)">Jayyid (Baik)</option>
                    <option value="Cukup">Cukup</option>
                    <option value="Kurang">Kurang</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Catatan Pembimbing Klinis</label>
                <textarea
                  rows={2}
                  value={formData.catatanPembimbing}
                  onChange={(e) => setFormData({ ...formData, catatanPembimbing: e.target.value })}
                  placeholder="Kelebihan dan kelemahan santri saat mempraktikkan metode..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Rekomendasi Tindak Lanjut</label>
                <input
                  type="text"
                  value={formData.rekomendasiTindakLanjut}
                  onChange={(e) => setFormData({ ...formData, rekomendasiTindakLanjut: e.target.value })}
                  placeholder="Contoh: Naik level kitab / Sorogan intensif ba'da Maghrib"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ustadz Penguji</label>
                <select
                  value={formData.evaluatorId}
                  onChange={(e) => setFormData({ ...formData, evaluatorId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {guruList.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.namaLengkap}, {g.gelar}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Simpan Evaluasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
