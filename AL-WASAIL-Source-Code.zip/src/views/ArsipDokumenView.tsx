import React, { useState } from 'react';
import {
  FolderArchive,
  FileText,
  Download,
  Plus,
  Trash2,
  Search,
  Filter,
  X,
  FileSpreadsheet,
  CheckCircle2,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { ArsipDokumen } from '../types';

export const ArsipDokumenView: React.FC = () => {
  const { role } = useAuth();
  const [dokumenList, setDokumenList] = useState<ArsipDokumen[]>(() => db.getDokumen());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterKategori, setFilterKategori] = useState<string>('all');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState<Omit<ArsipDokumen, 'id'>>({
    judul: '',
    nomorSurat: '',
    kategori: 'Kurikulum Al-Wasail',
    ukuran: '1.5 MB',
    tanggalUnggah: new Date().toISOString().split('T')[0],
    pengunggah: 'Bagian Sekretariat',
    ekstensi: 'PDF',
    deskripsi: '',
  });

  const refreshList = () => setDokumenList(db.getDokumen());
  const canEdit = role === 'admin';

  const handleOpenAdd = () => {
    setFormData({
      judul: '',
      nomorSurat: `DOC-ALIHSAN-${new Date().getFullYear()}/${Math.floor(Math.random() * 900 + 100)}`,
      kategori: 'Kurikulum Al-Wasail',
      ukuran: '2.4 MB',
      tanggalUnggah: new Date().toISOString().split('T')[0],
      pengunggah: 'Bidang Pendidikan Pesantren',
      ekstensi: 'PDF',
      deskripsi: '',
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    db.createDokumen(formData);
    refreshList();
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, judul: string) => {
    if (confirm(`Hapus arsip dokumen "${judul}"?`)) {
      db.deleteDokumen(id);
      refreshList();
    }
  };

  const handleDownload = (doc: ArsipDokumen) => {
    // Generate simulated realistic document file download
    const content = `PONDOK PESANTREN AL-IHSAN JRANGOAN
SISTEM INFORMASI PENDIDIKAN AL-WASAIL
"Metode Mudah Baca Kitab Kuning"
------------------------------------------------------------
DOKUMEN RESMI
Judul         : ${doc.judul}
Nomor Berkas  : ${doc.nomorSurat}
Kategori      : ${doc.kategori}
Tanggal Unggah: ${doc.tanggalUnggah}
Diterbitkan   : ${doc.pengunggah}
------------------------------------------------------------
DESKRIPSI:
${doc.deskripsi}

Catatan: Dokumen ini diterbitkan secara sah oleh Sekretariat Pondok Pesantren Al-Ihsan Jrangoan, Sampang, Madura.`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${doc.judul.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase()}.${doc.ekstensi.toLowerCase()}`;
    link.click();
  };

  const filteredDocs = dokumenList.filter((d) => {
    const matchSearch =
      d.judul.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.nomorSurat.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.deskripsi.toLowerCase().includes(searchQuery.toLowerCase());
    const matchKategori = filterKategori === 'all' || d.kategori === filterKategori;
    return matchSearch && matchKategori;
  });

  const getFileIcon = (ext: string) => {
    if (ext === 'XLSX') return <FileSpreadsheet className="w-5 h-5 text-emerald-600" />;
    return <FileText className="w-5 h-5 text-rose-600" />;
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <FolderArchive className="w-6 h-6 text-sky-600" />
            <span>Arsip Dokumen & Modul Al-Wasail</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Repositori resmi modul panduan metode, surat keputusan, silabus kurikulum, dan kalender pendidikan
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Unggah Dokumen Baru</span>
          </button>
        )}
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari dokumen, nomor berkas, atau isi pedoman..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800"
          />
        </div>

        <select
          value={filterKategori}
          onChange={(e) => setFilterKategori(e.target.value)}
          className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 shrink-0 w-full sm:w-auto"
        >
          <option value="all">Semua Kategori Dokumen</option>
          <option value="Buku Pedoman">Buku Pedoman</option>
          <option value="Kurikulum Al-Wasail">Kurikulum Al-Wasail</option>
          <option value="Kalender Akademik">Kalender Akademik</option>
          <option value="SK Pengurus">SK Pengurus</option>
          <option value="Panduan Guru">Panduan Guru</option>
          <option value="Formulir">Formulir</option>
        </select>
      </div>

      {/* Document Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredDocs.map((doc) => (
          <div
            key={doc.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 transition-all p-5 flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 shrink-0">
                    {getFileIcon(doc.ekstensi)}
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-sky-700 uppercase bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                      {doc.kategori}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 mt-1">{doc.judul}</h3>
                    <span className="text-[11px] text-slate-400 font-mono block">No: {doc.nomorSurat}</span>
                  </div>
                </div>

                {canEdit && (
                  <button
                    onClick={() => handleDelete(doc.id, doc.judul)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                    title="Hapus Dokumen"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <p className="text-xs text-slate-600 mt-3 line-clamp-2 leading-relaxed">
                {doc.deskripsi}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-400 font-mono text-[11px]">
                {doc.ukuran} · {doc.ekstensi}
              </span>
              <button
                onClick={() => handleDownload(doc)}
                className="px-3 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 font-semibold text-xs flex items-center gap-1.5 border border-sky-200 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Berkas</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">Unggah Arsip Dokumen Baru</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Judul Dokumen *</label>
                <input
                  type="text"
                  required
                  value={formData.judul}
                  onChange={(e) => setFormData({ ...formData, judul: e.target.value })}
                  placeholder="Contoh: Modul Latihan Tarkib Al-Wasail Jilid 2"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nomor Dokumen / Surat</label>
                  <input
                    type="text"
                    value={formData.nomorSurat}
                    onChange={(e) => setFormData({ ...formData, nomorSurat: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kategori Dokumen</label>
                  <select
                    value={formData.kategori}
                    onChange={(e) => setFormData({ ...formData, kategori: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Kurikulum Al-Wasail">Kurikulum Al-Wasail</option>
                    <option value="Buku Pedoman">Buku Pedoman</option>
                    <option value="Kalender Akademik">Kalender Akademik</option>
                    <option value="SK Pengurus">SK Pengurus</option>
                    <option value="Panduan Guru">Panduan Guru</option>
                    <option value="Formulir">Formulir</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Format Ekstensi</label>
                  <select
                    value={formData.ekstensi}
                    onChange={(e) => setFormData({ ...formData, ekstensi: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="PDF">Dokumen PDF (.pdf)</option>
                    <option value="DOCX">Microsoft Word (.docx)</option>
                    <option value="XLSX">Spreadsheet Excel (.xlsx)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Estimasi Ukuran</label>
                  <input
                    type="text"
                    value={formData.ukuran}
                    onChange={(e) => setFormData({ ...formData, ukuran: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Deskripsi Singkat Isi Berkas</label>
                <textarea
                  rows={3}
                  value={formData.deskripsi}
                  onChange={(e) => setFormData({ ...formData, deskripsi: e.target.value })}
                  placeholder="Keterangan isi dokumen, tujuan panduan..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Simpan Dokumen
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
