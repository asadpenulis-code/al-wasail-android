import React, { useState } from 'react';
import { Lock, User, ArrowRight, Shield, CheckCircle, Info } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db } from '../services/db';
import { UserRole } from '../types';

interface LoginViewProps {
  onSuccess: () => void;
  onOpenProfile: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onSuccess, onOpenProfile }) => {
  const { login } = useAuth();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('ihsan123');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const lembaga = db.getLembaga();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    try {
      const res = await login(username, password);
      if (res.success) {
        onSuccess();
      } else {
        setErrorMsg(res.message || 'Login gagal. Periksa kembali username/password.');
      }
    } catch {
      setErrorMsg('Terjadi kesalahan saat proses masuk.');
    } finally {
      setLoading(false);
    }
  };

  const quickLoginAs = async (u: string) => {
    setUsername(u);
    setPassword('ihsan123');
    setLoading(true);
    const res = await login(u, 'ihsan123');
    setLoading(false);
    if (res.success) {
      onSuccess();
    }
  };

  const quickRoles = [
    { role: 'admin' as UserRole, u: 'admin', label: '1. Pengurus / Admin', desc: 'Kelola seluruh data & sistem' },
    { role: 'guru' as UserRole, u: 'ustadz.ahmad', label: '2. Guru / Asatidz', desc: 'Isi absensi & input nilai' },
    { role: 'santri' as UserRole, u: 'santri.mubarok', label: '3. Santri', desc: 'Jadwal, absensi & nilai kitab' },
    { role: 'wali' as UserRole, u: 'wali.mubarok', label: '4. Wali Santri', desc: 'Pantau raport putra/putri' },
  ];

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-200 grid grid-cols-1 md:grid-cols-2">
        {/* Left Visual Column */}
        <div className="relative bg-gradient-to-br from-sky-600 via-sky-700 to-slate-900 text-white p-8 flex flex-col justify-between overflow-hidden">
          <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:20px_20px]" />
          
          <div className="z-10">
            <div className="flex items-center gap-3 mb-6">
              <img
                src={lembaga.logoUrl}
                alt="Logo AL-WASAIL"
                className="w-14 h-14 rounded-full border-2 border-white/50 bg-white object-cover shadow-md"
              />
              <div>
                <h1 className="text-xl font-extrabold tracking-wide uppercase">AL-WASAIL</h1>
                <p className="text-xs text-sky-200 font-medium">PP Al-Ihsan Jrangoan</p>
              </div>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
              Sistem Informasi & Manajemen Pendidikan
            </h2>
            <p className="text-sky-200 text-xs sm:text-sm mt-3 leading-relaxed">
              Platform terintegrasi pengurus, dewan asatidz, santri, dan wali santri dalam akselerasi pembelajaran Kitab Kuning salafiyah.
            </p>
          </div>

          <div className="z-10 mt-8 pt-6 border-t border-white/15">
            <div className="flex items-center justify-between text-xs text-sky-200">
              <span className="font-medium italic">"{lembaga.slogan}"</span>
              <button
                type="button"
                onClick={onOpenProfile}
                className="hover:text-white underline flex items-center gap-1 font-semibold"
              >
                <Info className="w-3.5 h-3.5" />
                <span>Profil Lembaga</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Form Column */}
        <div className="p-8 sm:p-10 flex flex-col justify-center">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-slate-900">Masuk ke Akun Anda</h3>
            <p className="text-xs text-slate-500 mt-1">Silakan gunakan kredensial resmi pesantren Anda.</p>
          </div>

          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Username / Email Akun
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Contoh: admin atau ustadz.ahmad"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white text-slate-800 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Kata Sandi
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:bg-white text-slate-800 transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-700 disabled:bg-sky-400 text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <span>{loading ? 'Memverifikasi...' : 'Masuk Sekarang'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Demo Role Logins */}
          <div className="mt-6 pt-5 border-t border-slate-200">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Masuk Cepat 1-Klik Berdasarkan Peran:
            </span>
            <div className="grid grid-cols-2 gap-2">
              {quickRoles.map((qr) => (
                <button
                  key={qr.role}
                  type="button"
                  onClick={() => quickLoginAs(qr.u)}
                  className="p-2 rounded-xl border border-slate-200 hover:border-sky-300 bg-slate-50 hover:bg-sky-50 text-left transition-colors"
                >
                  <span className="text-xs font-bold text-slate-800 block truncate">{qr.label}</span>
                  <span className="text-[10px] text-slate-500 block truncate">{qr.u}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
