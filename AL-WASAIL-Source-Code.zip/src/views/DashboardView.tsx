import React, { useState } from 'react';
import {
  Users,
  GraduationCap,
  BookOpen,
  CalendarCheck,
  Award,
  Trophy,
  Megaphone,
  ArrowUpRight,
  Sparkles,
  CheckCircle2,
  Clock,
  ChevronRight,
  TrendingUp,
  BookmarkCheck,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface DashboardViewProps {
  onNavigate: (menuId: string) => void;
  onOpenProfile: () => void;
  onOpenApkModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenProfile,
  onOpenApkModal,
}) => {
  const { role, currentUser } = useAuth();
  const santriList = db.getSantri();
  const guruList = db.getGuru();
  const kelasList = db.getKelas();
  const absensiList = db.getAbsensi();
  const pengumumanList = db.getPengumuman();
  const prestasiList = db.getPrestasi();
  const kitabList = db.getKitab();
  const evaluasiList = db.getEvaluasi();
  const lembaga = db.getLembaga();

  // Calculate statistics
  const totalSantri = santriList.length;
  const santriAktif = santriList.filter((s) => s.status === 'Aktif').length;
  const totalGuru = guruList.length;
  const totalKelas = kelasList.length;

  // Today attendance stats
  const today = new Date().toISOString().split('T')[0];
  const todayAbsensi = absensiList.filter((a) => a.tanggal === today);
  const hadirCount = todayAbsensi.filter((a) => a.status === 'Hadir').length;
  const kehadiranPercent = todayAbsensi.length > 0
    ? Math.round((hadirCount / todayAbsensi.length) * 100)
    : 96; // Standard pesantren attendance rate

  // Level Al-Wasail distribution
  const levelCounts = [1, 2, 3, 4, 5].map((lvl) => ({
    level: lvl,
    count: santriList.filter((s) => s.levelBacaKitab === lvl).length,
  }));

  // Role personalized greeting
  const roleGreetings: Record<string, string> = {
    admin: 'Pengurus & Administrator Sistem Al-Wasail',
    guru: 'Ustadz / Ustadzah Pengampu Kitab Kuning',
    santri: 'Santri PP Al-Ihsan Jrangoan',
    wali: 'Wali Santri PP Al-Ihsan Jrangoan',
  };

  return (
    <div className="space-y-6">
      {/* Hero Welcome Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-sky-600 via-sky-700 to-slate-900 text-white p-6 sm:p-8 shadow-md">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:20px_20px]" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-semibold text-sky-200 border border-white/15">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{roleGreetings[role || 'admin']}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Ahlan Wa Sahlan, {currentUser?.fullName}!
            </h1>
            <p className="text-sky-100 text-xs sm:text-sm leading-relaxed">
              Selamat datang di sistem manajemen <strong className="text-white">AL-WASAIL</strong> — {lembaga.namaLengkap}. Pantau kehadiran, capaian belajar santri, dan akselerasi baca Kitab Kuning dalam satu ekosistem terpadu.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={onOpenProfile}
              className="px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold backdrop-blur-md border border-white/20 transition-all flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4 text-sky-200" />
              <span>Profil Lembaga</span>
            </button>
            <button
              onClick={onOpenApkModal}
              className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold shadow-md transition-all flex items-center gap-2"
            >
              <span>Instal APK Android</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 4 Core Summary Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigate('santri')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Santri</span>
            <div className="p-2 rounded-xl bg-sky-50 text-sky-600 group-hover:bg-sky-600 group-hover:text-white transition-colors">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">{totalSantri}</span>
            <span className="text-xs text-slate-500 block mt-0.5">{santriAktif} Santri Berstatus Aktif</span>
          </div>
        </div>

        <div
          onClick={() => onNavigate('guru')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Dewan Asatidz</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <GraduationCap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">{totalGuru}</span>
            <span className="text-xs text-slate-500 block mt-0.5">Ustadz / Ustadzah Pengampu</span>
          </div>
        </div>

        <div
          onClick={() => onNavigate('absensi')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Tingkat Kehadiran</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">{kehadiranPercent}%</span>
            <span className="text-xs text-emerald-600 font-semibold block mt-0.5">Disiplin Pengajian Tinggi</span>
          </div>
        </div>

        <div
          onClick={() => onNavigate('akademik')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Kitab Kuning</span>
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">{kitabList.length}</span>
            <span className="text-xs text-slate-500 block mt-0.5">{totalKelas} Rombel Terakreditasi</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Al-Wasail Progress & Recent Announcements */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Progress Capaian Metode Al-Wasail */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <BookmarkCheck className="w-5 h-5 text-sky-600" />
                <span>Peta Capaian Kemampuan Santri: Metode AL-WASAIL</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Distribusi level kemahiran membaca kitab gundul santri saat ini
              </p>
            </div>
            <button
              onClick={() => onNavigate('evaluasi')}
              className="text-xs font-semibold text-sky-600 hover:text-sky-700 flex items-center gap-1"
            >
              <span>Detail Monitoring</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3.5">
            {[
              { lvl: 1, name: 'Level 1: Dasar Tarkib (Isim, Fi\'il, Huruf & Tanda I\'rob)', target: 'Matan Al-Jurumiyyah & Tashrif', color: 'bg-sky-400' },
              { lvl: 2, name: 'Level 2: Baca Berharokat & Struktur Mubtada-Khobar', target: 'Safinatun Naja', color: 'bg-sky-500' },
              { lvl: 3, name: 'Level 3: I\'rob Lanjutan & Penguraian Harokat Minim', target: 'Nadhom Al-Imrithi', color: 'bg-sky-600' },
              { lvl: 4, name: 'Level 4: Baca Kosongan (Gundul) & Analisis Sintaksis', target: 'Fathul Qorib Al-Mujib', color: 'bg-indigo-600' },
              { lvl: 5, name: 'Level 5: Mahir Mandiri & Bahtsul Masail Salaf', target: 'Alfiyyah Ibnu Malik & Fathul Mu\'in', color: 'bg-emerald-600' },
            ].map((item) => {
              const count = santriList.filter((s) => s.levelBacaKitab === item.lvl).length;
              const percent = totalSantri > 0 ? Math.round((count / totalSantri) * 100) : 0;

              return (
                <div key={item.lvl} className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-semibold text-slate-800">{item.name}</span>
                    <span className="font-mono font-bold text-sky-900">{count} Santri ({percent}%)</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full ${item.color} rounded-full transition-all duration-500`}
                      style={{ width: `${Math.max(percent, 5)}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1 flex items-center justify-between">
                    <span>Target Kitab: {item.target}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Announcements & News */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-amber-500" />
                <h2 className="text-base font-bold text-slate-900">Warta Pesantren</h2>
              </div>
              <button
                onClick={() => onNavigate('pengumuman')}
                className="text-xs font-semibold text-sky-600 hover:text-sky-700"
              >
                Semua
              </button>
            </div>

            <div className="py-2 space-y-3">
              {pengumumanList.slice(0, 3).map((item) => (
                <div
                  key={item.id}
                  onClick={() => onNavigate('pengumuman')}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-sky-50 border border-slate-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                    <span className="font-bold text-sky-700 uppercase">{item.kategori}</span>
                    <span className="font-mono">{item.tanggal}</span>
                  </div>
                  <h3 className="text-xs font-bold text-slate-800 line-clamp-1">{item.judul}</h3>
                  <p className="text-[11px] text-slate-500 line-clamp-2 mt-1">{item.konten}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Prestasi Spotlight */}
          <div className="p-4 bg-gradient-to-r from-amber-50 to-amber-100/60 rounded-xl border border-amber-200">
            <div className="flex items-center gap-2 mb-1.5">
              <Trophy className="w-4 h-4 text-amber-600" />
              <span className="text-xs font-bold text-amber-900">Prestasi Terkini</span>
            </div>
            {prestasiList.length > 0 && (
              <p className="text-xs text-slate-700">
                <strong>{prestasiList[0].santriNama}</strong> meraih <em>{prestasiList[0].juara}</em> pada {prestasiList[0].namaEvent}.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Quick Navigation Action Grid */}
      <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
        <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">
          Aksi Cepat & Navigasi Operasional
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {[
            { id: 'absensi', label: 'Catat Absensi', icon: CalendarCheck, color: 'text-emerald-600 bg-emerald-50' },
            { id: 'nilai', label: 'Input Nilai', icon: Award, color: 'text-sky-600 bg-sky-50' },
            { id: 'jadwal', label: 'Jadwal Ngaji', icon: Clock, color: 'text-indigo-600 bg-indigo-50' },
            { id: 'prestasi', label: 'Input Prestasi', icon: Trophy, color: 'text-amber-600 bg-amber-50' },
            { id: 'dokumen', label: 'Arsip & Modul', icon: BookOpen, color: 'text-purple-600 bg-purple-50' },
            { id: 'pengaturan', label: 'Sistem & Backup', icon: CheckCircle2, color: 'text-slate-600 bg-slate-100' },
          ].map((act) => {
            const Icon = act.icon;
            return (
              <button
                key={act.id}
                onClick={() => onNavigate(act.id)}
                className="p-3 bg-white hover:bg-slate-100/80 rounded-xl border border-slate-200 shadow-2xs flex flex-col items-center text-center gap-2 transition-transform active:scale-95"
              >
                <div className={`p-2 rounded-lg ${act.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-slate-800">{act.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
