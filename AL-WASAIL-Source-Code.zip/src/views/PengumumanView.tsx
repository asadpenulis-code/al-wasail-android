import React, { useState } from 'react';
import {
  Megaphone,
  Pin,
  Plus,
  Edit2,
  Trash2,
  Calendar,
  User,
  Search,
  Filter,
  X,
  Share2,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { Pengumuman } from '../types';

export const PengumumanView: React.FC = () => {
  const { role } = useAuth();
  const [pengumumanList, setPengumumanList] = useState<Pengumuman[]>(() => db.getPengumuman());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAudience, setFilterAudience] = useState<string>('all');
  const [filterKategori, setFilterKategori] = useState<string>('all');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPengumuman, setEditingPengumuman] = useState<Pengumuman | null>(null);

  const [formData, setFormData] = useState<Omit<Pengumuman, 'id'>>({
    judul: '',
    konten: '',
    tanggal: new Date().toISOString().split('T')[0],
    penulis: 'Sekretariat Pesantren Al-Ihsan Jrangoan',
    targetAudience: 'Semua',
    kategori: 'Akademik',
    isPinned: false,
  });

  const refreshList = () => setPengumumanList(db.getPengumuman());
  const canEdit = role === 'admin' || role === 'guru';

  const handleOpenAdd = () => {
    setEditingPengumuman(null);
    setFormData({
      judul: '',
      konten: '',
      tanggal: new Date().toISOString().split('T')[0],
      penulis: 'Bagian Pendidikan & Pengasuhan',
      targetAudience: 'Semua',
      kategori: 'Akademik',
      isPinned: false,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Pengumuman) => {
    setEditingPengumuman(p);
    setFormData({
      judul: p.judul,
      konten: p.konten,
      tanggal: p.tanggal,
      penulis: p.penulis,
      targetAudience: p.targetAudience,
      kategori: p.kategori,
      isPinned: p.isPinned,
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingPengumuman) {
      db.updatePengumuman(editingPengumuman.id, formData);
    } else {
      db.createPengumuman(formData);
    }
    refreshList();
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, judul: string) => {
    if (confirm(`Hapus pengumuman "${judul}"?`)) {
      db.deletePengumuman(id);
      refreshList();
    }
  };

  const handleTogglePin = (p: Pengumuman) => {
    db.updatePengumuman(p.id, { isPinned: !p.isPinned });
    refreshList();
  };

  const filteredPengumuman = pengumumanList.filter((p) => {
    const matchSearch =
      p.judul.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.konten.toLowerCase().includes(searchQuery.toLowerCase());
    const matchAudience = filterAudience === 'all' || p.targetAudience === filterAudience || p.targetAudience === 'Semua';
    const matchKategori = filterKategori === 'all' || p.kategori === filterKategori;
    return matchSearch && matchAudience && matchKategori;
  });

  // Sort pinned first
  const sortedList = [...filteredPengumuman].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return b.tanggal.localeCompare(a.tanggal);
  });

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Megaphone className="w-6 h-6 text-sky-600" />
            <span>Pusat Informasi & Pengumuman Resmi</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Warta resmi kegiatan, jadwal ikhtibar, dan maklumat pengurus Pondok Pesantren Al-Ihsan Jrangoan
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Buat Pengumuman</span>
          </button>
        )}
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari pengumuman..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800"
          />
        </div>

        <div className="flex items-center gap-2 shrink-0 w-full md:w-auto">
          <select
            value={filterAudience}
            onChange={(e) => setFilterAudience(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
          >
            <option value="all">Semua Sasaran</option>
            <option value="Semua">Untuk Semua</option>
            <option value="Santri">Santri</option>
            <option value="Guru">Guru / Asatidz</option>
            <option value="Wali Santri">Wali Santri</option>
          </select>

          <select
            value={filterKategori}
            onChange={(e) => setFilterKategori(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
          >
            <option value="all">Semua Kategori</option>
            <option value="Akademik">Akademik</option>
            <option value="Kegiatan">Kegiatan</option>
            <option value="Ujian Kitab">Ujian Kitab</option>
            <option value="Libur Pondok">Libur Pondok</option>
            <option value="Penting">Penting</option>
          </select>
        </div>
      </div>

      {/* Pengumuman List */}
      <div className="space-y-3.5">
        {sortedList.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-xs">
            Tidak ada pengumuman yang sesuai filter.
          </div>
        ) : (
          sortedList.map((p) => (
            <div
              key={p.id}
              className={`bg-white rounded-2xl border transition-all p-5 shadow-2xs ${
                p.isPinned ? 'border-sky-300 bg-sky-50/20' : 'border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2 flex-wrap">
                  {p.isPinned && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      <Pin className="w-3 h-3 text-amber-600 fill-amber-600" />
                      <span>Dipasang (Pinned)</span>
                    </span>
                  )}
                  <span className="text-[10px] font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-100 uppercase">
                    {p.kategori}
                  </span>
                  <span className="text-[10px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    Sasaran: {p.targetAudience}
                  </span>
                </div>

                {canEdit && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleTogglePin(p)}
                      className={`p-1.5 rounded-lg transition-colors ${
                        p.isPinned ? 'text-amber-600 bg-amber-50' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'
                      }`}
                      title={p.isPinned ? 'Lepas Pin' : 'Pasang Pin'}
                    >
                      <Pin className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleOpenEdit(p)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50"
                      title="Edit"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(p.id, p.judul)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                      title="Hapus"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <h2 className="text-base font-bold text-slate-900 mt-2">{p.judul}</h2>
              <p className="text-xs text-slate-700 leading-relaxed mt-2 whitespace-pre-line">
                {p.konten}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-500 gap-2">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-mono">{p.tanggal}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span>{p.penulis}</span>
                  </span>
                </div>
                <span className="text-sky-700 font-medium">PP Al-Ihsan Jrangoan</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add / Edit Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingPengumuman ? 'Edit Pengumuman' : 'Buat Pengumuman Baru'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Judul Pengumuman *</label>
                <input
                  type="text"
                  required
                  value={formData.judul}
                  onChange={(e) => setFormData({ ...formData, judul: e.target.value })}
                  placeholder="Contoh: Jadwal Ujian Ikhtibar Semester Ganjil..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Sasaran</label>
                  <select
                    value={formData.targetAudience}
                    onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Semua">Semua (Umum)</option>
                    <option value="Santri">Santri Saja</option>
                    <option value="Guru">Guru / Asatidz Saja</option>
                    <option value="Wali Santri">Wali Santri Saja</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kategori</label>
                  <select
                    value={formData.kategori}
                    onChange={(e) => setFormData({ ...formData, kategori: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Akademik">Akademik</option>
                    <option value="Kegiatan">Kegiatan</option>
                    <option value="Ujian Kitab">Ujian Kitab</option>
                    <option value="Libur Pondok">Libur Pondok</option>
                    <option value="Penting">Penting</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Isi Lengkap Pengumuman *</label>
                <textarea
                  rows={4}
                  required
                  value={formData.konten}
                  onChange={(e) => setFormData({ ...formData, konten: e.target.value })}
                  placeholder="Tuliskan isi detail warta, tanggal penting, atau arahan..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Penulis / Bagian</label>
                  <input
                    type="text"
                    value={formData.penulis}
                    onChange={(e) => setFormData({ ...formData, penulis: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tanggal</label>
                  <input
                    type="date"
                    value={formData.tanggal}
                    onChange={(e) => setFormData({ ...formData, tanggal: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="pinCheck"
                  checked={formData.isPinned}
                  onChange={(e) => setFormData({ ...formData, isPinned: e.target.checked })}
                  className="rounded text-sky-600 focus:ring-sky-500"
                />
                <label htmlFor="pinCheck" className="text-xs font-semibold text-slate-700 cursor-pointer">
                  Sematkan di bagian teratas (Pinned Announcement)
                </label>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Terbitkan Pengumuman
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
