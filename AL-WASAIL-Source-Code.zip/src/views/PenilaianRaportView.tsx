import React, { useState } from 'react';
import {
  Award,
  Search,
  Plus,
  Edit2,
  Trash2,
  Printer,
  FileText,
  X,
  BookOpen,
  CheckCircle2,
  Download,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { NilaiRaport, Santri } from '../types';

export const PenilaianRaportView: React.FC = () => {
  const { role } = useAuth();
  const [nilaiList, setNilaiList] = useState<NilaiRaport[]>(() => db.getNilai());
  const santriList = db.getSantri();
  const kitabList = db.getKitab();
  const kelasList = db.getKelas();
  const lembaga = db.getLembaga();

  // Filters
  const [selectedKelasId, setSelectedKelasId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSemester, setSelectedSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');

  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingNilai, setEditingNilai] = useState<NilaiRaport | null>(null);
  const [raportSantri, setRaportSantri] = useState<Santri | null>(null);

  // Form State
  const [formState, setFormState] = useState({
    santriId: santriList[0]?.id || '',
    kitabId: kitabList[0]?.id || '',
    semester: 'Ganjil' as 'Ganjil' | 'Genap',
    tahunAjaran: '1447-1448 H / 2026-2027 M',
    nilaiHafalan: 85,
    nilaiMembaca: 85,
    nilaiTarkibIrob: 90,
    nilaiMaknaPemahaman: 85,
    nilaiUjian: 88,
    catatanUstadz: 'Kemampuan analisis sintaksis metode Al-Wasail sangat baik.',
  });

  const refreshNilai = () => setNilaiList(db.getNilai());
  const canEdit = role === 'admin' || role === 'guru';

  const handleOpenAdd = () => {
    setEditingNilai(null);
    setFormState({
      santriId: santriList[0]?.id || '',
      kitabId: kitabList[0]?.id || '',
      semester: selectedSemester,
      tahunAjaran: '1447-1448 H / 2026-2027 M',
      nilaiHafalan: 85,
      nilaiMembaca: 85,
      nilaiTarkibIrob: 88,
      nilaiMaknaPemahaman: 84,
      nilaiUjian: 86,
      catatanUstadz: 'Pertahankan ketelitian dalam menguraikan i\'rob dan susunan kalimat.',
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (n: NilaiRaport) => {
    setEditingNilai(n);
    setFormState({
      santriId: n.santriId,
      kitabId: n.kitabId,
      semester: n.semester,
      tahunAjaran: n.tahunAjaran,
      nilaiHafalan: n.nilaiHafalan,
      nilaiMembaca: n.nilaiMembaca,
      nilaiTarkibIrob: n.nilaiTarkibIrob,
      nilaiMaknaPemahaman: n.nilaiMaknaPemahaman,
      nilaiUjian: n.nilaiUjian,
      catatanUstadz: n.catatanUstadz,
    });
    setIsFormOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const st = santriList.find((s) => s.id === formState.santriId);
    const kt = kitabList.find((k) => k.id === formState.kitabId);
    if (!st || !kt) return;

    if (editingNilai) {
      db.updateNilai(editingNilai.id, {
        santriId: st.id,
        santriNama: st.namaLengkap,
        kelasId: st.kelasId,
        namaKelas: st.namaKelas,
        kitabId: kt.id,
        namaKitab: kt.namaKitab,
        semester: formState.semester,
        tahunAjaran: formState.tahunAjaran,
        nilaiHafalan: Number(formState.nilaiHafalan),
        nilaiMembaca: Number(formState.nilaiMembaca),
        nilaiTarkibIrob: Number(formState.nilaiTarkibIrob),
        nilaiMaknaPemahaman: Number(formState.nilaiMaknaPemahaman),
        nilaiUjian: Number(formState.nilaiUjian),
        catatanUstadz: formState.catatanUstadz,
      });
    } else {
      db.createNilai({
        santriId: st.id,
        santriNama: st.namaLengkap,
        kelasId: st.kelasId,
        namaKelas: st.namaKelas,
        kitabId: kt.id,
        namaKitab: kt.namaKitab,
        semester: formState.semester,
        tahunAjaran: formState.tahunAjaran,
        nilaiHafalan: Number(formState.nilaiHafalan),
        nilaiMembaca: Number(formState.nilaiMembaca),
        nilaiTarkibIrob: Number(formState.nilaiTarkibIrob),
        nilaiMaknaPemahaman: Number(formState.nilaiMaknaPemahaman),
        nilaiUjian: Number(formState.nilaiUjian),
        catatanUstadz: formState.catatanUstadz,
      });
    }

    refreshNilai();
    setIsFormOpen(false);
  };

  const handleDelete = (id: string, namaKitab: string) => {
    if (confirm(`Hapus nilai mata pelajaran "${namaKitab}"?`)) {
      db.deleteNilai(id);
      refreshNilai();
    }
  };

  const filteredNilai = nilaiList.filter((n) => {
    const matchKelas = selectedKelasId === 'all' || n.kelasId === selectedKelasId;
    const matchSemester = n.semester === selectedSemester;
    const matchSearch =
      n.santriNama.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.namaKitab.toLowerCase().includes(searchQuery.toLowerCase());
    return matchKelas && matchSemester && matchSearch;
  });

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Award className="w-6 h-6 text-sky-600" />
            <span>Penilaian & Raport Digital Santri</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Evaluasi berkala hafalan, ketepatan tarkib & i'rob, baca kitab gundul, dan cetak raport resmi
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {canEdit && (
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Input Nilai Baru</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari nilai berdasarkan nama santri atau kitab..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800"
          />
        </div>

        <div className="flex items-center gap-2 shrink-0 w-full md:w-auto">
          <select
            value={selectedKelasId}
            onChange={(e) => setSelectedKelasId(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
          >
            <option value="all">Semua Kelas</option>
            {kelasList.map((k) => (
              <option key={k.id} value={k.id}>
                {k.namaKelas}
              </option>
            ))}
          </select>

          <select
            value={selectedSemester}
            onChange={(e) => setSelectedSemester(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 font-semibold"
          >
            <option value="Ganjil">Semester Ganjil</option>
            <option value="Genap">Semester Genap</option>
          </select>
        </div>
      </div>

      {/* Nilai Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Santri</th>
                <th className="py-3 px-4">Kelas</th>
                <th className="py-3 px-4">Kitab Kuning</th>
                <th className="py-3 px-4">Hafalan</th>
                <th className="py-3 px-4">Membaca</th>
                <th className="py-3 px-4">Tarkib I'rob</th>
                <th className="py-3 px-4">Pemahaman</th>
                <th className="py-3 px-4">Ujian</th>
                <th className="py-3 px-4">Nilai Akhir</th>
                <th className="py-3 px-4">Predikat</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredNilai.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-8 text-center text-slate-400">
                    Belum ada rekapan nilai untuk filter yang dipilih.
                  </td>
                </tr>
              ) : (
                filteredNilai.map((n) => (
                  <tr key={n.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">
                      <span className="font-bold text-slate-900 block">{n.santriNama}</span>
                      <button
                        onClick={() => {
                          const st = santriList.find((s) => s.id === n.santriId);
                          if (st) setRaportSantri(st);
                        }}
                        className="text-[11px] text-sky-600 hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <FileText className="w-3 h-3" />
                        <span>Lihat Raport Lengkap</span>
                      </button>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{n.namaKelas}</td>
                    <td className="py-3 px-4 font-semibold text-slate-800">{n.namaKitab}</td>
                    <td className="py-3 px-4 font-mono">{n.nilaiHafalan}</td>
                    <td className="py-3 px-4 font-mono">{n.nilaiMembaca}</td>
                    <td className="py-3 px-4 font-mono font-bold text-sky-700">{n.nilaiTarkibIrob}</td>
                    <td className="py-3 px-4 font-mono">{n.nilaiMaknaPemahaman}</td>
                    <td className="py-3 px-4 font-mono">{n.nilaiUjian}</td>
                    <td className="py-3 px-4 font-mono font-extrabold text-slate-900 text-sm">
                      {n.nilaiAkhir}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-50 text-sky-700 border border-sky-100">
                        {n.predikat}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {canEdit && (
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleOpenEdit(n)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50"
                            title="Edit Nilai"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(n.id, n.namaKitab)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                            title="Hapus Nilai"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Form Input / Edit Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingNilai ? 'Edit Nilai Kitab Santri' : 'Input Penilaian Kitab Kuning'}
              </h3>
              <button onClick={() => setIsFormOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pilih Santri *</label>
                <select
                  value={formState.santriId}
                  onChange={(e) => setFormState({ ...formState, santriId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {santriList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.namaLengkap} ({s.nis} - {s.namaKelas})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pilih Kitab Kuning *</label>
                <select
                  value={formState.kitabId}
                  onChange={(e) => setFormState({ ...formState, kitabId: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {kitabList.map((k) => (
                    <option key={k.id} value={k.id}>
                      {k.namaKitab} ({k.fanIlmu} - Tingkat {k.jenjang})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Semester</label>
                  <select
                    value={formState.semester}
                    onChange={(e) => setFormState({ ...formState, semester: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Ganjil">Semester Ganjil</option>
                    <option value="Genap">Semester Genap</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tahun Ajaran</label>
                  <input
                    type="text"
                    value={formState.tahunAjaran}
                    onChange={(e) => setFormState({ ...formState, tahunAjaran: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              {/* 5 Components of Al-Wasail Grading */}
              <div className="p-4 bg-sky-50/70 rounded-xl border border-sky-100 space-y-3">
                <span className="text-xs font-bold text-sky-900 block">Komponen Nilai Evaluasi (Skala 0-100):</span>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                      Hafalan Nadhom / Matan (20%)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      required
                      value={formState.nilaiHafalan}
                      onChange={(e) => setFormState({ ...formState, nilaiHafalan: Number(e.target.value) })}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                      Membaca & Fasahah (25%)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      required
                      value={formState.nilaiMembaca}
                      onChange={(e) => setFormState({ ...formState, nilaiMembaca: Number(e.target.value) })}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                      Tarkib & I'rob Al-Wasail (30%)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      required
                      value={formState.nilaiTarkibIrob}
                      onChange={(e) => setFormState({ ...formState, nilaiTarkibIrob: Number(e.target.value) })}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                      Makna & Murad (15%)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      required
                      value={formState.nilaiMaknaPemahaman}
                      onChange={(e) => setFormState({ ...formState, nilaiMaknaPemahaman: Number(e.target.value) })}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                      Ujian Ikhtibar Semester (10%)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      required
                      value={formState.nilaiUjian}
                      onChange={(e) => setFormState({ ...formState, nilaiUjian: Number(e.target.value) })}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Catatan & Masukan Ustadz Pengampu</label>
                <textarea
                  rows={2}
                  value={formState.catatanUstadz}
                  onChange={(e) => setFormState({ ...formState, catatanUstadz: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                >
                  Simpan Nilai
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Raport Digital Modal (Cetak Resmi) */}
      {raportSantri && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-300 my-8">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between no-print">
              <span className="text-xs font-bold flex items-center gap-2">
                <FileText className="w-4 h-4 text-sky-400" />
                <span>Pratinjau Raport Pendidikan Digital</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak Raport</span>
                </button>
                <button
                  onClick={() => setRaportSantri(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Raport Document Area */}
            <div className="p-8 space-y-6 text-slate-900 print:p-0">
              {/* Kop Pesantren Resmi */}
              <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
                <img
                  src={lembaga.logoUrl}
                  alt="Logo AL-WASAIL"
                  className="w-16 h-16 rounded-full border border-slate-300 object-cover"
                />
                <div className="text-center flex-1 px-4">
                  <h2 className="text-lg font-extrabold uppercase tracking-wide">
                    {lembaga.namaLengkap}
                  </h2>
                  <p className="text-xs font-semibold text-sky-800">
                    Sistem Pembelajaran Kitab Kuning Salafiyah: "{lembaga.nama}" ({lembaga.slogan})
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    Desa {lembaga.desa}, Kec. {lembaga.kecamatan}, Kab. {lembaga.kabupaten}, {lembaga.provinsi} | NSPP: {lembaga.nspp}
                  </p>
                </div>
                <div className="w-16 text-right">
                  <span className="text-[10px] font-mono text-slate-400">RAPORT 1447H</span>
                </div>
              </div>

              {/* Biodata Santri */}
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div className="space-y-1">
                  <div><strong>Nama Santri:</strong> {raportSantri.namaLengkap}</div>
                  <div><strong>Nomor Induk (NIS):</strong> {raportSantri.nis}</div>
                  <div><strong>Tingkat / Jenjang:</strong> Marhalah {raportSantri.jenjang}</div>
                </div>
                <div className="space-y-1">
                  <div><strong>Rombel Kelas:</strong> {raportSantri.namaKelas}</div>
                  <div><strong>Wali Santri:</strong> {raportSantri.namaWali}</div>
                  <div><strong>Tahun Pelajaran:</strong> 1447-1448 H / 2026-2027 M</div>
                </div>
              </div>

              {/* Table Nilai */}
              <table className="w-full text-left text-xs border border-slate-300">
                <thead className="bg-slate-100 border-b border-slate-300 font-bold">
                  <tr>
                    <th className="p-2 border-r border-slate-300">No</th>
                    <th className="p-2 border-r border-slate-300">Mata Kitab Kuning</th>
                    <th className="p-2 border-r border-slate-300 text-center">Hafalan</th>
                    <th className="p-2 border-r border-slate-300 text-center">Qira'ah</th>
                    <th className="p-2 border-r border-slate-300 text-center">Tarkib Al-Wasail</th>
                    <th className="p-2 border-r border-slate-300 text-center">Pemahaman</th>
                    <th className="p-2 border-r border-slate-300 text-center">Nilai Akhir</th>
                    <th className="p-2 text-center">Predikat</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {nilaiList
                    .filter((n) => n.santriId === raportSantri.id)
                    .map((n, idx) => (
                      <tr key={n.id}>
                        <td className="p-2 border-r border-slate-300 text-center">{idx + 1}</td>
                        <td className="p-2 border-r border-slate-300 font-semibold">{n.namaKitab}</td>
                        <td className="p-2 border-r border-slate-300 text-center font-mono">{n.nilaiHafalan}</td>
                        <td className="p-2 border-r border-slate-300 text-center font-mono">{n.nilaiMembaca}</td>
                        <td className="p-2 border-r border-slate-300 text-center font-mono font-bold text-sky-800">{n.nilaiTarkibIrob}</td>
                        <td className="p-2 border-r border-slate-300 text-center font-mono">{n.nilaiMaknaPemahaman}</td>
                        <td className="p-2 border-r border-slate-300 text-center font-mono font-bold">{n.nilaiAkhir}</td>
                        <td className="p-2 text-center font-bold text-sky-900">{n.predikat}</td>
                      </tr>
                    ))}
                </tbody>
              </table>

              {/* Evaluasi Al-Wasail Note */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
                <span className="font-bold text-slate-800">Capaian & Rekomendasi Metode AL-WASAIL:</span>
                <p className="text-slate-600 italic">
                  "{raportSantri.catatanMetodeAlWasail}"
                </p>
              </div>

              {/* Signature Columns */}
              <div className="grid grid-cols-3 text-center text-xs pt-8">
                <div>
                  <p className="text-slate-500">Wali Santri</p>
                  <div className="h-16" />
                  <p className="font-bold underline">{raportSantri.namaWali}</p>
                </div>
                <div>
                  <p className="text-slate-500">Wali Kelas Pengampu</p>
                  <div className="h-16" />
                  <p className="font-bold underline">Ustadz Pengampu Kelas</p>
                </div>
                <div>
                  <p className="text-slate-500">Pengasuh Pesantren</p>
                  <div className="h-16" />
                  <p className="font-bold underline">{lembaga.pengasuh}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
