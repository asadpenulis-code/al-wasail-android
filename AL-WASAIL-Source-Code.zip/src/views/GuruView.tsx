import React, { useState } from 'react';
import {
  GraduationCap,
  Search,
  Plus,
  Edit2,
  Trash2,
  Phone,
  Mail,
  MapPin,
  BookOpen,
  Calendar,
  X,
  CheckCircle2,
} from 'lucide-react';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { Guru } from '../types';

export const GuruView: React.FC = () => {
  const { role } = useAuth();
  const [guruList, setGuruList] = useState<Guru[]>(() => db.getGuru());
  const kelasList = db.getKelas();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingGuru, setEditingGuru] = useState<Guru | null>(null);
  const [selectedGuru, setSelectedGuru] = useState<Guru | null>(null);

  const [formData, setFormData] = useState<Omit<Guru, 'id'>>({
    nip: '',
    namaLengkap: '',
    gelar: '',
    spesialisasiKitab: '',
    noHp: '',
    email: '',
    alamat: '',
    kelasAmpu: [],
    statusKeaktifan: 'Aktif',
    tanggalMulaiTugas: '2020-01-01',
  });

  const refreshList = () => {
    setGuruList(db.getGuru());
  };

  const handleOpenAdd = () => {
    setEditingGuru(null);
    setFormData({
      nip: `G-${new Date().getFullYear()}${String(guruList.length + 1).padStart(3, '0')}`,
      namaLengkap: '',
      gelar: 'S.Pd.I',
      spesialisasiKitab: 'Metode Al-Wasail Nahwu & Shorof',
      noHp: '081234567890',
      email: '',
      alamat: 'Jrangoan, Sampang',
      kelasAmpu: [kelasList[0]?.namaKelas || 'Tingkat Ula - Kelas A (Putra)'],
      statusKeaktifan: 'Aktif',
      tanggalMulaiTugas: new Date().toISOString().split('T')[0],
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (g: Guru) => {
    setEditingGuru(g);
    setFormData({
      nip: g.nip,
      namaLengkap: g.namaLengkap,
      gelar: g.gelar,
      spesialisasiKitab: g.spesialisasiKitab,
      noHp: g.noHp,
      email: g.email,
      alamat: g.alamat,
      kelasAmpu: g.kelasAmpu,
      statusKeaktifan: g.statusKeaktifan,
      tanggalMulaiTugas: g.tanggalMulaiTugas,
    });
    setIsFormOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingGuru) {
      db.updateGuru(editingGuru.id, formData);
    } else {
      db.createGuru(formData);
    }
    refreshList();
    setIsFormOpen(false);
  };

  const handleDelete = (id: string, nama: string) => {
    if (confirm(`Apakah Anda yakin ingin menghapus data ustadz "${nama}"?`)) {
      db.deleteGuru(id);
      refreshList();
    }
  };

  const canEdit = role === 'admin';

  const filteredGuru = guruList.filter((g) => {
    const matchSearch =
      g.namaLengkap.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.spesialisasiKitab.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.nip.toLowerCase().includes(searchQuery.toLowerCase());
    const matchStatus = filterStatus === 'all' || g.statusKeaktifan === filterStatus;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-sky-600" />
            <span>Dewan Guru & Asatidz PP Al-Ihsan Jrangoan</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Data pengajar kitab kuning, spesialisasi fan ilmu, dan pembimbing Metode Al-Wasail
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Asatidz</span>
          </button>
        )}
      </div>

      {/* Search and Filter */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari asatidz berdasarkan nama, NIP, atau spesialisasi kitab..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-800"
          />
        </div>

        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="bg-slate-50 border border-slate-200 rounded-xl text-xs py-2 px-3 text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 shrink-0 w-full sm:w-auto"
        >
          <option value="all">Semua Status Keaktifan</option>
          <option value="Aktif">Aktif Mengajar</option>
          <option value="Cuti">Cuti</option>
          <option value="Purna">Purna Tugas</option>
        </select>
      </div>

      {/* Guru Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredGuru.map((g) => (
          <div
            key={g.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-sky-300 transition-all p-5 flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-sky-100 text-sky-800 font-bold text-base flex items-center justify-center shrink-0 border border-sky-200">
                    {g.namaLengkap.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{g.namaLengkap}, {g.gelar}</h3>
                    <span className="text-[11px] text-slate-500 font-mono block">NIP: {g.nip}</span>
                  </div>
                </div>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                    g.statusKeaktifan === 'Aktif'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {g.statusKeaktifan}
                </span>
              </div>

              <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                <div className="flex items-center gap-2 text-slate-700">
                  <BookOpen className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                  <span className="font-semibold">{g.spesialisasiKitab}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                  <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Pengabdian sejak {g.tanggalMulaiTugas}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{g.alamat}</span>
                </div>
              </div>

              <div className="mt-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Kelas yang Diampu:
                </span>
                <div className="flex flex-wrap gap-1">
                  {g.kelasAmpu.map((kls, idx) => (
                    <span key={idx} className="text-[10px] font-medium bg-sky-50 text-sky-700 px-2 py-0.5 rounded border border-sky-100">
                      {kls}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <a
                href={`https://wa.me/${g.noHp.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 hover:text-emerald-700"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>

              {canEdit && (
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(g)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                    title="Edit Asatidz"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(g.id, g.namaLengkap)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Hapus Asatidz"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 my-8">
            <div className="p-5 bg-sky-700 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingGuru ? 'Edit Data Asatidz' : 'Tambah Asatidz Baru'}
              </h3>
              <button onClick={() => setIsFormOpen(false)} className="text-sky-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap *</label>
                <input
                  type="text"
                  required
                  value={formData.namaLengkap}
                  onChange={(e) => setFormData({ ...formData, namaLengkap: e.target.value })}
                  placeholder="Contoh: Ustadz Ahmad Fauzi"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Gelar</label>
                  <input
                    type="text"
                    value={formData.gelar}
                    onChange={(e) => setFormData({ ...formData, gelar: e.target.value })}
                    placeholder="S.Pd.I / M.Ag / Lc."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">NIP *</label>
                  <input
                    type="text"
                    required
                    value={formData.nip}
                    onChange={(e) => setFormData({ ...formData, nip: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Spesialisasi Kitab / Fan Ilmu *</label>
                <input
                  type="text"
                  required
                  value={formData.spesialisasiKitab}
                  onChange={(e) => setFormData({ ...formData, spesialisasiKitab: e.target.value })}
                  placeholder="Contoh: Nahwu Imrithi & Fathul Qorib"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nomor WhatsApp *</label>
                  <input
                    type="text"
                    required
                    value={formData.noHp}
                    onChange={(e) => setFormData({ ...formData, noHp: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status Keaktifan</label>
                  <select
                    value={formData.statusKeaktifan}
                    onChange={(e) => setFormData({ ...formData, statusKeaktifan: e.target.value as 'Aktif' | 'Cuti' | 'Purna' })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Aktif">Aktif</option>
                    <option value="Cuti">Cuti</option>
                    <option value="Purna">Purna Tugas</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email Resmi</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="nama@alihsan-jrangoan.sch.id"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Alamat Asal</label>
                <input
                  type="text"
                  value={formData.alamat}
                  onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tanggal Mulai Tugas</label>
                <input
                  type="date"
                  value={formData.tanggalMulaiTugas}
                  onChange={(e) => setFormData({ ...formData, tanggalMulaiTugas: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold shadow-xs"
                >
                  Simpan Asatidz
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
