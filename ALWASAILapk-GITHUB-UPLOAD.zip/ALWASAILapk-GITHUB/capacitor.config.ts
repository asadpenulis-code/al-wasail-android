export interface CapacitorConfig {
  appId: string;
  appName: string;
  webDir: string;
  server?: {
    androidScheme?: string;
    cleartext?: boolean;
    url?: string;
  };
  plugins?: Record<string, any>;
}

const config: CapacitorConfig = {
  appId: 'id.ponpes.alihsanjrangoan.alwasail',
  appName: 'AL-WASĀ’IL',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#0B1B3D",
      showSpinner: false,
      androidSplashResourceName: "splash"
    }
  }
};

export default config;
