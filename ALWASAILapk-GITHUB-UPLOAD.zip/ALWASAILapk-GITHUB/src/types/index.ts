/**
 * AL-WASĀ’IL - Data Type Definitions
 * Lembaga Pendidikan Al-Wasā'il - PP Al-Ihsan Jrangoan
 */

export type UserRole = 'admin' | 'guru' | 'santri' | 'kepala';

export interface UserAccount {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  avatar?: string;
  relatedId?: string; // santriId or guruId
}

export type StatusSantri = 'Aktif' | 'Tidak Aktif' | 'Lulus';
export type Gender = 'L' | 'P';

export interface RiwayatKelas {
  kelasId: string;
  kelasNama: string;
  tahunAjaran: string;
  tanggalPindah: string;
  keterangan?: string;
}

export interface Santri {
  id: string;
  nis: string;
  nama: string;
  gender: Gender;
  tempatLahir: string;
  tanggalLahir: string;
  alamat: string;
  namaAyah: string;
  namaIbu: string;
  noHpWali: string;
  lembagaAsal: string;
  tahunMasuk: string;
  status: StatusSantri;
  kelasId: string;
  foto?: string;
  catatanKhusus?: string;
  riwayatKelas?: RiwayatKelas[];
}

export interface Guru {
  id: string;
  nig: string;
  nama: string;
  tempatLahir: string;
  tanggalLahir: string;
  alamat: string;
  noHp: string;
  pendidikanTerakhir: string;
  tahunMulaiMengajar: string;
  mapel: string[];
  kelasAmpu: string[];
  waliKelasUntuk?: string; // kelasId if any
  status: 'Aktif' | 'Non-Aktif';
  foto?: string;
  riwayatMengajar?: string;
}

export interface Kelas {
  id: string;
  nama: string; // 'I’dadiyah', 'Takhassus A', 'Takhassus B', 'Takhassus C', etc.
  waliKelasId: string;
  tahunAjaran: string;
  keterangan?: string;
}

export type StatusKehadiran = 'Hadir' | 'Sakit' | 'Izin' | 'Alfa';

export interface KehadiranSantriItem {
  santriId: string;
  status: StatusKehadiran;
  keterangan?: string;
}

export interface AbsensiSesi {
  id: string;
  tanggal: string; // YYYY-MM-DD
  kelasId: string;
  guruId: string;
  guruNama: string;
  records: KehadiranSantriItem[];
  catatan?: string;
  createdAt: string;
}

export type PredikatNilai = 'Jayyid' | 'Mutawassith' | 'Rodi';

export interface EvaluasiBidang {
  bidang: 'Nahwu' | 'Sharraf dan I‘lal' | 'Lafadz dan makna' | 'Kemampuan membaca kitab' | 'Hafalan' | 'Muthalaah' | 'Kedisiplinan' | 'Akhlak';
  predikat: PredikatNilai;
  nilaiAngka: number; // 0-100
  catatan?: string;
}

export interface PenilaianSantri {
  id: string;
  santriId: string;
  kelasId: string;
  periode: string; // e.g. "Semester Ganjil 1446-1447 H" or "Evaluasi Tengah Semester"
  tanggal: string;
  evaluasi: EvaluasiBidang[];
  catatanUmum: string;
  perkembanganKemampuan: string;
  guruId: string;
  guruNama: string;
}

export interface JurnalGuru {
  id: string;
  guruId: string;
  guruNama: string;
  kelasId: string;
  kelasNama: string;
  tanggal: string; // YYYY-MM-DD
  materiDiajarkan: string;
  targetPembelajaran: string;
  materiSelesai: string;
  kendala: string;
  catatanEvaluasi: string;
  statusVerifikasi: 'Terverifikasi' | 'Menunggu';
}

export interface ProgresPembelajaranSantri {
  id: string;
  santriId: string;
  tahapanAktif: string; // 'Marhalah 1 (Shufhah 1–15)', 'Marhalah 2 (Shufhah 16–30)', 'Marhalah 3 (Tarkib & Kitab Gundul)'
  materiSelesai: string[];
  targetHarian: string;
  targetHafalan: string;
  kesulitanKedudukanKalimat: boolean; // Flag if student has difficulty with sentence position
  kelancaranMembacaKitab: 'Sangat Baik' | 'Baik' | 'Cukup' | 'Kurang';
  catatanKesulitan: string;
  rekomendasiBimbingan: string;
  terakhirDiperbarui: string;
}

export interface PesertaTashih {
  id: string;
  nomorPeserta: string;
  santriId?: string;
  nama: string;
  lembagaAsal: string; // e.g. 'PP Al-Ihsan Jrangoan' or external branch
  kelasAsal: string;
  gelombangUjian: string;
  ruangUjian: string;
  tanggalUjian: string;
  penguji: string;
  nilaiNahwu: number;
  nilaiSharraf: number;
  nilaiMembacaKitab: number;
  catatanPenguji: string;
  statusLulus: 'Lulus' | 'Tidak Lulus' | 'Belum Ujian';
  predikat?: 'Mumtaz' | 'Jayyid Jiddan' | 'Jayyid' | 'Rasib';
  nomorSyahadah?: string;
}

export interface Pengumuman {
  id: string;
  judul: string;
  kategori: 'Kegiatan' | 'Jadwal Ujian' | 'Rapat Guru' | 'Pengumuman Santri' | 'Wali Santri' | 'Agenda Lembaga';
  tanggal: string;
  isi: string;
  target: 'Semua' | 'Guru' | 'Santri' | 'Wali';
  penulis: string;
  isPenting?: boolean;
}

export interface PengaturanLembaga {
  namaLembaga: string;
  naungan: string;
  sloganArab: string;
  sloganIndo: string;
  alamatLembaga: string;
  telepon: string;
  email: string;
  namaPimpinan: string;
  kkmTashih: number; // default 70
  logoUrl?: string;
  tahunAjaranAktif: string;
}

export interface DatabaseState {
  version: string;
  lastUpdated: string;
  pengaturan: PengaturanLembaga;
  santri: Santri[];
  guru: Guru[];
  kelas: Kelas[];
  absensi: AbsensiSesi[];
  penilaian: PenilaianSantri[];
  jurnal: JurnalGuru[];
  progres: ProgresPembelajaranSantri[];
  tashih: PesertaTashih[];
  pengumuman: Pengumuman[];
}
