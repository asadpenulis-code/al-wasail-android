/**
 * AL-WASĀ’IL - Local & Persistent Database Service
 * Lembaga Pendidikan Al-Wasā'il - PP Al-Ihsan Jrangoan
 */

import { DatabaseState, Santri, Guru, Kelas, AbsensiSesi, PenilaianSantri, JurnalGuru, ProgresPembelajaranSantri, PesertaTashih, Pengumuman, PengaturanLembaga } from '../types';

const STORAGE_KEY = 'alwasail_db_v1';

export const initialPengaturan: PengaturanLembaga = {
  namaLembaga: "LEMBAGA PENDIDIKAN AL-WASĀ’IL",
  naungan: "Pondok Pesantren Al-Ihsan Jrangoan",
  sloganArab: "«الْوَسَائِلُ – الطَّرِيْقَةُ السَّهْلَةُ لِقِرَاءَةِ الْكُتُبِ»",
  sloganIndo: "Metode Mudah Membaca Kitab Kuning",
  alamatLembaga: "Jl. Raya Jrangoan, Kec. Omben, Kab. Sampang, Jawa Timur 69261",
  telepon: "0812-3456-7890",
  email: "alwasail.alihsan@gmail.com",
  namaPimpinan: "KH. Fauzi Ihsan, M.Pd.I",
  kkmTashih: 70,
  tahunAjaranAktif: "1446-1447 H / 2025-2026 M",
};

export const initialKelas: Kelas[] = [
  {
    id: "k-1",
    nama: "I’dadiyah",
    waliKelasId: "g-1",
    tahunAjaran: "1446-1447 H / 2025-2026 M",
    keterangan: "Kelas Pengantar & Dasar Kaidah Al-Wasā'il (Shufhah 1–15)"
  },
  {
    id: "k-2",
    nama: "Takhassus A",
    waliKelasId: "g-2",
    tahunAjaran: "1446-1447 H / 2025-2026 M",
    keterangan: "Kelas Pendalaman Tarkib & Kedudukan Kalimat (Shufhah 16–30)"
  },
  {
    id: "k-3",
    nama: "Takhassus B",
    waliKelasId: "g-3",
    tahunAjaran: "1446-1447 H / 2025-2026 M",
    keterangan: "Kelas Praktik Membaca Kitab Yāqūtun Nafīs & Sharraf Tingkat Menengah"
  },
  {
    id: "k-4",
    nama: "Takhassus C",
    waliKelasId: "g-4",
    tahunAjaran: "1446-1447 H / 2025-2026 M",
    keterangan: "Kelas Tingkat Lanjut & Persiapan Tashih Nasional"
  }
];

export const initialGuru: Guru[] = [
  {
    id: "g-1",
    nig: "NIG-2019-01",
    nama: "Ust. Ahmad Ghazali, S.Pd.I",
    tempatLahir: "Sampang",
    tanggalLahir: "1988-06-14",
    alamat: "Jl. Ponpes Jrangoan, Omben, Sampang",
    noHp: "081234567801",
    pendidikanTerakhir: "Ma'had Aly Nurul Jadid / S1 PAI",
    tahunMulaiMengajar: "2019",
    mapel: ["Nahwu Al-Wasā'il", "Dasar Tarkib Shufhah 1-15"],
    kelasAmpu: ["k-1", "k-2"],
    waliKelasUntuk: "k-1",
    status: "Aktif",
    riwayatMengajar: "Guru senior Al-Wasā'il sejak angkatan perintis, pemegang sanad tashih kitab kuning."
  },
  {
    id: "g-2",
    nig: "NIG-2020-02",
    nama: "Ust. Muhammad Kholil, M.H",
    tempatLahir: "Bangkalan",
    tanggalLahir: "1991-09-22",
    alamat: "Blega, Kab. Bangkalan",
    noHp: "081234567802",
    pendidikanTerakhir: "Ma'had Aly PP Sukorejo / S2 Hukum Islam",
    tahunMulaiMengajar: "2020",
    mapel: ["Kitab Yāqūtun Nafīs", "Kedudukan Kalimat & I'rab"],
    kelasAmpu: ["k-2", "k-3"],
    waliKelasUntuk: "k-2",
    status: "Aktif",
    riwayatMengajar: "Instruktur bimbingan intensif tarkib Al-Wasā'il."
  },
  {
    id: "g-3",
    nig: "NIG-2021-03",
    nama: "Ust. Abdul Wahid Al-Hafidz",
    tempatLahir: "Pamekasan",
    tanggalLahir: "1993-03-10",
    alamat: "Proppo, Kab. Pamekasan",
    noHp: "081234567803",
    pendidikanTerakhir: "Pondok Pesantren Sidogiri Pasuruan",
    tahunMulaiMengajar: "2021",
    mapel: ["Sharraf & I'lal 19 Kaidah", "Hafalan Nadzom"],
    kelasAmpu: ["k-3", "k-4"],
    waliKelasUntuk: "k-3",
    status: "Aktif",
    riwayatMengajar: "Spesialis kaidah I'lal dan morfo-sintaksis Arab Al-Wasā'il."
  },
  {
    id: "g-4",
    nig: "NIG-2022-04",
    nama: "Ust. Hasan Basri, S.Hum",
    tempatLahir: "Sumenep",
    tanggalLahir: "1995-11-05",
    alamat: "Guluk-Guluk, Kab. Sumenep",
    noHp: "081234567804",
    pendidikanTerakhir: "UIN Sunan Kalijaga Yogyakarta / BSA",
    tahunMulaiMengajar: "2022",
    mapel: ["Muthalaah Kitab Kuning", "Persiapan Ujian Tashih"],
    kelasAmpu: ["k-4"],
    waliKelasUntuk: "k-4",
    status: "Aktif",
    riwayatMengajar: "Musahhih penguji kelulusan membaca kitab kuning tanpa harakat."
  }
];

export const initialSantri: Santri[] = [
  {
    id: "s-1",
    nis: "20240101",
    nama: "Muhammad Faiz Abdullah",
    gender: "L",
    tempatLahir: "Sampang",
    tanggalLahir: "2008-05-12",
    alamat: "Dusun Jrangoan Timur, Desa Jrangoan, Kec. Omben",
    namaAyah: "H. Abdullah Munir",
    namaIbu: "Hj. Siti Rohmah",
    noHpWali: "081330998811",
    lembagaAsal: "PP Al-Ihsan Jrangoan - Pusat",
    tahunMasuk: "2024",
    status: "Aktif",
    kelasId: "k-2",
    catatanKhusus: "Sangat antusias pada Nahwu, perlu penguatan pada I'lal bina' naqish.",
    riwayatKelas: [
      {
        kelasId: "k-1",
        kelasNama: "I’dadiyah",
        tahunAjaran: "2024-2025",
        tanggalPindah: "2024-07-15",
        keterangan: "Pendaftaran awal dan lulus matrikulasi Shufhah 1-15"
      },
      {
        kelasId: "k-2",
        kelasNama: "Takhassus A",
        tahunAjaran: "1446-1447 H / 2025-2026 M",
        tanggalPindah: "2025-01-10",
        keterangan: "Kenaikan kelas ke Takhassus A (Tarkib Lanjutan)"
      }
    ]
  },
  {
    id: "s-2",
    nis: "20240102",
    nama: "Ahmad Zainuri Al-Maduri",
    gender: "L",
    tempatLahir: "Bangkalan",
    tanggalLahir: "2008-08-20",
    alamat: "Desa Lombang, Kec. Blega, Kab. Bangkalan",
    namaAyah: "K.H. Zainal Arifin",
    namaIbu: "Ny. Halimah",
    noHpWali: "081231887722",
    lembagaAsal: "Cabang Bangkalan",
    tahunMasuk: "2024",
    status: "Aktif",
    kelasId: "k-2",
    catatanKhusus: "Kemampuan membaca kitab sangat lancar, tarkib fa'il dan maf'ul tuntas.",
    riwayatKelas: [
      {
        kelasId: "k-2",
        kelasNama: "Takhassus A",
        tahunAjaran: "1446-1447 H / 2025-2026 M",
        tanggalPindah: "2024-07-20",
        keterangan: "Penempatan langsung Takhassus A hasil seleksi awal"
      }
    ]
  },
  {
    id: "s-3",
    nis: "20240103",
    nama: "Fathur Rohman Jrangoan",
    gender: "L",
    tempatLahir: "Sampang",
    tanggalLahir: "2009-01-15",
    alamat: "Jl. Poros Karang Penang, Omben, Sampang",
    namaAyah: "Ust. Miftah",
    namaIbu: "Fatimah",
    noHpWali: "081987654321",
    lembagaAsal: "PP Al-Ihsan Jrangoan - Pusat",
    tahunMasuk: "2024",
    status: "Aktif",
    kelasId: "k-1",
    catatanKhusus: "Masih sering tertukar antara fa'il dan naibul fa'il saat membaca kalimat majhul.",
    riwayatKelas: [
      {
        kelasId: "k-1",
        kelasNama: "I’dadiyah",
        tahunAjaran: "1446-1447 H / 2025-2026 M",
        tanggalPindah: "2024-07-15",
        keterangan: "Kelas Dasar Kaidah"
      }
    ]
  },
  {
    id: "s-4",
    nis: "20230045",
    nama: "Mochammad Syamsul Huda",
    gender: "L",
    tempatLahir: "Pamekasan",
    tanggalLahir: "2007-10-04",
    alamat: "Desa Larangan, Kab. Pamekasan",
    namaAyah: "H. Subhan",
    namaIbu: "Hj. Mariyah",
    noHpWali: "081233445566",
    lembagaAsal: "Cabang Pamekasan",
    tahunMasuk: "2023",
    status: "Aktif",
    kelasId: "k-3",
    catatanKhusus: "Muthalaah tekun, calon peserta tashih gelombang berikutnya.",
    riwayatKelas: [
      {
        kelasId: "k-2",
        kelasNama: "Takhassus A",
        tahunAjaran: "2023-2024",
        tanggalPindah: "2023-07-12",
        keterangan: "Lulus Shufhah 1-30"
      },
      {
        kelasId: "k-3",
        kelasNama: "Takhassus B",
        tahunAjaran: "1446-1447 H / 2025-2026 M",
        tanggalPindah: "2024-07-10",
        keterangan: "Praktik Kitab Yāqūtun Nafīs"
      }
    ]
  },
  {
    id: "s-5",
    nis: "20230012",
    nama: "Lukman Hakim As-Samfani",
    gender: "L",
    tempatLahir: "Sampang",
    tanggalLahir: "2007-02-18",
    alamat: "Jl. Makboel, Sampang Kota",
    namaAyah: "H. Abdul Manan",
    namaIbu: "Hj. Ruqayyah",
    noHpWali: "087788990011",
    lembagaAsal: "PP Al-Ihsan Jrangoan - Pusat",
    tahunMasuk: "2023",
    status: "Aktif",
    kelasId: "k-4",
    catatanKhusus: "Sudah khatam tashih internal dengan predikat Jayyid Jiddan.",
    riwayatKelas: [
      {
        kelasId: "k-3",
        kelasNama: "Takhassus B",
        tahunAjaran: "2023-2024",
        tanggalPindah: "2023-07-10",
        keterangan: "Praktek Baca Kitab"
      },
      {
        kelasId: "k-4",
        kelasNama: "Takhassus C",
        tahunAjaran: "1446-1447 H / 2025-2026 M",
        tanggalPindah: "2024-07-10",
        keterangan: "Kelas Khusus Tashih"
      }
    ]
  },
  {
    id: "s-6",
    nis: "20240106",
    nama: "Nurul Aini Zulfah",
    gender: "P",
    tempatLahir: "Sumenep",
    tanggalLahir: "2008-12-03",
    alamat: "Desa Parsanga, Kab. Sumenep",
    namaAyah: "K. Ahmad Basyir",
    namaIbu: "Umi Kulsum",
    noHpWali: "085233112233",
    lembagaAsal: "Cabang Sumenep",
    tahunMasuk: "2024",
    status: "Aktif",
    kelasId: "k-1",
    catatanKhusus: "Hafalan nadzom dan kaidah Nahwu sangat kuat.",
    riwayatKelas: [
      {
        kelasId: "k-1",
        kelasNama: "I’dadiyah",
        tahunAjaran: "1446-1447 H / 2025-2026 M",
        tanggalPindah: "2024-07-15",
        keterangan: "Siswa Baru I'dadiyah Putri"
      }
    ]
  },
  {
    id: "s-7",
    nis: "20240107",
    nama: "Siti Masithah",
    gender: "P",
    tempatLahir: "Sampang",
    tanggalLahir: "2009-04-10",
    alamat: "Desa Kamoning, Sampang",
    namaAyah: "M. Thohir",
    namaIbu: "Solihah",
    noHpWali: "087855667788",
    lembagaAsal: "PP Al-Ihsan Jrangoan - Pusat",
    tahunMasuk: "2024",
    status: "Aktif",
    kelasId: "k-2",
    catatanKhusus: "Perlu bimbingan intensif pada materi tarkib Hal dan Tamyiz.",
    riwayatKelas: [
      {
        kelasId: "k-2",
        kelasNama: "Takhassus A",
        tahunAjaran: "1446-1447 H / 2025-2026 M",
        tanggalPindah: "2024-07-15",
        keterangan: "Kelas Takhassus A Putri"
      }
    ]
  },
  {
    id: "s-8",
    nis: "20220008",
    nama: "Miftahul Arifin",
    gender: "L",
    tempatLahir: "Surabaya",
    tanggalLahir: "2006-03-25",
    alamat: "Ampel Denta, Surabaya",
    namaAyah: "H. Syukur",
    namaIbu: "Hj. Wardah",
    noHpWali: "081299887766",
    lembagaAsal: "Cabang Surabaya",
    tahunMasuk: "2022",
    status: "Lulus",
    kelasId: "k-4",
    catatanKhusus: "Lulus Tashih dengan Predikat Mumtaz (Ijazah Terbit).",
    riwayatKelas: [
      {
        kelasId: "k-4",
        kelasNama: "Takhassus C",
        tahunAjaran: "2023-2024",
        tanggalPindah: "2024-06-25",
        keterangan: "Dinyatakan Lulus Ujian Tashih"
      }
    ]
  }
];

export const initialAbsensi: AbsensiSesi[] = [
  {
    id: "abs-01",
    tanggal: "2026-11-08",
    kelasId: "k-2",
    guruId: "g-2",
    guruNama: "Ust. Muhammad Kholil, M.H",
    records: [
      { santriId: "s-1", status: "Hadir" },
      { santriId: "s-2", status: "Hadir" },
      { santriId: "s-7", status: "Izin", keterangan: "Keperluan keluarga di rumah" }
    ],
    catatan: "Kajian fasal syarat shalat tuntas.",
    createdAt: "2026-11-08T08:00:00Z"
  },
  {
    id: "abs-02",
    tanggal: "2026-11-09",
    kelasId: "k-2",
    guruId: "g-2",
    guruNama: "Ust. Muhammad Kholil, M.H",
    records: [
      { santriId: "s-1", status: "Hadir" },
      { santriId: "s-2", status: "Hadir" },
      { santriId: "s-7", status: "Hadir" }
    ],
    catatan: "Praktik i'rab kedudukan maf'ul fih dan mutlaq.",
    createdAt: "2026-11-09T08:00:00Z"
  },
  {
    id: "abs-03",
    tanggal: "2026-11-09",
    kelasId: "k-1",
    guruId: "g-1",
    guruNama: "Ust. Ahmad Ghazali, S.Pd.I",
    records: [
      { santriId: "s-3", status: "Alfa", keterangan: "Tidak masuk tanpa keterangan" },
      { santriId: "s-6", status: "Hadir" }
    ],
    catatan: "Materi tanda I'rab rofa' (Dhammah, Wawu, Alif, Nun).",
    createdAt: "2026-11-09T08:30:00Z"
  },
  {
    id: "abs-04",
    tanggal: "2026-11-07",
    kelasId: "k-1",
    guruId: "g-1",
    guruNama: "Ust. Ahmad Ghazali, S.Pd.I",
    records: [
      { santriId: "s-3", status: "Alfa", keterangan: "Alfa hari ke-2" },
      { santriId: "s-6", status: "Hadir" }
    ],
    catatan: "Pengenalan tanda isim dan fi'il.",
    createdAt: "2026-11-07T08:30:00Z"
  },
  {
    id: "abs-05",
    tanggal: "2026-11-06",
    kelasId: "k-1",
    guruId: "g-1",
    guruNama: "Ust. Ahmad Ghazali, S.Pd.I",
    records: [
      { santriId: "s-3", status: "Alfa", keterangan: "Alfa hari ke-3 (Perlu pemanggilan wali)" },
      { santriId: "s-6", status: "Hadir" }
    ],
    catatan: "Pengulangan materi shufhah 8.",
    createdAt: "2026-11-06T08:30:00Z"
  }
];

export const initialPenilaian: PenilaianSantri[] = [
  {
    id: "pen-01",
    santriId: "s-1",
    kelasId: "k-2",
    periode: "Evaluasi Tengah Semester Ganjil 1446-1447 H",
    tanggal: "2026-10-25",
    evaluasi: [
      { bidang: "Nahwu", predikat: "Jayyid", nilaiAngka: 88, catatan: "Kaidah marfu'at isim dikuasai baik" },
      { bidang: "Sharraf dan I‘lal", predikat: "Mutawassith", nilaiAngka: 74, catatan: "Perlu drill bina' naqish & ajwaf" },
      { bidang: "Lafadz dan makna", predikat: "Jayyid", nilaiAngka: 85, catatan: "Penguasaan mufradat fidyah dan shalat lancar" },
      { bidang: "Kemampuan membaca kitab", predikat: "Jayyid", nilaiAngka: 82, catatan: "Membaca Yāqūtun Nafīs tartil" },
      { bidang: "Hafalan", predikat: "Jayyid", nilaiAngka: 90, catatan: "Nadzom kaidah Al-Wasā'il tuntas 60 bait" },
      { bidang: "Muthalaah", predikat: "Jayyid", nilaiAngka: 85, catatan: "Tepat waktu dan konsisten" },
      { bidang: "Kedisiplinan", predikat: "Jayyid", nilaiAngka: 92, catatan: "Hadir selalu tepat waktu" },
      { bidang: "Akhlak", predikat: "Jayyid", nilaiAngka: 95, catatan: "Sopan santun dan tawadhu'" }
    ],
    catatanUmum: "Santri memiliki potensi besar, direkomendasikan masuk simulasi pra-tashih bulan depan.",
    perkembanganKemampuan: "Pesat dalam analisa kedudukan kalimat gundul.",
    guruId: "g-2",
    guruNama: "Ust. Muhammad Kholil, M.H"
  },
  {
    id: "pen-02",
    santriId: "s-3",
    kelasId: "k-1",
    periode: "Evaluasi Tengah Semester Ganjil 1446-1447 H",
    tanggal: "2026-10-25",
    evaluasi: [
      { bidang: "Nahwu", predikat: "Rodi", nilaiAngka: 58, catatan: "Masih bingung membedakan isim dan fi'il" },
      { bidang: "Sharraf dan I‘lal", predikat: "Mutawassith", nilaiAngka: 65, catatan: "Wazan tsulatsi mujarrad belum hafal sempurna" },
      { bidang: "Lafadz dan makna", predikat: "Mutawassith", nilaiAngka: 68, catatan: "Makna gandul terkadang tertinggal" },
      { bidang: "Kemampuan membaca kitab", predikat: "Rodi", nilaiAngka: 55, catatan: "Masih mengeja dan takut salah harakat akhir" },
      { bidang: "Hafalan", predikat: "Mutawassith", nilaiAngka: 70, catatan: "Baru mencapai Shufhah 6" },
      { bidang: "Muthalaah", predikat: "Rodi", nilaiAngka: 60, catatan: "Jarang muthalaah mandiri" },
      { bidang: "Kedisiplinan", predikat: "Rodi", nilaiAngka: 62, catatan: "Sering terlambat dan alfa 3 kali" },
      { bidang: "Akhlak", predikat: "Mutawassith", nilaiAngka: 75, catatan: "Cukup baik" }
    ],
    catatanUmum: "Memerlukan bimbingan khusus (tahsin kaidah) setiap ba'da Maghrib.",
    perkembanganKemampuan: "Perlu dorongan motivasi dan penataan kedisiplinan belajar.",
    guruId: "g-1",
    guruNama: "Ust. Ahmad Ghazali, S.Pd.I"
  },
  {
    id: "pen-03",
    santriId: "s-2",
    kelasId: "k-2",
    periode: "Evaluasi Tengah Semester Ganjil 1446-1447 H",
    tanggal: "2026-10-25",
    evaluasi: [
      { bidang: "Nahwu", predikat: "Jayyid", nilaiAngka: 94, catatan: "Tarkib luar biasa tajam" },
      { bidang: "Sharraf dan I‘lal", predikat: "Jayyid", nilaiAngka: 90, catatan: "Kaidah I'lal 1-19 dikuasai sangat baik" },
      { bidang: "Lafadz dan makna", predikat: "Jayyid", nilaiAngka: 92, catatan: "Fasih menerjemah makna murad" },
      { bidang: "Kemampuan membaca kitab", predikat: "Jayyid", nilaiAngka: 93, catatan: "Mampu membaca tanpa harakat dengan lancar" },
      { bidang: "Hafalan", predikat: "Jayyid", nilaiAngka: 96, catatan: "Hafalan shufhah 1-30 tuntas mutqin" },
      { bidang: "Muthalaah", predikat: "Jayyid", nilaiAngka: 90, catatan: "Rajin membedah kitab di asrama" },
      { bidang: "Kedisiplinan", predikat: "Jayyid", nilaiAngka: 95, catatan: "Teladan kelas" },
      { bidang: "Akhlak", predikat: "Jayyid", nilaiAngka: 98, catatan: "Sangat ta'dzim kepada asatidz" }
    ],
    catatanUmum: "Siap langsung diajukan sebagai peserta Tashih Al-Wasā'il Gelombang Utama.",
    perkembanganKemampuan: "Sangat matang dalam membaca kitab kuning.",
    guruId: "g-2",
    guruNama: "Ust. Muhammad Kholil, M.H"
  }
];

export const initialProgres: ProgresPembelajaranSantri[] = [
  {
    id: "prog-1",
    santriId: "s-1",
    tahapanAktif: "Marhalah 2 (Shufhah 16–30)",
    materiSelesai: [
      "Pengenalan Kalimat (Isim, Fi'il, Huruf)",
      "Shufhah 1–15: Tanda I'rab Rofa, Nashab, Jer, Jazm",
      "Kaidah Fa'il & Naibul Fa'il",
      "Mubtada' & Khabar serta Amil Nawasikh",
      "Latihan Tarkib Shufhah 16-20"
    ],
    targetHarian: "Membaca 2 Shufhah Yāqūtun Nafīs & Mengi'rab 5 kalimat tarkib",
    targetHafalan: "Nadzom I'lal Kaidah ke-7 sampai ke-12",
    kesulitanKedudukanKalimat: false,
    kelancaranMembacaKitab: "Baik",
    catatanKesulitan: "Terkadang ragu membedakan antara Khobar Syibhul Jumlah dengan Hal.",
    rekomendasiBimbingan: "Berikan drilling perbandingan antara Hal dan Tamyiz pada ibarat kitab.",
    terakhirDiperbarui: "2026-11-08"
  },
  {
    id: "prog-2",
    santriId: "s-2",
    tahapanAktif: "Marhalah 3 (Tarkib & Kitab Gundul)",
    materiSelesai: [
      "Seluruh Shufhah 1–30 Metode Al-Wasā'il",
      "19 Kaidah I'lal Al-Wasā'il",
      "Kitab Yāqūtun Nafīs Bab Ibadat",
      "Praktik Baca Kitab Fathul Qorib Gundul Fasal Thaharah"
    ],
    targetHarian: "Membaca 1 bab Fathul Qorib gundul dengan i'rab lengkap",
    targetHafalan: "Hafal matan kaidah tashih",
    kesulitanKedudukanKalimat: false,
    kelancaranMembacaKitab: "Sangat Baik",
    catatanKesulitan: "Tidak ada kendala berarti. Menguasai tarkib tingkat tinggi.",
    rekomendasiBimbingan: "Didaftarkan ke Ujian Tashih Al-Wasā'il.",
    terakhirDiperbarui: "2026-11-09"
  },
  {
    id: "prog-3",
    santriId: "s-3",
    tahapanAktif: "Marhalah 1 (Shufhah 1–15)",
    materiSelesai: [
      "Pengenalan Isim, Fi'il, Huruf",
      "Tanda Rofa' Dhammah"
    ],
    targetHarian: "Menghafal 3 tanda isim dan mencocokkan pada Shufhah 5",
    targetHafalan: "Kaidah tanda-tanda kalimah Al-Wasā'il",
    kesulitanKedudukanKalimat: true, // Flagged: kesulitan kedudukan kalimat!
    kelancaranMembacaKitab: "Kurang",
    catatanKesulitan: "Kesulitan menentukan kedudukan kalimat (Fa'il vs Maf'ul). Masih mengeja.",
    rekomendasiBimbingan: "Wajib mengikuti kelas bimbingan sore (Remedial Al-Wasā'il) bersama pendamping santri.",
    terakhirDiperbarui: "2026-11-07"
  },
  {
    id: "prog-4",
    santriId: "s-4",
    tahapanAktif: "Marhalah 2 (Shufhah 16–30)",
    materiSelesai: [
      "Shufhah 1–24",
      "Bina' Mudha'af & Mahmuz",
      "Tarkib Maf'ulat"
    ],
    targetHarian: "Menyelesaikan tarkib Shufhah 25-28",
    targetHafalan: "Wazan tsulatsi mazid",
    kesulitanKedudukanKalimat: false,
    kelancaranMembacaKitab: "Baik",
    catatanKesulitan: "Hafalan wazan perlu dimutqinkan kembali.",
    rekomendasiBimbingan: "Muthalaah kelompok bersama santri senior.",
    terakhirDiperbarui: "2026-11-06"
  },
  {
    id: "prog-7",
    santriId: "s-7",
    tahapanAktif: "Marhalah 2 (Shufhah 16–30)",
    materiSelesai: [
      "Shufhah 1–18",
      "Tarkib Marfu'at Isim"
    ],
    targetHarian: "Latihan menelaah Hal dan Tamyiz pada 3 ibarat kitab",
    targetHafalan: "Nadzom syarat Hal dan Tamyiz",
    kesulitanKedudukanKalimat: true, // Flagged: kesulitan menentukan kedudukan kalimat!
    kelancaranMembacaKitab: "Cukup",
    catatanKesulitan: "Sering tertukar kedudukan manshubat (terutama Hal dan Maf'ul Fih).",
    rekomendasiBimbingan: "Fokus pada rumus praktis Al-Wasā'il untuk mendeteksi Hal (menjawab pertanyaan 'bagaimana keadaan?').",
    terakhirDiperbarui: "2026-11-08"
  }
];

export const initialJurnal: JurnalGuru[] = [
  {
    id: "jur-01",
    guruId: "g-2",
    guruNama: "Ust. Muhammad Kholil, M.H",
    kelasId: "k-2",
    kelasNama: "Takhassus A",
    tanggal: "2026-11-09",
    materiDiajarkan: "Kitab Yāqūtun Nafīs - Bab Shalat & Shufhah 20 (Tarkib Manshubat Isim)",
    targetPembelajaran: "Santri mampu mengidentifikasi dan mengi'rab Maf'ul Bih dan Maf'ul Muthlaq dalam ibarat fiqih",
    materiSelesai: "Tuntas membaca fasal syarat shalat (2 halaman gundul) dan bedah tarkib 8 santri",
    kendala: "Sebagian santri putri (Siti Masithah) masih tertukar membedakan kedudukan Hal dan Maf'ul Bih",
    catatanEvaluasi: "Diberikan tugas tambahan menuliskan 5 contoh Maf'ul Muthlaq bersumber dari kitab",
    statusVerifikasi: "Terverifikasi"
  },
  {
    id: "jur-02",
    guruId: "g-1",
    guruNama: "Ust. Ahmad Ghazali, S.Pd.I",
    kelasId: "k-1",
    kelasNama: "I’dadiyah",
    tanggal: "2026-11-09",
    materiDiajarkan: "Metode Al-Wasā'il Shufhah 9: Tanda I'rab Rofa' (Wawu pada Jamak Mudzakkar Salim & Asma'ul Khomsah)",
    targetPembelajaran: "Santri hafal rumus tanda rofa' wawu dan dapat menunjukkan contohnya",
    materiSelesai: "Selesai 1 lembar rumus kaidah Al-Wasā'il dan latihan membaca 15 kalimat",
    kendala: "Santri Fathur Rohman tidak hadir (Alfa), pemahaman santri baru masih bervariasi",
    catatanEvaluasi: "Akan diadakan drill talaqqi bersama pada pertemuan berikutnya",
    statusVerifikasi: "Terverifikasi"
  },
  {
    id: "jur-03",
    guruId: "g-3",
    guruNama: "Ust. Abdul Wahid Al-Hafidz",
    kelasId: "k-3",
    kelasNama: "Takhassus B",
    tanggal: "2026-11-08",
    materiDiajarkan: "Kaidah I'lal Al-Wasā'il: Kaidah 1 (Penggantian Wawu/Ya' menjadi Alif karena berharakat dan sebelumnya fathah)",
    targetPembelajaran: "Santri mampu mengi'lal lafadz QOOLA (اصلُه قَوَلَ) dan BAA'A (اصلُه بَيَعَ)",
    materiSelesai: "Tuntas kaidah 1 dan kaidah 2 beserta 10 contoh tashrif",
    kendala: "Tidak ada kendala berarti, santri sangat antusias",
    catatanEvaluasi: "Tingkat pemahaman kelas 85% memuaskan",
    statusVerifikasi: "Terverifikasi"
  }
];

export const initialTashih: PesertaTashih[] = [
  {
    id: "tsh-01",
    nomorPeserta: "TSH-2026-001",
    santriId: "s-5",
    nama: "Lukman Hakim As-Samfani",
    lembagaAsal: "PP Al-Ihsan Jrangoan - Pusat",
    kelasAsal: "Takhassus C",
    gelombangUjian: "Gelombang I (Ujian Syahadah Tahap 1)",
    ruangUjian: "Aula Utama Ma'had Al-Ihsan",
    tanggalUjian: "2026-11-01",
    penguji: "Ust. Hasan Basri, S.Hum",
    nilaiNahwu: 88,
    nilaiSharraf: 85,
    nilaiMembacaKitab: 86,
    catatanPenguji: "Membaca kitab Yāqūtun Nafīs dengan tartil, i'rab mantap.",
    statusLulus: "Lulus",
    predikat: "Jayyid Jiddan",
    nomorSyahadah: "SY-ALW/XI/2026/089"
  },
  {
    id: "tsh-02",
    nomorPeserta: "TSH-2026-002",
    santriId: "s-8",
    nama: "Miftahul Arifin",
    lembagaAsal: "Cabang Surabaya",
    kelasAsal: "Takhassus C",
    gelombangUjian: "Gelombang I (Ujian Syahadah Tahap 1)",
    ruangUjian: "Aula Utama Ma'had Al-Ihsan",
    tanggalUjian: "2026-11-01",
    penguji: "KH. Fauzi Ihsan, M.Pd.I",
    nilaiNahwu: 95,
    nilaiSharraf: 92,
    nilaiMembacaKitab: 94,
    catatanPenguji: "Mumtaz! Menguasai tarkib dan i'lal secara mendalam, bacaan sangat fasih.",
    statusLulus: "Lulus",
    predikat: "Mumtaz",
    nomorSyahadah: "SY-ALW/XI/2026/090"
  },
  {
    id: "tsh-03",
    nomorPeserta: "TSH-2026-003",
    santriId: "s-2",
    nama: "Ahmad Zainuri Al-Maduri",
    lembagaAsal: "Cabang Bangkalan",
    kelasAsal: "Takhassus A",
    gelombangUjian: "Gelombang II (Jadwal Mendatang)",
    ruangUjian: "Ruang Penguji B",
    tanggalUjian: "2026-11-20",
    penguji: "Ust. Hasan Basri, S.Hum",
    nilaiNahwu: 0,
    nilaiSharraf: 0,
    nilaiMembacaKitab: 0,
    catatanPenguji: "Terdaftar resmi, berkas lengkap, menunggu tanggal ujian.",
    statusLulus: "Belum Ujian"
  },
  {
    id: "tsh-04",
    nomorPeserta: "TSH-2026-004",
    nama: "Kamilul Ihsan (Eksternal)",
    lembagaAsal: "PP Darul Ulum Sampang (Mitra Cabang)",
    kelasAsal: "Takhassus Cabang",
    gelombangUjian: "Gelombang I (Ujian Syahadah Tahap 1)",
    ruangUjian: "Ruang Penguji C",
    tanggalUjian: "2026-11-01",
    penguji: "Ust. Ahmad Ghazali, S.Pd.I",
    nilaiNahwu: 62,
    nilaiSharraf: 60,
    nilaiMembacaKitab: 65,
    catatanPenguji: "Belum memenuhi standar KKM (70) pada bidang Sharraf dan I'lal. Direkomendasikan remidi.",
    statusLulus: "Tidak Lulus",
    predikat: "Rasib"
  }
];

export const initialPengumuman: Pengumuman[] = [
  {
    id: "pgm-01",
    judul: "Jadwal Pelaksanaan Ujian Tashih Al-Wasā'il Gelombang II",
    kategori: "Jadwal Ujian",
    tanggal: "2026-11-09",
    isi: "Diberitahukan kepada seluruh santri Takhassus dan koordinator cabang bahwa Ujian Tashih Gelombang II akan diselenggarakan pada hari Kamis, 20 November 2026 bertempat di Gedung Pusat Lembaga Al-Wasā'il PP Al-Ihsan Jrangoan. Harap menyelesaikan berkas administrasi dan setoran shufhah 1-30.",
    target: "Semua",
    penulis: "Sekretariat Lembaga Al-Wasā'il",
    isPenting: true
  },
  {
    id: "pgm-02",
    judul: "Rapat Bulanan Asatidz: Evaluasi Capaian Tarkib Santri",
    kategori: "Rapat Guru",
    tanggal: "2026-11-08",
    isi: "Seluruh Asatidz pengampu kelas I'dadiyah dan Takhassus dimohon hadir pada Rapat Evaluasi Bulanan hari Sabtu ba'da Ashar di Ruang Asatidz. Agenda: Analisis santri kesulitan kedudukan kalimat dan sinkronisasi jurnal mengajar.",
    target: "Guru",
    penulis: "Kepala Lembaga Al-Wasā'il",
    isPenting: true
  },
  {
    id: "pgm-03",
    judul: "Informasi Wali Santri: Pembagian Rapor Hasil Belajar Mid-Semester",
    kategori: "Wali Santri",
    tanggal: "2026-11-05",
    isi: "Laporan perkembangan metode Al-Wasā'il (Nahwu, Sharraf, Baca Kitab, Hafalan) semester ini dapat dipantau langsung oleh Bapak/Ibu wali santri melalui aplikasi AL-WASĀ’IL menggunakan Nomor Induk Santri (NIS).",
    target: "Wali",
    penulis: "Bagian Kesiswaan PP Al-Ihsan Jrangoan",
    isPenting: false
  }
];

export const getInitialDatabase = (): DatabaseState => ({
  version: "1.0.0",
  lastUpdated: new Date().toISOString(),
  pengaturan: initialPengaturan,
  santri: initialSantri,
  guru: initialGuru,
  kelas: initialKelas,
  absensi: initialAbsensi,
  penilaian: initialPenilaian,
  jurnal: initialJurnal,
  progres: initialProgres,
  tashih: initialTashih,
  pengumuman: initialPengumuman
});

/**
 * Load database from localStorage or initialize with seed data
 */
export function loadDatabase(): DatabaseState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial = getInitialDatabase();
      saveDatabase(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);
    // Ensure backwards compatibility with all fields
    return {
      ...getInitialDatabase(),
      ...parsed,
      pengaturan: { ...initialPengaturan, ...(parsed.pengaturan || {}) }
    };
  } catch (err) {
    console.error("Failed to load database from localStorage, resetting to initial:", err);
    const initial = getInitialDatabase();
    saveDatabase(initial);
    return initial;
  }
}

/**
 * Save database to localStorage and broadcast change event
 */
export function saveDatabase(data: DatabaseState): void {
  try {
    data.lastUpdated = new Date().toISOString();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    window.dispatchEvent(new CustomEvent('alwasail:db-updated', { detail: data }));
  } catch (err) {
    console.error("Failed to save database to localStorage:", err);
  }
}

/**
 * Download entire database as a JSON file
 */
export function downloadDatabaseBackup(): void {
  const data = loadDatabase();
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const dateStr = new Date().toISOString().split('T')[0];
  a.href = url;
  a.download = `backup_alwasail_alihsan_${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Restore database from a JSON file
 */
export function restoreDatabaseFromFile(file: File): Promise<boolean> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        if (!parsed.santri || !parsed.guru || !parsed.kelas) {
          throw new Error("Format berkas backup tidak valid.");
        }
        saveDatabase(parsed);
        resolve(true);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error("Gagal membaca berkas."));
    reader.readAsText(file);
  });
}

/**
 * Reset database to factory default
 */
export function resetDatabaseToDefault(): DatabaseState {
  const initial = getInitialDatabase();
  saveDatabase(initial);
  return initial;
}

/**
 * Export array of data to CSV file
 */
export function exportToCSV(filename: string, headers: string[], rows: (string | number)[][]): void {
  const processCell = (cell: string | number) => {
    const str = cell === null || cell === undefined ? '' : String(cell);
    return `"${str.replace(/"/g, '""')}"`;
  };

  const csvContent = [
    headers.map(processCell).join(','),
    ...rows.map(row => row.map(processCell).join(','))
  ].join('\r\n');

  // Add BOM for proper UTF-8 Excel support
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
