import { createClient } from '@supabase/supabase-js';

// Public client configuration. Never place a service_role key in the Android app.
const supabaseUrl = 'https://ppctorygunyrddbplxyv.supabase.co';
const supabaseAnonKey = 'sb_publishable_qHvRW8OSvU44tVCXj1RZwg_A0nwj7QE';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});
