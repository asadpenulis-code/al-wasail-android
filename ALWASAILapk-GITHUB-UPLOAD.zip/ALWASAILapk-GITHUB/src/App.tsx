/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { DatabaseState, UserAccount, Santri, Guru, Kelas, AbsensiSesi, PenilaianSantri, JurnalGuru, ProgresPembelajaranSantri, PesertaTashih, Pengumuman, PengaturanLembaga } from './types';
import { loadDatabase, saveDatabase } from './services/db';
import { Header } from './components/Header';
import { Sidebar, NavTab } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { MutuAnalitikModal } from './components/MutuAnalitikModal';
import { BackupRestoreModal } from './components/BackupRestoreModal';
import { AuthGate } from './components/AuthGate';

// Modules & Dashboards
import { DashboardAdmin } from './components/DashboardAdmin';
import { DashboardGuru } from './components/DashboardGuru';
import { DashboardSantri } from './components/DashboardSantri';
import { DashboardKepala } from './components/DashboardKepala';
import { SantriModule } from './components/SantriModule';
import { GuruModule } from './components/GuruModule';
import { KelasModule } from './components/KelasModule';
import { AbsensiModule } from './components/AbsensiModule';
import { PenilaianModule } from './components/PenilaianModule';
import { PembelajaranModule } from './components/PembelajaranModule';
import { JurnalModule } from './components/JurnalModule';
import { TashihModule } from './components/TashihModule';
import { PengumumanModule } from './components/PengumumanModule';
import { LaporanModule } from './components/LaporanModule';
import { PengaturanModule } from './components/PengaturanModule';

function AppContent({ authenticatedUser, onSignOut }: { authenticatedUser: UserAccount; onSignOut: () => Promise<void> }) {
  const [db, setDb] = useState<DatabaseState>(() => loadDatabase());
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMutuModalOpen, setIsMutuModalOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);

  // Identity comes from the authenticated Supabase account.
  const currentUser = authenticatedUser;

  // Listen to external or cross-tab DB updates
  useEffect(() => {
    const handleDbUpdated = (e: any) => {
      if (e.detail) {
        setDb(e.detail);
      } else {
        setDb(loadDatabase());
      }
    };
    window.addEventListener('alwasail:db-updated', handleDbUpdated);
    return () => window.removeEventListener('alwasail:db-updated', handleDbUpdated);
  }, []);

  // Update handlers that commit to localStorage and broadcast
  const handleUpdateDatabase = (updater: (prev: DatabaseState) => DatabaseState) => {
    const nextState = updater(db);
    setDb(nextState);
    saveDatabase(nextState);
  };

  const handleUpdateSantri = (santriList: Santri[]) => {
    handleUpdateDatabase(prev => ({ ...prev, santri: santriList }));
  };

  const handleUpdateGuru = (guruList: Guru[]) => {
    handleUpdateDatabase(prev => ({ ...prev, guru: guruList }));
  };

  const handleUpdateKelas = (kelasList: Kelas[]) => {
    handleUpdateDatabase(prev => ({ ...prev, kelas: kelasList }));
  };

  const handleUpdateAbsensi = (absensiList: AbsensiSesi[]) => {
    handleUpdateDatabase(prev => ({ ...prev, absensi: absensiList }));
  };

  const handleUpdatePenilaian = (penilaianList: PenilaianSantri[]) => {
    handleUpdateDatabase(prev => ({ ...prev, penilaian: penilaianList }));
  };

  const handleUpdateProgres = (progresList: ProgresPembelajaranSantri[]) => {
    handleUpdateDatabase(prev => ({ ...prev, progres: progresList }));
  };

  const handleUpdateJurnal = (jurnalList: JurnalGuru[]) => {
    handleUpdateDatabase(prev => ({ ...prev, jurnal: jurnalList }));
  };

  const handleUpdateTashih = (tashihList: PesertaTashih[]) => {
    handleUpdateDatabase(prev => ({ ...prev, tashih: tashihList }));
  };

  const handleUpdatePengumuman = (pengumumanList: Pengumuman[]) => {
    handleUpdateDatabase(prev => ({ ...prev, pengumuman: pengumumanList }));
  };

  const handleUpdatePengaturan = (pengaturan: PengaturanLembaga) => {
    handleUpdateDatabase(prev => ({ ...prev, pengaturan }));
  };

  // Render active dashboard or module view
  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        if (currentUser.role === 'admin') {
          return (
            <DashboardAdmin
              db={db}
              currentUser={currentUser}
              onNavigate={(tab) => setActiveTab(tab)}
              onOpenMutuModal={() => setIsMutuModalOpen(true)}
            />
          );
        } else if (currentUser.role === 'guru') {
          return (
            <DashboardGuru
              db={db}
              currentUser={currentUser}
              onNavigate={(tab) => setActiveTab(tab)}
              onOpenMutuModal={() => setIsMutuModalOpen(true)}
            />
          );
        } else if (currentUser.role === 'santri') {
          return (
            <DashboardSantri
              db={db}
              currentUser={currentUser}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          );
        } else {
          return (
            <DashboardKepala
              db={db}
              currentUser={currentUser}
              onNavigate={(tab) => setActiveTab(tab)}
              onOpenMutuModal={() => setIsMutuModalOpen(true)}
            />
          );
        }

      case 'santri':
        return (
          <SantriModule
            db={db}
            currentUser={currentUser}
            onUpdateSantri={handleUpdateSantri}
          />
        );

      case 'guru':
        return (
          <GuruModule
            db={db}
            currentUser={currentUser}
            onUpdateGuru={handleUpdateGuru}
          />
        );

      case 'kelas':
        return (
          <KelasModule
            db={db}
            currentUser={currentUser}
            onUpdateKelas={handleUpdateKelas}
            onNavigateToSantriFiltered={(cId) => {
              setActiveTab('santri');
            }}
          />
        );

      case 'absensi':
        return (
          <AbsensiModule
            db={db}
            currentUser={currentUser}
            onUpdateAbsensi={handleUpdateAbsensi}
          />
        );

      case 'penilaian':
        return (
          <PenilaianModule
            db={db}
            currentUser={currentUser}
            onUpdatePenilaian={handleUpdatePenilaian}
          />
        );

      case 'pembelajaran':
        return (
          <PembelajaranModule
            db={db}
            currentUser={currentUser}
            onUpdateProgres={handleUpdateProgres}
            onOpenMutuModal={() => setIsMutuModalOpen(true)}
          />
        );

      case 'jurnal':
        return (
          <JurnalModule
            db={db}
            currentUser={currentUser}
            onUpdateJurnal={handleUpdateJurnal}
          />
        );

      case 'tashih':
        return (
          <TashihModule
            db={db}
            currentUser={currentUser}
            onUpdateTashih={handleUpdateTashih}
          />
        );

      case 'pengumuman':
        return (
          <PengumumanModule
            db={db}
            currentUser={currentUser}
            onUpdatePengumuman={handleUpdatePengumuman}
          />
        );

      case 'laporan':
        return (
          <LaporanModule
            db={db}
            currentUser={currentUser}
            onOpenMutuModal={() => setIsMutuModalOpen(true)}
          />
        );

      case 'pengaturan':
        return (
          <PengaturanModule
            db={db}
            currentUser={currentUser}
            onUpdatePengaturan={handleUpdatePengaturan}
            onOpenBackupModal={() => setIsBackupModalOpen(true)}
          />
        );

      default:
        return (
          <DashboardAdmin
            db={db}
            currentUser={currentUser}
            onNavigate={(tab) => setActiveTab(tab)}
            onOpenMutuModal={() => setIsMutuModalOpen(true)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* Top Header */}
      <Header
        currentUser={currentUser}
        onSignOut={onSignOut}
        pengaturan={db.pengaturan}
        onOpenMutuModal={() => setIsMutuModalOpen(true)}
        onOpenBackupModal={() => setIsBackupModalOpen(true)}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          userRole={currentUser.role}
          isOpen={isSidebarOpen}
          onCloseMobile={() => setIsSidebarOpen(false)}
          onOpenMutuModal={() => setIsMutuModalOpen(true)}
          onOpenBackupModal={() => setIsBackupModalOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 lg:pl-64 p-4 sm:p-6 lg:p-8 pb-24 lg:pb-8 max-w-full overflow-x-hidden">
          {renderContent()}
        </main>

      </div>

      {/* Mobile Navigation Bottom Bar */}
      <MobileNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        userRole={currentUser.role}
        onToggleSidebar={() => setIsSidebarOpen(true)}
      />

      {/* Modal Mutu Analitik (Saran Utama Pengembangan) */}
      {isMutuModalOpen && (
        <MutuAnalitikModal
          db={db}
          onClose={() => setIsMutuModalOpen(false)}
        />
      )}

      {/* Modal Backup & Restore Database */}
      {isBackupModalOpen && (
        <BackupRestoreModal
          db={db}
          onClose={() => setIsBackupModalOpen(false)}
          onRefresh={() => setDb(loadDatabase())}
        />
      )}

    </div>
  );
}


export default function App() {
  return <AuthGate>{(user, signOut) => <AppContent authenticatedUser={user} onSignOut={signOut} />}</AuthGate>;
}
