import React, { useState } from 'react';
import { DatabaseState, PenilaianSantri, UserAccount, PredikatNilai, EvaluasiBidang } from '../types';
import { exportToCSV } from '../services/db';
import { Award, Plus, Search, Printer, Download, Edit2, Trash2, X, CheckCircle, FileText } from 'lucide-react';

interface PenilaianModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdatePenilaian: (penilaianList: PenilaianSantri[]) => void;
}

const DEFAULT_BIDANG: EvaluasiBidang['bidang'][] = [
  'Nahwu',
  'Sharraf dan I‘lal',
  'Lafadz dan makna',
  'Kemampuan membaca kitab',
  'Hafalan',
  'Muthalaah',
  'Kedisiplinan',
  'Akhlak'
];

export const PenilaianModule: React.FC<PenilaianModuleProps> = ({
  db,
  currentUser,
  onUpdatePenilaian
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedKelasFilter, setSelectedKelasFilter] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPenilaian, setEditingPenilaian] = useState<PenilaianSantri | null>(null);
  const [selectedRapor, setSelectedRapor] = useState<{ santriId: string; penilaian: PenilaianSantri } | null>(null);

  // Form State
  const [targetSantriId, setTargetSantriId] = useState<string>(db.santri[0]?.id || 's-1');
  const [periode, setPeriode] = useState<string>('Evaluasi Tengah Semester Ganjil 1446-1447 H');
  const [evaluasiList, setEvaluasiList] = useState<EvaluasiBidang[]>(
    DEFAULT_BIDANG.map(b => ({
      bidang: b,
      predikat: 'Jayyid',
      nilaiAngka: 80,
      catatan: ''
    }))
  );
  const [catatanUmum, setCatatanUmum] = useState<string>('');
  const [perkembanganKemampuan, setPerkembanganKemampuan] = useState<string>('');

  const canEdit = currentUser.role === 'admin' || currentUser.role === 'guru';

  const filteredPenilaian = db.penilaian.filter(p => {
    const s = db.santri.find(item => item.id === p.santriId);
    if (!s) return false;
    const matchSearch = s.nama.toLowerCase().includes(searchTerm.toLowerCase()) || s.nis.includes(searchTerm);
    const matchKelas = selectedKelasFilter === 'all' || s.kelasId === selectedKelasFilter;
    return matchSearch && matchKelas;
  });

  const handleOpenAdd = () => {
    setEditingPenilaian(null);
    setTargetSantriId(db.santri[0]?.id || 's-1');
    setPeriode('Evaluasi Tengah Semester Ganjil 1446-1447 H');
    setEvaluasiList(
      DEFAULT_BIDANG.map(b => ({
        bidang: b,
        predikat: 'Jayyid',
        nilaiAngka: 80,
        catatan: ''
      }))
    );
    setCatatanUmum('');
    setPerkembanganKemampuan('Mampu mengidentifikasi tarkib kedudukan kalimat dengan baik.');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: PenilaianSantri) => {
    setEditingPenilaian(p);
    setTargetSantriId(p.santriId);
    setPeriode(p.periode);
    setEvaluasiList(p.evaluasi);
    setCatatanUmum(p.catatanUmum);
    setPerkembanganKemampuan(p.perkembanganKemampuan);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const targetSantri = db.santri.find(s => s.id === targetSantriId);
    if (!targetSantri) return;

    const teacherName = currentUser.name;
    const teacherId = currentUser.relatedId || 'g-1';

    const newPenilaian: PenilaianSantri = {
      id: editingPenilaian?.id || `pen-${Date.now()}`,
      santriId: targetSantriId,
      kelasId: targetSantri.kelasId,
      periode,
      tanggal: new Date().toISOString().split('T')[0],
      evaluasi: evaluasiList,
      catatanUmum,
      perkembanganKemampuan,
      guruId: teacherId,
      guruNama: teacherName
    };

    if (editingPenilaian) {
      onUpdatePenilaian(db.penilaian.map(p => p.id === editingPenilaian.id ? newPenilaian : p));
    } else {
      onUpdatePenilaian([...db.penilaian, newPenilaian]);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Yakin ingin menghapus data penilaian ini?")) {
      onUpdatePenilaian(db.penilaian.filter(p => p.id !== id));
    }
  };

  const handleExportCSV = () => {
    const headers = ['NIS', 'Nama Santri', 'Kelas', 'Periode', 'Rata-rata Nilai', 'Catatan Umum'];
    const rows = filteredPenilaian.map(p => {
      const s = db.santri.find(item => item.id === p.santriId);
      const k = db.kelas.find(item => item.id === p.kelasId);
      const avg = Math.round(p.evaluasi.reduce((acc, curr) => acc + curr.nilaiAngka, 0) / p.evaluasi.length);
      return [
        s?.nis || '-',
        s?.nama || '-',
        k?.nama || '-',
        p.periode,
        avg,
        p.catatanUmum
      ];
    });
    const dateStr = new Date().toISOString().split('T')[0];
    exportToCSV(`penilaian_alwasail_${dateStr}`, headers, rows);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <Award className="w-4 h-4" />
            <span>Sistem Evaluasi Metodologi Al-Wasā’il</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Penilaian & Rapor Hasil Belajar Santri
          </h2>
          <p className="text-xs text-slate-500">
            Standar 8 bidang keahlian: Nahwu, Sharraf & I'lal, Lafadz & Makna, Baca Kitab, Hafalan, Muthalaah, Kedisiplinan & Akhlak.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Ekspor CSV</span>
          </button>

          {canEdit && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <Plus className="w-4 h-4 text-amber-300" />
              <span>Input Penilaian Santri</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari santri atau NIS..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-slate-500 font-medium">Filter Kelas:</span>
          <select
            value={selectedKelasFilter}
            onChange={(e) => setSelectedKelasFilter(e.target.value)}
            className="py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
          >
            <option value="all">Semua Kelas</option>
            {db.kelas.map(k => (
              <option key={k.id} value={k.id}>{k.nama}</option>
            ))}
          </select>
        </div>
      </div>

      {/* List of Evaluations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredPenilaian.map(p => {
          const s = db.santri.find(item => item.id === p.santriId);
          const k = db.kelas.find(item => item.id === p.kelasId);
          const avgScore = Math.round(p.evaluasi.reduce((acc, curr) => acc + curr.nilaiAngka, 0) / p.evaluasi.length);

          return (
            <div key={p.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
              
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-bold text-slate-900 text-base">{s?.nama || 'Santri'}</h3>
                  <div className="text-[11px] text-slate-500 font-mono-num">
                    NIS: {s?.nis} · Kelas {k?.nama}
                  </div>
                  <div className="text-[10px] text-amber-800 font-medium mt-0.5">{p.periode}</div>
                </div>

                <div className="text-right">
                  <div className="text-2xl font-bold text-[#0B1B3D] font-mono-num">{avgScore}</div>
                  <div className="text-[10px] text-slate-400">Rata-rata Nilai</div>
                </div>
              </div>

              {/* 8 Bidang Grid Mini */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[11px]">
                {p.evaluasi.map((e, idx) => (
                  <div key={idx} className="p-2 rounded bg-slate-50 border border-slate-100 flex flex-col justify-between">
                    <span className="text-slate-600 font-medium truncate" title={e.bidang}>{e.bidang}</span>
                    <div className="flex items-baseline justify-between mt-1">
                      <span className="font-bold font-mono-num text-slate-900">{e.nilaiAngka}</span>
                      <span className={`text-[10px] font-bold ${
                        e.predikat === 'Jayyid' ? 'text-emerald-700' : e.predikat === 'Mutawassith' ? 'text-blue-700' : 'text-rose-700'
                      }`}>
                        {e.predikat}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {p.catatanUmum && (
                <div className="text-xs text-slate-600 bg-amber-50/50 p-2.5 rounded-lg border border-amber-100/70">
                  <span className="font-semibold text-slate-800">Catatan Evaluasi: </span>
                  {p.catatanUmum}
                </div>
              )}

              {/* Actions */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400">Penguji: {p.guruNama}</span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setSelectedRapor({ santriId: p.santriId, penilaian: p })}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-semibold text-xs shadow-2xs"
                  >
                    <Printer className="w-3.5 h-3.5 text-amber-300" />
                    <span>Cetak Rapor Santri</span>
                  </button>

                  {canEdit && (
                    <>
                      <button
                        onClick={() => handleOpenEdit(p)}
                        className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(p.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* Modal: Input / Edit Penilaian */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl my-8 overflow-hidden">
            
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingPenilaian ? 'Edit Penilaian Santri' : 'Input Nilai Evaluasi 8 Bidang Al-Wasā’il'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Pilih Santri *</label>
                  <select
                    value={targetSantriId}
                    onChange={(e) => setTargetSantriId(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                  >
                    {db.santri.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.nama} ({s.nis}) - {db.kelas.find(k => k.id === s.kelasId)?.nama}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Periode Evaluasi *</label>
                  <input
                    type="text"
                    required
                    value={periode}
                    onChange={(e) => setPeriode(e.target.value)}
                    placeholder="Contoh: Semester Ganjil 1446-1447 H"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              {/* 8 Bidang Evaluation Inputs */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="font-bold text-slate-900 text-sm">8 Bidang Evaluasi Metodologi Al-Wasā'il:</div>
                
                <div className="space-y-2">
                  {evaluasiList.map((item, index) => (
                    <div key={index} className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                      <div className="sm:col-span-4 font-bold text-slate-800 text-xs">
                        {index + 1}. {item.bidang}
                      </div>

                      <div className="sm:col-span-3">
                        <select
                          value={item.predikat}
                          onChange={(e) => {
                            const val = e.target.value as PredikatNilai;
                            const copy = [...evaluasiList];
                            copy[index].predikat = val;
                            setEvaluasiList(copy);
                          }}
                          className="w-full p-1.5 bg-white border border-slate-200 rounded-lg font-semibold text-xs"
                        >
                          <option value="Jayyid">Jayyid (جيد - Baik)</option>
                          <option value="Mutawassith">Mutawassith (متوسط - Sedang)</option>
                          <option value="Rodi">Rodi' (رديء - Butuh Perbaikan)</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={item.nilaiAngka}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            const copy = [...evaluasiList];
                            copy[index].nilaiAngka = val;
                            setEvaluasiList(copy);
                          }}
                          className="w-full p-1.5 bg-white border border-slate-200 rounded-lg font-mono-num font-bold text-center text-xs"
                          placeholder="Skor"
                        />
                      </div>

                      <div className="sm:col-span-3">
                        <input
                          type="text"
                          value={item.catatan || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            const copy = [...evaluasiList];
                            copy[index].catatan = val;
                            setEvaluasiList(copy);
                          }}
                          className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                          placeholder="Catatan ustadz..."
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Catatan Evaluasi Umum</label>
                <textarea
                  rows={2}
                  value={catatanUmum}
                  onChange={(e) => setCatatanUmum(e.target.value)}
                  placeholder="Catatan pembinaan santri, nasihat akhlak dan metodologi..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Perkembangan Kemampuan Membaca Kitab</label>
                <input
                  type="text"
                  value={perkembanganKemampuan}
                  onChange={(e) => setPerkembanganKemampuan(e.target.value)}
                  placeholder="Contoh: Menguasai tarkib isim marfu'at dengan fasih."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Simpan Nilai Santri
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Printable Official Student Report Card (Rapor Santri Al-Wasā'il) */}
      {selectedRapor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl my-8 overflow-hidden">
            
            {/* Action Bar (Not Printed) */}
            <div className="no-print px-6 py-3.5 bg-[#0B1B3D] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-300" />
                <span className="font-bold text-sm">Pratinjau Rapor Resmi Al-Wasā’il</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-[#0B1B3D] font-bold rounded-lg text-xs flex items-center gap-1.5 transition-colors shadow-2xs"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak / Simpan PDF</span>
                </button>
                <button
                  onClick={() => setSelectedRapor(null)}
                  className="p-1 text-slate-300 hover:text-white rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Official Report Card Sheet (Kop Lembaga & Content) */}
            <div className="p-8 space-y-6 text-slate-800 bg-white">
              
              {/* Kop Surat PP Al-Ihsan Jrangoan - Lembaga Al-Wasā'il */}
              <div className="border-b-2 border-slate-900 pb-4 text-center space-y-1 relative">
                <div className="font-arabic text-xl font-bold text-amber-900 mb-0.5">
                  «الْوَسَائِلُ – الطَّرِيْقَةُ السَّهْلَةُ لِقِرَاءَةِ الْكُتُبِ»
                </div>
                <h2 className="text-lg font-black uppercase tracking-wider text-slate-950">
                  {db.pengaturan.namaLembaga}
                </h2>
                <h3 className="text-sm font-bold text-slate-800">
                  {db.pengaturan.naungan}
                </h3>
                <p className="text-[11px] text-slate-600">
                  {db.pengaturan.alamatLembaga} · Telp: {db.pengaturan.telepon} · Email: {db.pengaturan.email}
                </p>
                <div className="h-0.5 bg-slate-900 mt-2"></div>
                <div className="h-px bg-slate-400 mt-0.5"></div>
              </div>

              {/* Title */}
              <div className="text-center space-y-1">
                <h4 className="text-base font-extrabold uppercase tracking-wide text-slate-950 underline underline-offset-4">
                  LAPORAN HASIL EVALUASI PEMBELAJARAN SANTRI
                </h4>
                <p className="text-xs text-slate-600 font-medium">
                  {selectedRapor.penilaian.periode} · Tahun Ajaran {db.pengaturan.tahunAjaranAktif}
                </p>
              </div>

              {/* Student Metadata Table */}
              {(() => {
                const s = db.santri.find(item => item.id === selectedRapor.santriId);
                const k = db.kelas.find(item => item.id === s?.kelasId);
                const wali = db.guru.find(item => item.id === k?.waliKelasId);

                return (
                  <div className="grid grid-cols-2 gap-x-8 gap-y-1.5 text-xs border border-slate-200 p-3 rounded-lg bg-slate-50/50">
                    <div><span className="text-slate-500 inline-block w-28">Nama Santri</span>: <strong className="text-slate-950">{s?.nama}</strong></div>
                    <div><span className="text-slate-500 inline-block w-28">Nomor Induk (NIS)</span>: <strong className="font-mono-num">{s?.nis}</strong></div>
                    <div><span className="text-slate-500 inline-block w-28">Rombel Kelas</span>: <strong className="text-slate-950">{k?.nama}</strong></div>
                    <div><span className="text-slate-500 inline-block w-28">Wali Kelas</span>: <span>{wali?.nama}</span></div>
                    <div><span className="text-slate-500 inline-block w-28">Lembaga Asal</span>: <span>{s?.lembagaAsal}</span></div>
                    <div><span className="text-slate-500 inline-block w-28">Tanggal Evaluasi</span>: <span className="font-mono-num">{selectedRapor.penilaian.tanggal}</span></div>
                  </div>
                );
              })()}

              {/* 8 Bidang Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse border border-slate-300">
                  <thead className="bg-slate-100 text-slate-800 font-bold uppercase text-[11px]">
                    <tr>
                      <th className="border border-slate-300 py-2 px-2 text-center w-10">No</th>
                      <th className="border border-slate-300 py-2 px-3 text-left">Bidang Evaluasi Al-Wasā'il</th>
                      <th className="border border-slate-300 py-2 px-3 text-center w-24">Nilai Angka</th>
                      <th className="border border-slate-300 py-2 px-3 text-center w-36">Predikat</th>
                      <th className="border border-slate-300 py-2 px-3 text-left">Catatan Khusus Pengajar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedRapor.penilaian.evaluasi.map((e, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="border border-slate-300 py-2 px-2 text-center font-mono-num">{idx + 1}</td>
                        <td className="border border-slate-300 py-2 px-3 font-semibold text-slate-900">{e.bidang}</td>
                        <td className="border border-slate-300 py-2 px-3 text-center font-mono-num font-bold text-slate-900">{e.nilaiAngka}</td>
                        <td className="border border-slate-300 py-2 px-3 text-center font-bold font-arabic text-sm">
                          {e.predikat}
                        </td>
                        <td className="border border-slate-300 py-2 px-3 text-slate-600 text-[11px]">{e.catatan || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Remarks */}
              <div className="border border-slate-200 p-3 rounded-lg text-xs space-y-1.5 bg-slate-50/50">
                <div>
                  <strong className="text-slate-900">Perkembangan Kemampuan: </strong>
                  <span className="text-slate-700">{selectedRapor.penilaian.perkembanganKemampuan}</span>
                </div>
                <div>
                  <strong className="text-slate-900">Catatan Dewan Asatidz: </strong>
                  <span className="text-slate-700">{selectedRapor.penilaian.catatanUmum}</span>
                </div>
              </div>

              {/* Signature Blocks */}
              <div className="grid grid-cols-2 text-xs pt-4 text-center">
                <div className="space-y-16">
                  <div>
                    Mengetahui,<br />
                    <strong>Kepala Lembaga Al-Wasā'il</strong>
                  </div>
                  <div>
                    <strong className="underline underline-offset-4">{db.pengaturan.namaPimpinan}</strong>
                  </div>
                </div>

                <div className="space-y-16">
                  <div>
                    Sampang, {new Date(selectedRapor.penilaian.tanggal).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}<br />
                    <strong>Guru Pengampu / Wali Kelas</strong>
                  </div>
                  <div>
                    <strong className="underline underline-offset-4">{selectedRapor.penilaian.guruNama}</strong>
                  </div>
                </div>
              </div>

            </div>

            <div className="no-print px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedRapor(null)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-semibold"
              >
                Tutup Pratinjau
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
