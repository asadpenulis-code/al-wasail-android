import React from 'react';
import { DatabaseState, UserAccount, Guru } from '../types';
import { NavTab } from './Sidebar';
import { CalendarCheck, BookOpen, Award, FileText, AlertTriangle, Users, CheckCircle2, Plus } from 'lucide-react';

interface DashboardGuruProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onNavigate: (tab: NavTab) => void;
  onOpenMutuModal: () => void;
}

export const DashboardGuru: React.FC<DashboardGuruProps> = ({
  db,
  currentUser,
  onNavigate,
  onOpenMutuModal
}) => {
  // Find logged-in guru details
  const currentGuru = db.guru.find(g => g.id === currentUser.relatedId) || db.guru[1]; // default Ust. Kholil
  const kelasAmpuList = db.kelas.filter(k => currentGuru.kelasAmpu.includes(k.id));
  const santriBinaan = db.santri.filter(s => currentGuru.kelasAmpu.includes(s.kelasId) && s.status === 'Aktif');

  // Santri in this teacher's class having difficulty with sentence position
  const santriKesulitan = santriBinaan.filter(s => {
    const prog = db.progres.find(p => p.santriId === s.id);
    return prog?.kesulitanKedudukanKalimat;
  });

  // Recent journals by this teacher
  const myJournals = db.jurnal.filter(j => j.guruId === currentGuru.id).sort((a, b) => b.tanggal.localeCompare(a.tanggal));
  const todayStr = new Date().toISOString().split('T')[0];
  const hasFilledJournalToday = myJournals.some(j => j.tanggal === todayStr);

  return (
    <div className="space-y-6">
      
      {/* Teacher Profile Banner */}
      <div className="bg-gradient-to-r from-[#0B1B3D] via-[#0E2656] to-[#0B1B3D] rounded-2xl text-white p-6 sm:p-7 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
              <span>Portal Guru Asatidz</span>
              <span>·</span>
              <span className="font-mono-num">{currentGuru.nig}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              Ahlan Wa Sahlan, {currentGuru.nama}
            </h1>
            <p className="text-xs text-slate-200">
              Pendidikan Terakhir: {currentGuru.pendidikanTerakhir} · Pengampu: {currentGuru.mapel.join(', ')}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onNavigate('absensi')}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-amber-400 hover:bg-amber-300 text-[#0B1B3D] font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Input Absensi Hari Ini</span>
            </button>
            <button
              onClick={() => onNavigate('jurnal')}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-white/10 hover:bg-white/20 text-white font-medium rounded-xl text-xs transition-colors border border-white/20"
            >
              <Plus className="w-4 h-4 text-amber-300" />
              <span>Isi Jurnal Baru</span>
            </button>
          </div>
        </div>
      </div>

      {/* Today Journal Reminder */}
      {!hasFilledJournalToday ? (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 text-amber-900">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Pemberitahuan:</strong> Anda belum mengisi <strong>Jurnal Pembelajaran</strong> untuk tanggal hari ini ({todayStr}).
            </span>
          </div>
          <button
            onClick={() => onNavigate('jurnal')}
            className="shrink-0 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold transition-colors text-xs"
          >
            Isi Sekarang
          </button>
        </div>
      ) : (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Jurnal pembelajaran untuk hari ini telah tersimpan dan terverifikasi. Jazākumullāhu Khairān.</span>
        </div>
      )}

      {/* Stats Summary for this Teacher */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Kelas yang Diampu</div>
          <div className="text-xl font-bold text-slate-900">
            {kelasAmpuList.map(k => k.nama).join(', ')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Total {santriBinaan.length} santri aktif dalam rombel
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Jurnal Tersimpan</div>
          <div className="text-xl font-bold text-slate-900 font-mono-num">{myJournals.length} Catatan</div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">
            Dokumentasi kurikulum tuntas
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Santri Butuh Drill Tarkib</div>
          <div className="text-xl font-bold text-amber-700 font-mono-num">{santriKesulitan.length} Santri</div>
          <div className="text-[11px] text-slate-500 mt-1">
            Perlu penguatan kedudukan kalimat
          </div>
        </div>

      </div>

      {/* Santri in Teacher's Class needing Attention */}
      {santriKesulitan.length > 0 && (
        <div className="bg-white p-5 rounded-xl border border-amber-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h3 className="text-sm font-bold text-slate-900">
                Santri Binaan yang Masih Kesulitan Menentukan Kedudukan Kalimat
              </h3>
            </div>
            <button
              onClick={onOpenMutuModal}
              className="text-xs font-semibold text-amber-700 hover:underline"
            >
              Matriks Bimbingan →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {santriKesulitan.map(s => {
              const prog = db.progres.find(p => p.santriId === s.id);
              const kls = db.kelas.find(k => k.id === s.kelasId);
              return (
                <div key={s.id} className="p-3 bg-amber-50/50 border border-amber-200/60 rounded-xl space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-sm">{s.nama}</span>
                    <span className="text-[11px] text-slate-500 font-mono-num">{kls?.nama}</span>
                  </div>
                  <div className="text-[11px] text-slate-600">
                    <span className="font-semibold text-slate-800">Catatan: </span>
                    {prog?.catatanKesulitan || s.catatanKhusus}
                  </div>
                  <div className="text-[11px] text-amber-900 bg-amber-100/60 p-2 rounded-lg">
                    <span className="font-semibold">Rekomendasi: </span>
                    {prog?.rekomendasiBimbingan || 'Berikan drilling tarkib ba\'da jam kelas.'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Two Column: Class list & Recent Teaching Log */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Class Santri List */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Daftar Santri Binaan</h3>
            <button
              onClick={() => onNavigate('penilaian')}
              className="text-xs font-medium text-blue-600 hover:underline"
            >
              Input Nilai Rapor →
            </button>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {santriBinaan.map(s => {
              const kls = db.kelas.find(k => k.id === s.kelasId);
              const prog = db.progres.find(p => p.santriId === s.id);
              return (
                <div key={s.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900">{s.nama}</div>
                    <div className="text-[11px] text-slate-400 font-mono-num">
                      NIS: {s.nis} · {kls?.nama}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      prog?.kelancaranMembacaKitab === 'Sangat Baik'
                        ? 'bg-emerald-100 text-emerald-800'
                        : prog?.kesulitanKedudukanKalimat
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {prog?.tahapanAktif || 'Shufhah 1-15'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Journal History */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Riwayat Jurnal Mengajar Anda</h3>
            <button
              onClick={() => onNavigate('jurnal')}
              className="text-xs font-medium text-blue-600 hover:underline"
            >
              Kelola Jurnal →
            </button>
          </div>

          <div className="space-y-3 text-xs">
            {myJournals.slice(0, 3).map(j => (
              <div key={j.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{j.kelasNama}</span>
                  <span className="text-[10px] text-slate-500 font-mono-num">{j.tanggal}</span>
                </div>
                <div className="text-[11px] text-slate-700">
                  <span className="font-semibold text-slate-900">Materi: </span>
                  {j.materiDiajarkan}
                </div>
                <div className="text-[11px] text-slate-500 line-clamp-1">
                  <span className="font-medium text-slate-700">Capaian: </span>
                  {j.materiSelesai}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
