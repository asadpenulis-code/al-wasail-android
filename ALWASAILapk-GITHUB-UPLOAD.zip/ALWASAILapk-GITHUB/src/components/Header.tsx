import React from 'react';
import { UserAccount, PengaturanLembaga } from '../types';
import { Logo } from './Logo';
import { Shield, BookOpen, Download, Sparkles, LogOut, Menu } from 'lucide-react';

interface HeaderProps {
  currentUser: UserAccount;
  onSignOut: () => Promise<void>;
  pengaturan: PengaturanLembaga;
  onOpenMutuModal: () => void;
  onOpenBackupModal: () => void;
  onToggleSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onSignOut,
  pengaturan,
  onOpenMutuModal,
  onOpenBackupModal,
  onToggleSidebar
}) => {

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-[0_1px_3px_rgba(0,0,0,0.04)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Left Zone: Hamburger for Mobile + Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
              aria-label="Toggle navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <Logo size="md" logoUrl={pengaturan.logoUrl} />
          </div>

          {/* Slogan Banner on Desktop */}
          <div className="hidden xl:flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span className="font-arabic text-amber-700 font-semibold text-base">
              {pengaturan.sloganArab}
            </span>
            <span className="text-slate-300">·</span>
            <span className="italic text-slate-600">
              {pengaturan.sloganIndo}
            </span>
          </div>

          {/* Right Zone: Quality Analysis, Backup, and authenticated account */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Quick Mutual Quality Analyzer (Saran Utama Pengembangan) */}
            <button
              onClick={onOpenMutuModal}
              title="Analisis Mutu Metodologi Al-Wasā'il"
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#0B1B3D] bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Analisis Mutu</span>
            </button>

            {/* Backup DB quick button */}
            <button
              onClick={onOpenBackupModal}
              title="Pencadangan & Pemulihan Database"
              className="p-1.5 text-slate-600 hover:text-[#0B1B3D] hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 rounded-lg bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 border border-slate-200">
              {currentUser.role === 'admin' ? <Shield className="w-4 h-4 text-amber-600" /> : <BookOpen className="w-4 h-4 text-blue-600" />}
              <span className="hidden sm:inline max-w-[150px] truncate font-semibold">{currentUser.name}</span>
            </div>
            <button onClick={() => void onSignOut()} title="Keluar" className="p-2 rounded-lg text-slate-600 hover:bg-slate-100" aria-label="Keluar dari akun">
              <LogOut className="w-4 h-4" />
            </button>

          </div>

        </div>
      </div>
    </header>
  );
};
