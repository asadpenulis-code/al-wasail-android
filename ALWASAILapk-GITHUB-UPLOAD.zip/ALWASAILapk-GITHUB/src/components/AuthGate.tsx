import React, { useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { BookOpen, ShieldCheck, Clock3, LogOut, LoaderCircle } from 'lucide-react';
import { supabase } from '../services/supabase';
import type { UserAccount } from '../types';

interface Profile { id: string; nama: string; role: 'admin' | 'guru'; status: 'menunggu' | 'disetujui' | 'ditolak'; }

export const AuthGate: React.FC<{ children: (user: UserAccount, signOut: () => Promise<void>) => React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [nama, setNama] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [pending, setPending] = useState<Profile[]>([]);

  const loadProfile = async (activeSession: Session | null) => {
    setSession(activeSession);
    if (!activeSession?.user) { setProfile(null); setLoading(false); return; }
    const { data, error } = await supabase.from('profiles').select('id,nama,role,status').eq('id', activeSession.user.id).maybeSingle();
    if (error || !data) { setProfile(null); setMessage(error?.message || 'Profil akun belum tersedia. Silakan hubungi administrator.'); setLoading(false); return; }
    setProfile(data as Profile);
    setLoading(false);
  };

  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(({ data }) => { if (alive) void loadProfile(data.session); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (alive) { setLoading(true); void loadProfile(nextSession); }
    });
    return () => { alive = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (profile?.role === 'admin' && profile.status === 'disetujui') {
      supabase.from('profiles').select('id,nama,role,status').eq('role', 'guru').eq('status', 'menunggu').then(({ data }) => setPending((data || []) as Profile[]));
    }
  }, [profile]);

  const signOut = async () => { await supabase.auth.signOut(); setProfile(null); setSession(null); setPending([]); };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); setBusy(true); setMessage('');
    try {
      if (mode === 'register') {
        if (!nama.trim()) throw new Error('Nama lengkap wajib diisi.');
        const { data, error } = await supabase.auth.signUp({ email: email.trim(), password, options: { data: { nama: nama.trim() } } });
        if (error) throw error;
        if (data.session) await loadProfile(data.session);
        setMessage('Pendaftaran berhasil. Jika diminta verifikasi email, silakan periksa kotak masuk. Akun guru menunggu persetujuan admin.');
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        await loadProfile(data.session);
      }
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Terjadi kesalahan.'); }
    finally { setBusy(false); }
  };

  const approve = async (id: string) => {
    setBusy(true); setMessage('');
    const { error } = await supabase.from('profiles').update({ status: 'disetujui' }).eq('id', id);
    if (error) setMessage(error.message);
    else setPending(items => items.filter(item => item.id !== id));
    setBusy(false);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center text-slate-600"><LoaderCircle className="animate-spin mr-2"/> Memeriksa akun AL WASAIL…</div>;
  if (session && profile?.status === 'menunggu') return <StatusScreen title="Pendaftaran Menunggu Persetujuan" detail="Akun guru telah terdaftar. Akses aplikasi akan dibuka setelah disetujui oleh Admin AL WASAIL." onSignOut={signOut} />;
  if (session && profile?.status === 'ditolak') return <StatusScreen title="Akun Belum Disetujui" detail="Silakan menghubungi Admin AL WASAIL untuk memperoleh informasi lebih lanjut." onSignOut={signOut} />;
  if (session && profile?.status === 'disetujui' && profile.role === 'admin') return <>{children({ id: profile.id, username: session.user.email || '', name: profile.nama, role: 'admin' }, signOut)}<div className="fixed bottom-3 right-3 z-50 max-w-xs rounded-xl border bg-white p-3 shadow-lg text-xs"><div className="font-semibold mb-2">Persetujuan Guru ({pending.length})</div>{pending.length === 0 ? <p className="text-slate-500">Tidak ada pendaftaran menunggu.</p> : pending.map(item => <div key={item.id} className="flex items-center justify-between gap-2 py-1"><span>{item.nama}</span><button disabled={busy} onClick={() => void approve(item.id)} className="rounded-lg bg-emerald-600 px-2 py-1 text-white">Setujui</button></div>)}</div></>;
  if (session && profile?.status === 'disetujui' && profile.role === 'guru') return <>{children({ id: profile.id, username: session.user.email || '', name: profile.nama, role: 'guru' }, signOut)}</>;

  return <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4"><div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-200 p-6 sm:p-8"><div className="flex items-center gap-3 mb-6"><div className="rounded-xl bg-[#0B1B3D] p-3 text-white"><BookOpen/></div><div><h1 className="text-xl font-extrabold text-[#0B1B3D]">AL WASAIL</h1><p className="text-xs text-slate-500">Sistem Informasi & Manajemen Pendidikan</p></div></div><div className="flex rounded-xl bg-slate-100 p-1 mb-5"><button onClick={() => {setMode('login');setMessage('');}} className={`flex-1 rounded-lg py-2 text-sm font-semibold ${mode==='login'?'bg-white shadow text-[#0B1B3D]':'text-slate-500'}`}>Masuk</button><button onClick={() => {setMode('register');setMessage('');}} className={`flex-1 rounded-lg py-2 text-sm font-semibold ${mode==='register'?'bg-white shadow text-[#0B1B3D]':'text-slate-500'}`}>Daftar Guru</button></div><form onSubmit={submit} className="space-y-4">{mode==='register' && <label className="block text-sm font-medium text-slate-700">Nama lengkap<input value={nama} onChange={e=>setNama(e.target.value)} required className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-3 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Nama lengkap guru"/></label>}<label className="block text-sm font-medium text-slate-700">Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-3 outline-none focus:ring-2 focus:ring-blue-500" placeholder="nama@email.com"/></label><label className="block text-sm font-medium text-slate-700">Kata sandi<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={6} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-3 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Minimal 6 karakter"/></label><button disabled={busy} className="w-full rounded-xl bg-[#0B1B3D] py-3 font-bold text-white disabled:opacity-60">{busy?'Memproses…':mode==='login'?'Masuk ke AL WASAIL':'Daftar sebagai Guru'}</button></form>{message && <p className="mt-4 rounded-lg bg-amber-50 p-3 text-sm text-amber-800">{message}</p>}<p className="mt-5 text-center text-xs text-slate-400">Akses guru diberikan setelah persetujuan administrator.</p></div></div>;
};

const StatusScreen: React.FC<{title:string;detail:string;onSignOut:()=>Promise<void>}> = ({title,detail,onSignOut}) => <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4"><div className="max-w-md rounded-2xl bg-white p-8 text-center shadow-xl border"><Clock3 className="mx-auto mb-4 h-10 w-10 text-amber-500"/><h1 className="text-xl font-bold text-slate-800">{title}</h1><p className="mt-3 text-sm leading-6 text-slate-600">{detail}</p><button onClick={()=>void onSignOut()} className="mt-6 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white"><LogOut size={16}/> Keluar</button></div></div>;
