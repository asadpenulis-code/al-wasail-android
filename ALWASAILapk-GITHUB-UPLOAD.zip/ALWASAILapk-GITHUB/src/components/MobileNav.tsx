import React from 'react';
import { NavTab } from './Sidebar';
import { UserRole } from '../types';
import { LayoutDashboard, Users, CalendarCheck, BookOpen, Menu } from 'lucide-react';

interface MobileNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  userRole: UserRole;
  onToggleSidebar: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeTab,
  onSelectTab,
  userRole,
  onToggleSidebar
}) => {
  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1 shadow-lg no-print">
      <div className="flex items-center justify-around h-14">
        <button
          onClick={() => onSelectTab('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 py-1 ${
            activeTab === 'dashboard' ? 'text-[#0B1B3D] font-bold' : 'text-slate-500'
          }`}
        >
          <LayoutDashboard className={`w-5 h-5 ${activeTab === 'dashboard' ? 'stroke-[2.5]' : ''}`} />
          <span className="text-[10px] mt-0.5">Dasbor</span>
        </button>

        {userRole === 'santri' ? (
          <button
            onClick={() => onSelectTab('penilaian')}
            className={`flex flex-col items-center justify-center flex-1 py-1 ${
              activeTab === 'penilaian' ? 'text-[#0B1B3D] font-bold' : 'text-slate-500'
            }`}
          >
            <BookOpen className={`w-5 h-5 ${activeTab === 'penilaian' ? 'stroke-[2.5]' : ''}`} />
            <span className="text-[10px] mt-0.5">Rapor</span>
          </button>
        ) : (
          <button
            onClick={() => onSelectTab('santri')}
            className={`flex flex-col items-center justify-center flex-1 py-1 ${
              activeTab === 'santri' ? 'text-[#0B1B3D] font-bold' : 'text-slate-500'
            }`}
          >
            <Users className={`w-5 h-5 ${activeTab === 'santri' ? 'stroke-[2.5]' : ''}`} />
            <span className="text-[10px] mt-0.5">Santri</span>
          </button>
        )}

        <button
          onClick={() => onSelectTab('absensi')}
          className={`flex flex-col items-center justify-center flex-1 py-1 ${
            activeTab === 'absensi' ? 'text-[#0B1B3D] font-bold' : 'text-slate-500'
          }`}
        >
          <CalendarCheck className={`w-5 h-5 ${activeTab === 'absensi' ? 'stroke-[2.5]' : ''}`} />
          <span className="text-[10px] mt-0.5">Absensi</span>
        </button>

        <button
          onClick={() => onSelectTab('pembelajaran')}
          className={`flex flex-col items-center justify-center flex-1 py-1 ${
            activeTab === 'pembelajaran' ? 'text-[#0B1B3D] font-bold' : 'text-slate-500'
          }`}
        >
          <BookOpen className={`w-5 h-5 ${activeTab === 'pembelajaran' ? 'stroke-[2.5]' : ''}`} />
          <span className="text-[10px] mt-0.5">Al-Wasā'il</span>
        </button>

        <button
          onClick={onToggleSidebar}
          className="flex flex-col items-center justify-center flex-1 py-1 text-slate-500"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Menu</span>
        </button>
      </div>
    </nav>
  );
};
