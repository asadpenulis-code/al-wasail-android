import React, { useState } from 'react';
import { DatabaseState } from '../types';
import { X, Sparkles, AlertTriangle, CheckCircle2, TrendingDown, Clock, BookOpen, UserX, Printer, ArrowRight } from 'lucide-react';

interface MutuAnalitikModalProps {
  db: DatabaseState;
  onClose: () => void;
  onSelectSantri?: (santriId: string) => void;
  onSelectGuru?: (guruId: string) => void;
}

export const MutuAnalitikModal: React.FC<MutuAnalitikModalProps> = ({
  db,
  onClose,
  onSelectSantri,
  onSelectGuru
}) => {
  const [activeTab, setActiveTab] = useState<'semua' | 'kedudukan' | 'mahir' | 'kelas' | 'jurnal' | 'target'>('semua');

  // 1. Santri kesulitan menentukan kedudukan kalimat
  const santriKesulitanKedudukan = db.santri.filter(s => {
    const prog = db.progres.find(p => p.santriId === s.id);
    const pen = db.penilaian.find(p => p.santriId === s.id);
    const nahwuBad = pen?.evaluasi.some(e => e.bidang === 'Nahwu' && e.predikat === 'Rodi');
    return prog?.kesulitanKedudukanKalimat || nahwuBad;
  }).map(s => {
    const prog = db.progres.find(p => p.santriId === s.id);
    const kls = db.kelas.find(k => k.id === s.kelasId);
    return {
      santri: s,
      kelasNama: kls?.nama || '-',
      catatan: prog?.catatanKesulitan || s.catatanKhusus || 'Kesulitan membedakan Fa\'il, Maf\'ul, atau Tarkib Manshubat.',
      rekomendasi: prog?.rekomendasiBimbingan || 'Bimbingan intensif ba\'da shalat jama\'ah dengan rumus praktis Al-Wasā\'il.'
    };
  });

  // 2. Santri mahir membaca kitab
  const santriMahirBaca = db.santri.filter(s => {
    const prog = db.progres.find(p => p.santriId === s.id);
    const pen = db.penilaian.find(p => p.santriId === s.id);
    const bacaGood = pen?.evaluasi.some(e => e.bidang === 'Kemampuan membaca kitab' && e.predikat === 'Jayyid' && e.nilaiAngka >= 80);
    return prog?.kelancaranMembacaKitab === 'Sangat Baik' || prog?.kelancaranMembacaKitab === 'Baik' || bacaGood;
  }).map(s => {
    const prog = db.progres.find(p => p.santriId === s.id);
    const kls = db.kelas.find(k => k.id === s.kelasId);
    const tashih = db.tashih.find(t => t.santriId === s.id);
    return {
      santri: s,
      kelasNama: kls?.nama || '-',
      tahapan: prog?.tahapanAktif || 'Takhassus',
      statusTashih: tashih ? (tashih.statusLulus === 'Lulus' ? 'Sudah Lulus Tashih' : 'Terdaftar Ujian') : 'Siap Diajukan Tashih'
    };
  });

  // 3. Analisis laju kelas
  const kelasStats = db.kelas.map(k => {
    const santriInClass = db.santri.filter(s => s.kelasId === k.id && s.status === 'Aktif');
    const santriIds = santriInClass.map(s => s.id);
    
    // Evaluation scores in class
    const evaluations = db.penilaian.filter(p => santriIds.includes(p.santriId));
    let totalScore = 0;
    let scoreCount = 0;
    evaluations.forEach(p => {
      p.evaluasi.forEach(e => {
        totalScore += e.nilaiAngka;
        scoreCount++;
      });
    });
    const avgScore = scoreCount > 0 ? Math.round(totalScore / scoreCount) : 0;

    // Santri struggling
    const strugglingCount = santriInClass.filter(s => 
      db.progres.some(p => p.santriId === s.id && p.kesulitanKedudukanKalimat)
    ).length;

    const wali = db.guru.find(g => g.id === k.waliKelasId);

    const statusPerkembangan = avgScore >= 80 ? 'Cepat & Mandiri' : avgScore >= 68 ? 'Stabil / Wajar' : 'Perlu Akselerasi & Pengawasan';
    const statusColor = avgScore >= 80 ? 'text-emerald-700 bg-emerald-50' : avgScore >= 68 ? 'text-blue-700 bg-blue-50' : 'text-amber-800 bg-amber-50';

    return {
      kelas: k,
      waliNama: wali?.nama || 'Belum Ditentukan',
      totalSantri: santriInClass.length,
      avgScore,
      strugglingCount,
      statusPerkembangan,
      statusColor
    };
  });

  // 4. Guru yang belum mengisi jurnal mengajar terkini
  const todayStr = new Date().toISOString().split('T')[0];
  const guruStatusJurnal = db.guru.filter(g => g.status === 'Aktif').map(g => {
    const journals = db.jurnal.filter(j => j.guruId === g.id);
    const lastJournal = journals.sort((a, b) => b.tanggal.localeCompare(a.tanggal))[0];
    const isTodayFilled = journals.some(j => j.tanggal === todayStr);

    return {
      guru: g,
      totalJurnal: journals.length,
      lastDate: lastJournal?.tanggal || 'Belum pernah',
      isTodayFilled,
      kelasAmpu: g.kelasAmpu.map(cId => db.kelas.find(k => k.id === cId)?.nama).filter(Boolean).join(', ')
    };
  });

  // 5. Target materi yang belum tuntas
  const targetTertunda = [
    { materi: 'Pembedaan Hal vs Tamyiz pada Ibarat Kitab Gundul', kategori: 'Nahwu / Tarkib', santriTerdampak: 4, prioritas: 'Tinggi', solusi: 'Berikan latihan isim nakirah berpola مشتق vs جامد' },
    { materi: '19 Kaidah I\'lal: Kaidah 11 - 15 (Bina\' Lafif & Naqish)', kategori: 'Sharraf', santriTerdampak: 3, prioritas: 'Sedang', solusi: 'Tashrif lughowi berjamaah setiap ba\'da Maghrib' },
    { materi: 'Kelancaran Membaca Yāqūtun Nafīs Shufhah 16–25', kategori: 'Membaca Kitab', santriTerdampak: 2, prioritas: 'Tinggi', solusi: 'Talaqqi individual 10 menit bersama wali kelas' },
    { materi: 'Setoran Hafalan Nadzom Dasar Kaidah Al-Wasā\'il', kategori: 'Hafalan', santriTerdampak: 3, prioritas: 'Sedang', solusi: 'Jadwalkan tasmi\' mingguan tiap malam Jum\'at' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl my-8 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-[#0B1B3D] via-[#0E2656] to-[#0B1B3D] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-400/20 text-amber-300 rounded-xl border border-amber-300/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold flex items-center gap-2">
                <span>Pusat Kendali Mutu Metodologi AL-WASĀ’IL</span>
                <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-200 border border-amber-300/30">
                  Keputusan Berbasis Data
                </span>
              </h2>
              <p className="text-xs text-slate-300">
                Lembaga Al-Wasā'il PP Al-Ihsan Jrangoan · Evaluasi Kualitas & Intervensi Pedagogis
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors border border-white/20"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Hasil</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Filter Bar */}
        <div className="flex items-center gap-1 px-6 py-3 border-b border-slate-200 bg-slate-50 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('semua')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'semua' ? 'bg-[#0B1B3D] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            Ikhtisar Komprehensif
          </button>
          <button
            onClick={() => setActiveTab('kedudukan')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'kedudukan' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Kesulitan Kedudukan Kalimat ({santriKesulitanKedudukan.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('mahir')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'mahir' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Santri Mahir Baca Kitab ({santriMahirBaca.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('kelas')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'kelas' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5" />
            <span>Laju Perkembangan Kelas</span>
          </button>
          <button
            onClick={() => setActiveTab('jurnal')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'jurnal' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Kepatuhan Jurnal Asatidz</span>
          </button>
          <button
            onClick={() => setActiveTab('target')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'target' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Target Materi Tertunda</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto space-y-6">

          {/* KPI Matrix Overview */}
          {(activeTab === 'semua' || activeTab === 'kedudukan') && (
            <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-bold text-amber-950">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>1. Santri yang Masih Kesulitan Menentukan Kedudukan Kalimat</span>
                </div>
                <span className="text-xs font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md">
                  {santriKesulitanKedudukan.length} Santri Terdeteksi
                </span>
              </div>
              <p className="text-xs text-amber-900/80 mb-3">
                Santri pada daftar ini membutuhkan intervensi pedagogis berupa rumus taktis pembedaan I'rab, Fa'il, Maf'ul, Mubtada-Khabar, Hal, dan Tamyiz.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {santriKesulitanKedudukan.map(item => (
                  <div key={item.santri.id} className="bg-white p-3.5 rounded-xl border border-amber-200/60 shadow-2xs space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-bold text-slate-900 text-sm">{item.santri.nama}</div>
                        <div className="text-[11px] text-slate-500 font-mono-num">
                          NIS: {item.santri.nis} · Kelas {item.kelasNama}
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-100 text-rose-800">
                        Perlu Remedial
                      </span>
                    </div>

                    <div className="text-xs text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <span className="font-semibold text-slate-900">Kendala: </span>
                      {item.catatan}
                    </div>

                    <div className="text-xs text-amber-900 bg-amber-50/50 p-2 rounded-lg border border-amber-100 flex items-start gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold">Rekomendasi Kebijakan: </span>
                        {item.rekomendasi}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Mahir Baca Kitab */}
          {(activeTab === 'semua' || activeTab === 'mahir') && (
            <div className="bg-emerald-50/60 border border-emerald-200/80 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-bold text-emerald-950">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>2. Santri yang Sudah Mampu Membaca Kitab dengan Baik (Siap Tashih)</span>
                </div>
                <span className="text-xs font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md">
                  {santriMahirBaca.length} Santri Mahir
                </span>
              </div>
              <p className="text-xs text-emerald-900/80 mb-3">
                Santri dengan kelancaran membaca kitab kuning gundul sangat baik dan i'rab tarkib tuntas. Dapat diakselerasi menjadi kader musahhih muda.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {santriMahirBaca.map(item => (
                  <div key={item.santri.id} className="bg-white p-3.5 rounded-xl border border-emerald-200/60 shadow-2xs space-y-1.5">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-bold text-slate-900 text-sm">{item.santri.nama}</div>
                        <div className="text-[11px] text-slate-500 font-mono-num">
                          NIS: {item.santri.nis} · Kelas {item.kelasNama}
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                        {item.statusTashih}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600">
                      <span className="font-semibold text-slate-800">Capaian Tahapan: </span>
                      {item.tahapan}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Laju Perkembangan Kelas */}
          {(activeTab === 'semua' || activeTab === 'kelas') && (
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <TrendingDown className="w-4 h-4 text-blue-600" />
                  <span>3. Analisis Laju Perkembangan Belajar Antarkelas</span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Nama Rombel Kelas</th>
                      <th className="py-2.5 px-3">Wali Kelas</th>
                      <th className="py-2.5 px-3 text-center">Jml Santri</th>
                      <th className="py-2.5 px-3 text-center">Rata Nilai</th>
                      <th className="py-2.5 px-3 text-center">Santri Butuh Bantuan</th>
                      <th className="py-2.5 px-3">Status Laju Belajar</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {kelasStats.map(stat => (
                      <tr key={stat.kelas.id} className="hover:bg-slate-50/80">
                        <td className="py-3 px-3 font-bold text-slate-900">{stat.kelas.nama}</td>
                        <td className="py-3 px-3 text-slate-700">{stat.waliNama}</td>
                        <td className="py-3 px-3 text-center font-mono-num">{stat.totalSantri}</td>
                        <td className="py-3 px-3 text-center font-mono-num font-bold text-slate-800">{stat.avgScore || '-'}</td>
                        <td className="py-3 px-3 text-center">
                          {stat.strugglingCount > 0 ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                              {stat.strugglingCount} Santri
                            </span>
                          ) : (
                            <span className="text-slate-400">Nihil</span>
                          )}
                        </td>
                        <td className="py-3 px-3">
                          <span className={`px-2.5 py-1 rounded-md text-[11px] font-semibold ${stat.statusColor}`}>
                            {stat.statusPerkembangan}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Kepatuhan Jurnal Asatidz */}
          {(activeTab === 'semua' || activeTab === 'jurnal') && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <Clock className="w-4 h-4 text-purple-600" />
                  <span>4. Pengawasan Kepatuhan Pengisian Jurnal Pembelajaran Guru</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {guruStatusJurnal.map(item => (
                  <div key={item.guru.id} className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs space-y-2">
                    <div className="font-bold text-slate-900 text-xs truncate">{item.guru.nama}</div>
                    <div className="text-[11px] text-slate-500 font-mono-num">{item.guru.nig}</div>
                    <div className="text-[11px] text-slate-600">
                      <span className="font-medium">Kelas:</span> {item.kelasAmpu || '-'}
                    </div>

                    <div className="pt-1 border-t border-slate-100 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Jurnal Terakhir:</span>
                      <span className="font-mono-num font-medium text-slate-700">{item.lastDate}</span>
                    </div>

                    <div>
                      {item.isTodayFilled ? (
                        <div className="text-center py-1 rounded bg-emerald-50 text-emerald-700 font-semibold text-[10px]">
                          ✓ Jurnal Hari Ini Tuntas
                        </div>
                      ) : (
                        <div className="text-center py-1 rounded bg-amber-50 text-amber-800 font-semibold text-[10px]">
                          Belum Isi Jurnal Hari Ini
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Target Pembelajaran Tertunda */}
          {(activeTab === 'semua' || activeTab === 'target') && (
            <div className="bg-rose-50/50 border border-rose-200/80 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-bold text-rose-950">
                  <BookOpen className="w-4 h-4 text-rose-600" />
                  <span>5. Evaluasi Target Materi yang Belum Mencapai Standar</span>
                </div>
              </div>

              <div className="space-y-2.5">
                {targetTertunda.map((item, idx) => (
                  <div key={idx} className="bg-white p-3 rounded-xl border border-rose-200/60 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                          Prioritas {item.prioritas}
                        </span>
                        <span className="text-slate-400">·</span>
                        <span className="font-semibold text-slate-600">{item.kategori}</span>
                      </div>
                      <div className="font-bold text-slate-900">{item.materi}</div>
                      <div className="text-[11px] text-slate-600">
                        <span className="font-semibold text-slate-800">Solusi Instruksional: </span>
                        {item.solusi}
                      </div>
                    </div>
                    <div className="shrink-0 text-right sm:border-l sm:border-slate-100 sm:pl-4">
                      <div className="text-slate-500 text-[11px]">Santri Teridentifikasi</div>
                      <div className="text-base font-bold text-rose-700 font-mono-num">{item.santriTerdampak} Santri</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <div className="text-slate-500">
            Data ini dihitung otomatis secara live dari database nilai, progres, absensi, dan jurnal harian.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#0B1B3D] hover:bg-[#132c63] text-white font-medium rounded-lg transition-colors"
          >
            Tutup Panel
          </button>
        </div>

      </div>
    </div>
  );
};
