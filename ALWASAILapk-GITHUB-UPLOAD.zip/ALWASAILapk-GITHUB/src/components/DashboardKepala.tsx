import React from 'react';
import { DatabaseState, UserAccount } from '../types';
import { NavTab } from './Sidebar';
import { Building2, Sparkles, Award, FileCheck2, Users, TrendingUp, AlertTriangle, CheckCircle2, ArrowUpRight } from 'lucide-react';

interface DashboardKepalaProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onNavigate: (tab: NavTab) => void;
  onOpenMutuModal: () => void;
}

export const DashboardKepala: React.FC<DashboardKepalaProps> = ({
  db,
  currentUser,
  onNavigate,
  onOpenMutuModal
}) => {
  const totalSantri = db.santri.length;
  const santriAktif = db.santri.filter(s => s.status === 'Aktif').length;
  const totalGuru = db.guru.length;
  const totalTashih = db.tashih.length;
  const lulusTashih = db.tashih.filter(t => t.statusLulus === 'Lulus').length;
  const santriKesulitan = db.progres.filter(p => p.kesulitanKedudukanKalimat).length;
  const santriMahir = db.progres.filter(p => p.kelancaranMembacaKitab === 'Sangat Baik' || p.kelancaranMembacaKitab === 'Baik').length;

  return (
    <div className="space-y-6">
      
      {/* Principal Welcome Banner */}
      <div className="bg-gradient-to-r from-[#0B1B3D] via-[#0E2656] to-[#0B1B3D] rounded-2xl text-white p-6 sm:p-7 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
              <Building2 className="w-4 h-4 text-amber-400" />
              <span>Portal Pengawasan & Pimpinan Lembaga</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              Inspeksi Mutu & Pengawasan Lembaga Al-Wasā’il
            </h1>
            <p className="text-xs text-slate-200">
              Pondok Pesantren Al-Ihsan Jrangoan · Pengambil Kebijakan Kurikulum & Standar Tashih
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenMutuModal}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-[#0B1B3D] font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <Sparkles className="w-4 h-4 text-[#0B1B3D]" />
              <span>Buka Analisis Mutu Lengkap</span>
            </button>
          </div>
        </div>
      </div>

      {/* Strategic KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Populasi Santri</div>
          <div className="text-2xl font-bold text-slate-900 font-mono-num">{santriAktif}</div>
          <div className="text-[11px] text-slate-500 mt-1">Santri aktif terdaftar</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Kader Mahir Baca Kitab</div>
          <div className="text-2xl font-bold text-emerald-700 font-mono-num">{santriMahir}</div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">Siap tashih & matang</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Perlu Intervensi Tarkib</div>
          <div className="text-2xl font-bold text-amber-700 font-mono-num">{santriKesulitan}</div>
          <div className="text-[11px] text-amber-800 font-medium mt-1">Kesulitan kedudukan kalimat</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Kelulusan Tashih</div>
          <div className="text-2xl font-bold text-purple-700 font-mono-num">{lulusTashih}</div>
          <div className="text-[11px] text-purple-600 font-medium mt-1">Syahadah resmi diterbitkan</div>
        </div>

      </div>

      {/* Strategic Decision Matrix */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-bold text-slate-900">Dasar Pengambilan Kebijakan Kurikulum Al-Wasā'il</h3>
          </div>
          <button
            onClick={onOpenMutuModal}
            className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1"
          >
            <span>Buka Panel Detail</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          
          <div className="p-3.5 rounded-xl bg-amber-50/60 border border-amber-200/80 space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-950">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Akselerasi Tarkib Santri</span>
            </div>
            <p className="text-[11px] text-amber-900/80 leading-relaxed">
              Ditemukan santri di rombel I'dadiyah dan Takhassus A yang masih tertukar membedakan Fa'il dan Naibul Fa'il.
            </p>
            <div className="text-[11px] font-semibold text-amber-900 pt-1 border-t border-amber-200/60">
              Kebijakan: Tambahkan jam talaqqi 30 menit setiap malam Rabu.
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-200/80 space-y-2">
            <div className="flex items-center gap-2 font-bold text-emerald-950">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Standarisasi Musahhih</span>
            </div>
            <p className="text-[11px] text-emerald-900/80 leading-relaxed">
              Tingkat kelulusan tashih Gelombang I mencapai 80%. Peserta cabang eksternal siap diajukan ke Gelombang II.
            </p>
            <div className="text-[11px] font-semibold text-emerald-900 pt-1 border-t border-emerald-200/60">
              Kebijakan: Pertahankan KKM Tashih di angka 70 dan perkuat rubrik Sharraf.
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-blue-50/60 border border-blue-200/80 space-y-2">
            <div className="flex items-center gap-2 font-bold text-blue-950">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <span>Pengawasan Jurnal Asatidz</span>
            </div>
            <p className="text-[11px] text-blue-900/80 leading-relaxed">
              Seluruh asatidz aktif mengisi jurnal pembelajaran dengan rata-rata tingkat ketuntasan materi 88%.
            </p>
            <div className="text-[11px] font-semibold text-blue-900 pt-1 border-t border-blue-200/60">
              Kebijakan: Berikan apresiasi pada rapat asatidz bulanan mendatang.
            </div>
          </div>

        </div>
      </div>

      {/* Two Column Layout: Ujian Tashih Overview & Rombel Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Tashih Results Summary */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Hasil Evaluasi Tashih Al-Wasā'il</h3>
            <button
              onClick={() => onNavigate('tashih')}
              className="text-xs font-medium text-blue-600 hover:underline"
            >
              Lihat Syahadah →
            </button>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {db.tashih.map(t => (
              <div key={t.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-900">{t.nama}</div>
                  <div className="text-[11px] text-slate-500 font-mono-num">
                    {t.nomorPeserta} · {t.lembagaAsal}
                  </div>
                </div>
                <div className="text-right">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                    t.statusLulus === 'Lulus'
                      ? 'bg-emerald-100 text-emerald-800'
                      : t.statusLulus === 'Tidak Lulus'
                      ? 'bg-rose-100 text-rose-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {t.statusLulus} {t.predikat ? `(${t.predikat})` : ''}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Asatidz Activity Summary */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Aktivitas Mengajar Asatidz</h3>
            <button
              onClick={() => onNavigate('jurnal')}
              className="text-xs font-medium text-blue-600 hover:underline"
            >
              Semua Jurnal →
            </button>
          </div>

          <div className="space-y-2 text-xs">
            {db.guru.map(g => {
              const jCount = db.jurnal.filter(j => j.guruId === g.id).length;
              return (
                <div key={g.id} className="p-2.5 rounded-lg bg-slate-50 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900">{g.nama}</div>
                    <div className="text-[11px] text-slate-500">{g.mapel.join(', ')}</div>
                  </div>
                  <div className="text-right">
                    <span className="font-mono-num font-bold text-slate-800">{jCount}</span>
                    <span className="text-[10px] text-slate-400 ml-1">Jurnal Terisi</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
