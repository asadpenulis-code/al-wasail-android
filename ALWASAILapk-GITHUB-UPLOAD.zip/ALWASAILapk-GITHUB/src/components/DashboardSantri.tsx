import React from 'react';
import { DatabaseState, UserAccount } from '../types';
import { NavTab } from './Sidebar';
import { GraduationCap, Award, CalendarCheck, BookOpen, User, CheckCircle2, AlertCircle, FileCheck2, ArrowRight } from 'lucide-react';

interface DashboardSantriProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onNavigate: (tab: NavTab) => void;
}

export const DashboardSantri: React.FC<DashboardSantriProps> = ({
  db,
  currentUser,
  onNavigate
}) => {
  // Find current santri
  const santri = db.santri.find(s => s.id === currentUser.relatedId) || db.santri[0]; // default Muhammad Faiz
  const kls = db.kelas.find(k => k.id === santri.kelasId);
  const wali = db.guru.find(g => g.id === kls?.waliKelasId);
  const prog = db.progres.find(p => p.santriId === santri.id);
  const pen = db.penilaian.find(p => p.santriId === santri.id);
  const tashih = db.tashih.find(t => t.santriId === santri.id);

  // Calculate attendance for this santri
  const myAttendance = db.absensi.flatMap(s => s.records.filter(r => r.santriId === santri.id));
  const totalSesi = myAttendance.length;
  const totalHadir = myAttendance.filter(a => a.status === 'Hadir').length;
  const totalSakit = myAttendance.filter(a => a.status === 'Sakit').length;
  const totalIzin = myAttendance.filter(a => a.status === 'Izin').length;
  const totalAlfa = myAttendance.filter(a => a.status === 'Alfa').length;
  const persenKehadiran = totalSesi > 0 ? Math.round((totalHadir / totalSesi) * 100) : 100;

  return (
    <div className="space-y-6">
      
      {/* Santri Identity Banner */}
      <div className="bg-gradient-to-r from-[#0B1B3D] via-[#0E2656] to-[#0B1B3D] rounded-2xl text-white p-6 sm:p-7 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-400/20 border border-amber-300/40 text-amber-300 flex items-center justify-center font-bold text-xl shrink-0">
              {santri.nama.charAt(0)}
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
                <span>Santri Al-Wasā’il</span>
                <span>·</span>
                <span className="font-mono-num">NIS: {santri.nis}</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {santri.nama}
              </h1>
              <p className="text-xs text-slate-200">
                Kelas: <span className="font-semibold text-amber-200">{kls?.nama}</span> · Wali Kelas: {wali?.nama || '-'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigate('penilaian')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-[#0B1B3D] font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <Award className="w-4 h-4" />
              <span>Lihat Rapor Lengkap</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Tahapan Al-Wasā'il</div>
          <div className="text-base font-bold text-slate-900 truncate">
            {prog?.tahapanAktif || 'Marhalah 1'}
          </div>
          <div className="text-[11px] text-blue-600 font-medium mt-1">
            Status: {prog?.kelancaranMembacaKitab || 'Dalam Pembelajaran'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Presensi Kehadiran</div>
          <div className="text-xl font-bold text-emerald-700 font-mono-num">
            {persenKehadiran}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {totalHadir} Hadir dari {totalSesi} Sesi
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Evaluasi Terkini</div>
          <div className="text-xl font-bold text-amber-700 font-mono-num">
            {pen ? `${pen.evaluasi[0]?.nilaiAngka || 85} / 100` : 'Belum Ada'}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {pen ? 'Predikat Jayyid' : 'Menunggu Evaluasi'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Status Tashih</div>
          <div className="text-base font-bold text-purple-700 truncate">
            {tashih ? (tashih.statusLulus === 'Lulus' ? 'Lulus (Syahadah)' : 'Terdaftar Ujian') : 'Tahap Binaan'}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {tashih?.nomorSyahadah || 'Persiapan Ujian'}
          </div>
        </div>

      </div>

      {/* Target Harian & Target Hafalan (Card Khusus Pembelajaran) */}
      <div className="bg-gradient-to-br from-amber-50 to-orange-50/60 border border-amber-200 rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-bold text-amber-950">Target Pembelajaran & Hafalan Santri</h3>
          </div>
          <span className="text-[11px] font-bold text-amber-900 bg-amber-200/60 px-2 py-0.5 rounded-md">
            Metode Al-Wasā’il
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-white p-3.5 rounded-xl border border-amber-200/60 shadow-2xs space-y-1.5">
            <div className="text-slate-500 font-semibold text-[11px] uppercase tracking-wider">Target Harian Membaca Kitab</div>
            <div className="font-bold text-slate-900 text-sm">
              {prog?.targetHarian || 'Membaca 2 Shufhah Yāqūtun Nafīs & Mengi\'rab 5 kalimat'}
            </div>
            <p className="text-[11px] text-slate-600">
              Praktik membaca tanpa harakat dan menentukan kedudukan kalimat di hadapan ustadz pengampu.
            </p>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-amber-200/60 shadow-2xs space-y-1.5">
            <div className="text-slate-500 font-semibold text-[11px] uppercase tracking-wider">Target Hafalan Nadzom & Kaidah</div>
            <div className="font-bold text-slate-900 text-sm">
              {prog?.targetHafalan || 'Kaidah I\'lal 19 & Nadzom Al-Wasā\'il'}
            </div>
            <p className="text-[11px] text-slate-600">
              Setoran hafalan rutin ba'da shalat Subuh kepada musyrif asrama.
            </p>
          </div>
        </div>

        {prog?.catatanKesulitan && (
          <div className="p-3 bg-white rounded-xl border border-amber-200/80 flex items-start gap-2.5 text-xs text-amber-950">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Fokus Perbaikan dari Ustadz: </span>
              {prog.catatanKesulitan}
            </div>
          </div>
        )}
      </div>

      {/* Two Columns: Identitas Biodata & Nilai Rapor 8 Bidang */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Identitas Santri Lengkap */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Identitas Diri & Lembaga</h3>
          </div>

          <div className="space-y-2 text-xs divide-y divide-slate-100">
            <div className="py-1.5 flex justify-between">
              <span className="text-slate-500">Nomor Induk Santri (NIS):</span>
              <span className="font-mono-num font-bold text-slate-800">{santri.nis}</span>
            </div>
            <div className="py-1.5 flex justify-between">
              <span className="text-slate-500">Nama Lengkap:</span>
              <span className="font-semibold text-slate-800">{santri.nama}</span>
            </div>
            <div className="py-1.5 flex justify-between">
              <span className="text-slate-500">Tempat, Tanggal Lahir:</span>
              <span className="text-slate-800">{santri.tempatLahir}, {santri.tanggalLahir}</span>
            </div>
            <div className="py-1.5 flex justify-between">
              <span className="text-slate-500">Lembaga Asal / Cabang:</span>
              <span className="text-slate-800 font-medium">{santri.lembagaAsal}</span>
            </div>
            <div className="py-1.5 flex justify-between">
              <span className="text-slate-500">Nama Orang Tua:</span>
              <span className="text-slate-800">{santri.namaAyah} / {santri.namaIbu}</span>
            </div>
            <div className="py-1.5 flex justify-between">
              <span className="text-slate-500">No. HP Wali Santri:</span>
              <span className="font-mono-num text-slate-800">{santri.noHpWali}</span>
            </div>
            <div className="py-1.5 flex justify-between">
              <span className="text-slate-500">Alamat Rumah:</span>
              <span className="text-slate-800 text-right max-w-xs">{santri.alamat}</span>
            </div>
          </div>
        </div>

        {/* Nilai Evaluasi 8 Bidang Al-Wasā'il */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900">Nilai Evaluasi Al-Wasā'il (8 Bidang)</h3>
            </div>
            <button
              onClick={() => onNavigate('penilaian')}
              className="text-xs font-semibold text-blue-600 hover:underline"
            >
              Cetak Rapor →
            </button>
          </div>

          {pen ? (
            <div className="space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2">
                {pen.evaluasi.map((e, idx) => (
                  <div key={idx} className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-slate-800">{e.bidang}</div>
                      <div className="text-[10px] text-slate-400 font-arabic">{e.predikat}</div>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-bold font-mono-num text-[#0B1B3D]">{e.nilaiAngka}</span>
                      <span className={`block text-[10px] font-bold ${
                        e.predikat === 'Jayyid' ? 'text-emerald-700' : e.predikat === 'Mutawassith' ? 'text-blue-700' : 'text-rose-700'
                      }`}>
                        {e.predikat}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {pen.catatanUmum && (
                <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-slate-700 text-[11px] mt-2">
                  <span className="font-bold text-blue-950">Catatan Wali Kelas: </span>
                  {pen.catatanUmum}
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400 text-xs">
              Belum ada data evaluasi resmi yang diterbitkan untuk semester ini.
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
