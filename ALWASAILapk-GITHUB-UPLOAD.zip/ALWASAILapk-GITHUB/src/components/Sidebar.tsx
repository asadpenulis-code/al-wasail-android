import React from 'react';
import { UserRole } from '../types';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  Layers,
  CalendarCheck,
  Award,
  BookOpen,
  FileText,
  FileCheck2,
  Bell,
  BarChart3,
  Settings,
  Sparkles,
  Database
} from 'lucide-react';

export type NavTab = 
  | 'dashboard'
  | 'santri'
  | 'guru'
  | 'kelas'
  | 'absensi'
  | 'penilaian'
  | 'pembelajaran'
  | 'jurnal'
  | 'tashih'
  | 'pengumuman'
  | 'laporan'
  | 'pengaturan';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  userRole: UserRole;
  isOpen: boolean;
  onCloseMobile: () => void;
  onOpenMutuModal: () => void;
  onOpenBackupModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  userRole,
  isOpen,
  onCloseMobile,
  onOpenMutuModal,
  onOpenBackupModal
}) => {
  interface NavItem {
    id: NavTab;
    label: string;
    sublabel?: string;
    icon: React.ReactNode;
    roles: UserRole[];
    badge?: string;
  }

  const navItems: NavItem[] = [
    {
      id: 'dashboard',
      label: 'Dasbor Utama',
      sublabel: 'Ringkasan & Statistik',
      icon: <LayoutDashboard className="w-4 h-4" />,
      roles: ['admin', 'guru', 'santri', 'kepala']
    },
    {
      id: 'santri',
      label: 'Data Santri',
      sublabel: 'Biodata & Riwayat Kelas',
      icon: <Users className="w-4 h-4" />,
      roles: ['admin', 'guru', 'kepala']
    },
    {
      id: 'guru',
      label: 'Data Guru / Asatidz',
      sublabel: 'Pengajar & Wali Kelas',
      icon: <GraduationCap className="w-4 h-4" />,
      roles: ['admin', 'kepala']
    },
    {
      id: 'kelas',
      label: 'Manajemen Kelas',
      sublabel: 'I’dadiyah & Takhassus',
      icon: <Layers className="w-4 h-4" />,
      roles: ['admin', 'guru', 'kepala']
    },
    {
      id: 'absensi',
      label: 'Absensi Harian',
      sublabel: 'Presensi & Rekap Kehadiran',
      icon: <CalendarCheck className="w-4 h-4" />,
      roles: ['admin', 'guru', 'santri', 'kepala']
    },
    {
      id: 'penilaian',
      label: 'Nilai & Evaluasi',
      sublabel: '8 Bidang & Jayyid/Rodi\'',
      icon: <Award className="w-4 h-4" />,
      roles: ['admin', 'guru', 'santri', 'kepala']
    },
    {
      id: 'pembelajaran',
      label: 'Metode Al-Wasā’il',
      sublabel: 'Shufhah, Tarkib & Baca Kitab',
      icon: <BookOpen className="w-4 h-4" />,
      roles: ['admin', 'guru', 'santri', 'kepala'],
      badge: 'Spesial'
    },
    {
      id: 'jurnal',
      label: 'Jurnal Guru',
      sublabel: 'Agenda Mengajar & Evaluasi',
      icon: <FileText className="w-4 h-4" />,
      roles: ['admin', 'guru', 'kepala']
    },
    {
      id: 'tashih',
      label: 'Ujian Tashih',
      sublabel: 'Peserta, Nilai & Syahadah',
      icon: <FileCheck2 className="w-4 h-4" />,
      roles: ['admin', 'guru', 'santri', 'kepala']
    },
    {
      id: 'laporan',
      label: 'Laporan & Analisis',
      sublabel: 'Statistik & Cetak Dokumen',
      icon: <BarChart3 className="w-4 h-4" />,
      roles: ['admin', 'kepala']
    },
    {
      id: 'pengumuman',
      label: 'Pusat Informasi',
      sublabel: 'Pengumuman & Agenda',
      icon: <Bell className="w-4 h-4" />,
      roles: ['admin', 'guru', 'santri', 'kepala']
    },
    {
      id: 'pengaturan',
      label: 'Pengaturan Lembaga',
      sublabel: 'Identitas, KKM & Database',
      icon: <Settings className="w-4 h-4" />,
      roles: ['admin']
    }
  ];

  const visibleItems = navItems.filter(item => item.roles.includes(userRole));

  const handleSelect = (tab: NavTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transform transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } flex flex-col justify-between overflow-y-auto`}
      >
        <div className="p-3 space-y-1">
          <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Menu Navigasi
          </div>

          {visibleItems.map(item => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-[#0B1B3D] text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-1.5 rounded-lg ${isActive ? 'bg-amber-400/20 text-amber-300' : 'bg-slate-100 text-slate-500'}`}>
                    {item.icon}
                  </div>
                  <div>
                    <div className={isActive ? 'font-semibold text-white' : 'font-medium'}>
                      {item.label}
                    </div>
                    {item.sublabel && (
                      <div className={`text-[10px] ${isActive ? 'text-slate-300' : 'text-slate-400'}`}>
                        {item.sublabel}
                      </div>
                    )}
                  </div>
                </div>

                {item.badge && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-semibold ${
                    isActive ? 'bg-amber-400 text-[#0B1B3D]' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom Banner & Action Callouts */}
        <div className="p-3 border-t border-slate-100 space-y-2">
          {/* Quality Analysis Banner */}
          <div className="p-3 bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/60 rounded-xl">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-950 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Analisis Mutu Al-Wasā’il</span>
            </div>
            <p className="text-[11px] text-amber-800/80 leading-relaxed mb-2">
              Pantau santri kesulitan kedudukan kalimat & evaluasi capaian target.
            </p>
            <button
              onClick={onOpenMutuModal}
              className="w-full text-center py-1.5 px-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[11px] font-semibold transition-colors"
            >
              Buka Analisis Mutu
            </button>
          </div>

          {/* Quick DB Backup */}
          <button
            onClick={onOpenBackupModal}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
          >
            <Database className="w-3.5 h-3.5 text-slate-500" />
            <span>Cadangkan Data (JSON)</span>
          </button>

          <div className="text-center pt-1 text-[10px] text-slate-400 font-medium">
            Lembaga Al-Wasā'il © 2026<br />PP Al-Ihsan Jrangoan
          </div>
        </div>
      </aside>
    </>
  );
};
