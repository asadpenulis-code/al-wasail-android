import React, { useState } from 'react';
import { DatabaseState, UserAccount } from '../types';
import { exportToCSV } from '../services/db';
import { BarChart3, Download, Printer, Users, Award, CalendarCheck, FileCheck2, BookOpen, Clock, Sparkles } from 'lucide-react';

interface LaporanModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onOpenMutuModal: () => void;
}

export const LaporanModule: React.FC<LaporanModuleProps> = ({
  db,
  currentUser,
  onOpenMutuModal
}) => {
  const [selectedReportType, setSelectedReportType] = useState<'eksekutif' | 'absensi' | 'nilai' | 'tashih'>('eksekutif');

  const totalSantri = db.santri.length;
  const santriAktif = db.santri.filter(s => s.status === 'Aktif').length;
  const totalGuru = db.guru.length;
  const totalKelas = db.kelas.length;
  const totalSesiAbsensi = db.absensi.length;
  const totalPenilaian = db.penilaian.length;
  const totalTashih = db.tashih.length;
  const lulusTashih = db.tashih.filter(t => t.statusLulus === 'Lulus').length;

  // Average grades across all evaluations
  let sumScore = 0;
  let countScore = 0;
  db.penilaian.forEach(p => {
    p.evaluasi.forEach(e => {
      sumScore += e.nilaiAngka;
      countScore++;
    });
  });
  const avgSemuaNilai = countScore > 0 ? Math.round(sumScore / countScore) : 0;

  // Attendance recap
  let sumHadir = 0;
  let sumTotalAtt = 0;
  db.absensi.forEach(a => {
    a.records.forEach(r => {
      sumTotalAtt++;
      if (r.status === 'Hadir') sumHadir++;
    });
  });
  const avgKehadiran = sumTotalAtt > 0 ? Math.round((sumHadir / sumTotalAtt) * 100) : 100;

  // Export Executive Summary to CSV
  const handleExportSummaryCSV = () => {
    const headers = ['Indikator Lembaga', 'Nilai / Jumlah', 'Keterangan'];
    const rows = [
      ['Total Santri Terdaftar', totalSantri, 'Buku Induk'],
      ['Santri Aktif', santriAktif, 'Rombel Kelas'],
      ['Total Dewan Asatidz', totalGuru, 'Pengajar Al-Wasā\'il'],
      ['Jumlah Rombel Kelas', totalKelas, 'I\'dadiyah & Takhassus A/B/C'],
      ['Rata-rata Nilai Santri', avgSemuaNilai, 'Skala 0-100'],
      ['Rata-rata Presensi Kehadiran', `${avgKehadiran}%`, 'Seluruh Rombel'],
      ['Kelulusan Ujian Tashih', `${lulusTashih} dari ${totalTashih} Peserta`, 'Syahadah Resmi Terbit']
    ];
    exportToCSV(`laporan_eksekutif_alwasail_${new Date().toISOString().split('T')[0]}`, headers, rows);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <BarChart3 className="w-4 h-4" />
            <span>Pusat Laporan & Statistik Terpadu</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Laporan Pendidikan Lembaga Al-Wasā’il
          </h2>
          <p className="text-xs text-slate-500">
            PP Al-Ihsan Jrangoan · Rekapitulasi perkembangan santri, presensi, evaluasi mutu dan tashih.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportSummaryCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Ekspor Ringkasan (CSV)</span>
          </button>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs"
          >
            <Printer className="w-4 h-4 text-amber-300" />
            <span>Cetak Laporan Lengkap (PDF)</span>
          </button>
        </div>
      </div>

      {/* Strategic Report Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Populasi Santri Aktif</div>
          <div className="text-2xl font-bold text-slate-900 font-mono-num">{santriAktif}</div>
          <div className="text-[11px] text-slate-500 mt-1">Total {totalSantri} santri tercatat</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Rata-rata Presensi</div>
          <div className="text-2xl font-bold text-emerald-700 font-mono-num">{avgKehadiran}%</div>
          <div className="text-[11px] text-slate-500 mt-1">Dari {totalSesiAbsensi} sesi presensi</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Rata-rata Nilai 8 Bidang</div>
          <div className="text-2xl font-bold text-[#0B1B3D] font-mono-num">{avgSemuaNilai}</div>
          <div className="text-[11px] text-slate-500 mt-1">Predikat Jayyid Mutawassith</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs text-slate-500 font-medium mb-1">Kelulusan Tashih Kitab</div>
          <div className="text-2xl font-bold text-purple-700 font-mono-num">{lulusTashih}</div>
          <div className="text-[11px] text-slate-500 mt-1">Dari {totalTashih} peserta terdaftar</div>
        </div>

      </div>

      {/* Quality Matrix Spotlight Callout */}
      <div className="bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 p-5 rounded-2xl border border-amber-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-950">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>Matriks Peningkatan Mutu Metodologi Al-Wasā'il</span>
          </div>
          <p className="text-xs text-amber-900/80 max-w-2xl leading-relaxed">
            Identifikasi dini santri yang kesulitan kedudukan kalimat, evaluasi kelancaran membaca kitab kuning, monitoring jurnal asatidz, dan target pembelajaran yang belum tercapai.
          </p>
        </div>
        <button
          onClick={onOpenMutuModal}
          className="shrink-0 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs transition-colors shadow-2xs"
        >
          Buka Analisis Mutu
        </button>
      </div>

      {/* Rombongan Belajar Progress Matrix Table */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <h3 className="font-bold text-slate-900 text-sm">
          Matriks Rekapitulasi Antar Rombel Kelas (Tahun Ajaran {db.pengaturan.tahunAjaranAktif})
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Kelas Rombel</th>
                <th className="py-2.5 px-3">Wali Kelas</th>
                <th className="py-2.5 px-3 text-center">Santri Aktif</th>
                <th className="py-2.5 px-3 text-center">Rata-rata Nilai</th>
                <th className="py-2.5 px-3 text-center">Presensi Rombel</th>
                <th className="py-2.5 px-3">Fokus & Capaian Metodologi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {db.kelas.map(k => {
                const santriInK = db.santri.filter(s => s.kelasId === k.id && s.status === 'Aktif');
                const wali = db.guru.find(g => g.id === k.waliKelasId);
                const ids = santriInK.map(s => s.id);
                
                // Calculate average evaluation
                const pens = db.penilaian.filter(p => ids.includes(p.santriId));
                let tScore = 0;
                let cScore = 0;
                pens.forEach(p => p.evaluasi.forEach(e => { tScore += e.nilaiAngka; cScore++; }));
                const avgK = cScore > 0 ? Math.round(tScore / cScore) : '-';

                return (
                  <tr key={k.id} className="hover:bg-slate-50">
                    <td className="py-3 px-3 font-bold text-slate-900">{k.nama}</td>
                    <td className="py-3 px-3 text-slate-700">{wali?.nama || '-'}</td>
                    <td className="py-3 px-3 text-center font-mono-num font-semibold text-slate-800">{santriInK.length} Santri</td>
                    <td className="py-3 px-3 text-center font-mono-num font-bold text-[#0B1B3D]">{avgK}</td>
                    <td className="py-3 px-3 text-center font-mono-num font-semibold text-emerald-700">92%</td>
                    <td className="py-3 px-3 text-slate-600 text-[11px]">{k.keterangan || '-'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
