import React, { useState } from 'react';
import { DatabaseState, ProgresPembelajaranSantri, UserAccount } from '../types';
import { 
  BookOpen, CheckCircle2, AlertCircle, HelpCircle, Sparkles, Plus, Edit2, 
  ArrowRight, Search, FileText, Check, Award
} from 'lucide-react';

interface PembelajaranModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdateProgres: (progresList: ProgresPembelajaranSantri[]) => void;
  onOpenMutuModal: () => void;
}

export const PembelajaranModule: React.FC<PembelajaranModuleProps> = ({
  db,
  currentUser,
  onUpdateProgres,
  onOpenMutuModal
}) => {
  const [activeTab, setActiveTab] = useState<'kurikulum' | 'santri' | 'latihan'>('kurikulum');
  const [selectedSantriId, setSelectedSantriId] = useState<string>(db.santri[0]?.id || 's-1');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Practice Interactive Trainer State
  const [selectedSentenceIndex, setSelectedSentenceIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, { jenis?: string; kedudukan?: string; irab?: string }>>({});
  const [showAnswerResult, setShowAnswerResult] = useState(false);

  const canEdit = currentUser.role === 'admin' || currentUser.role === 'guru';

  // Sample Interactive Kitab Gundul Sentences from Yāqūtun Nafīs & Fathul Qorib
  const sampleKitabSentences = [
    {
      kitab: 'Kitab Yāqūtun Nafīs (ياقوت النفيس)',
      bab: 'Bab Shalat - Syarat Wajib Shalat',
      arabicText: 'يَجِبُ الصَّلَاةُ عَلَى كُلِّ مُسْلِمٍ بَالِغٍ عَاقِلٍ',
      arabicGundul: 'يجب الصلاة على كل مسلم بالغ عاقل',
      words: [
        { word: 'يَجِبُ', jenis: 'Fi\'il Mudhari\'', kedudukan: 'Fi\'il', irab: 'Marfu\' (Dhammah)', arti: 'Wajib' },
        { word: 'الصَّلَاةُ', jenis: 'Isim', kedudukan: 'Fa\'il (Subjek)', irab: 'Marfu\' (Dhammah)', arti: 'Shalat' },
        { word: 'عَلَى', jenis: 'Huruf Jar', kedudukan: 'Huruf Jar', irab: 'Mabni atas Sukun', arti: 'Atas' },
        { word: 'كُلِّ', jenis: 'Isim', kedudukan: 'Majrur bi \'ala', irab: 'Majrur (Kasrah)', arti: 'Setiap' },
        { word: 'مُسْلِمٍ', jenis: 'Isim', kedudukan: 'Mudhaf Ilaih', irab: 'Majrur (Kasrah)', arti: 'Orang Muslim' },
        { word: 'بَالِغٍ', jenis: 'Isim', kedudukan: 'Na\'at (Sifat 1)', irab: 'Majrur (Kasrah)', arti: 'Yang Baligh' },
        { word: 'عَاقِلٍ', jenis: 'Isim', kedudukan: 'Na\'at (Sifat 2)', irab: 'Majrur (Kasrah)', arti: 'Yang Berakal' }
      ],
      tarkibPenting: 'Kata "الصَّلَاةُ" berkedudukan sebagai Fa\'il dari fi\'il "يَجِبُ", ditandai harakat Dhammah di huruf ta\' marbuthah.'
    },
    {
      kitab: 'Kitab Yāqūtun Nafīs (ياقوت النفيس)',
      bab: 'Bab Thaharah - Air yang Mensucikan',
      arabicText: 'المِيَاهُ الَّتِي يَجُوْزُ التَّطْهِيْرُ بِهَا سَبْعَةُ مِيَاهٍ',
      arabicGundul: 'المياه التي يجوز التطهير بها سبعة مياه',
      words: [
        { word: 'المِيَاهُ', jenis: 'Isim', kedudukan: 'Mubtada\'', irab: 'Marfu\' (Dhammah)', arti: 'Air-air' },
        { word: 'الَّتِي', jenis: 'Isim Maushul', kedudukan: 'Na\'at untuk Mubtada\'', irab: 'Mabni atas Sukun', arti: 'Yang' },
        { word: 'يَجُوْزُ', jenis: 'Fi\'il Mudhari\'', kedudukan: 'Shilah Maushul', irab: 'Marfu\' (Dhammah)', arti: 'Boleh' },
        { word: 'التَّطْهِيْرُ', jenis: 'Isim', kedudukan: 'Fa\'il dari yajuzu', irab: 'Marfu\' (Dhammah)', arti: 'Bersuci' },
        { word: 'سَبْعَةُ', jenis: 'Isim', kedudukan: 'Khabar Mubtada\'', irab: 'Marfu\' (Dhammah)', arti: 'Tujuh' },
        { word: 'مِيَاهٍ', jenis: 'Isim', kedudukan: 'Mudhaf Ilaih / Tamyiz', irab: 'Majrur (Kasrah)', arti: 'Macam air' }
      ],
      tarkibPenting: 'Perhatikan bahwa Khabar dari Mubtada "المِيَاهُ" adalah "سَبْعَةُ" (bukan kata "التي" atau "التطهير"). Ini melatih santri menemukan pasangan Mubtada\' & Khabar!'
    }
  ];

  // Current selected Santri progres
  const currentProgres = db.progres.find(p => p.santriId === selectedSantriId);
  const currentSantri = db.santri.find(s => s.id === selectedSantriId);
  const currentKelas = db.kelas.find(k => k.id === currentSantri?.kelasId);

  // Edit Progres Form State
  const [editFormData, setEditFormData] = useState<Partial<ProgresPembelajaranSantri>>({});

  const handleOpenEditProgres = () => {
    if (!currentProgres) {
      setEditFormData({
        santriId: selectedSantriId,
        tahapanAktif: 'Marhalah 1 (Shufhah 1–15)',
        materiSelesai: ['Pengenalan Isim, Fi\'il, Huruf', 'Tanda I\'rab Rofa\''],
        targetHarian: 'Membaca 2 Shufhah & Mengi\'rab 5 kalimat',
        targetHafalan: 'Kaidah I\'lal 1-5',
        kesulitanKedudukanKalimat: false,
        kelancaranMembacaKitab: 'Baik',
        catatanKesulitan: '',
        rekomendasiBimbingan: ''
      });
    } else {
      setEditFormData(currentProgres);
    }
    setIsEditModalOpen(true);
  };

  const handleSaveProgres = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedItem: ProgresPembelajaranSantri = {
      id: currentProgres?.id || `prog-${Date.now()}`,
      santriId: selectedSantriId,
      tahapanAktif: editFormData.tahapanAktif || 'Marhalah 1 (Shufhah 1–15)',
      materiSelesai: editFormData.materiSelesai || [],
      targetHarian: editFormData.targetHarian || '',
      targetHafalan: editFormData.targetHafalan || '',
      kesulitanKedudukanKalimat: editFormData.kesulitanKedudukanKalimat || false,
      kelancaranMembacaKitab: editFormData.kelancaranMembacaKitab || 'Baik',
      catatanKesulitan: editFormData.catatanKesulitan || '',
      rekomendasiBimbingan: editFormData.rekomendasiBimbingan || '',
      terakhirDiperbarui: new Date().toISOString().split('T')[0]
    };

    if (currentProgres) {
      onUpdateProgres(db.progres.map(p => p.id === currentProgres.id ? updatedItem : p));
    } else {
      onUpdateProgres([...db.progres, updatedItem]);
    }

    setIsEditModalOpen(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0B1B3D] via-[#0E2656] to-[#0B1B3D] rounded-2xl text-white p-6 sm:p-7 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
              <span className="font-arabic text-base">«الْوَسَائِلُ – الطَّرِيْقَةُ السَّهْلَةُ لِقِرَاءَةِ الْكُتُبِ»</span>
              <span>·</span>
              <span>Metodologi Pesantren</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              Modul Pembelajaran & Metodologi Al-Wasā’il
            </h1>
            <p className="text-xs text-slate-200">
              Panduan Shufhah 1-15, Shufhah 16-30, 19 Kaidah I'lal, Kitab Yāqūtun Nafīs & Pelacak Progres Santri.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenMutuModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-[#0B1B3D] font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <Sparkles className="w-4 h-4 text-[#0B1B3D]" />
              <span>Analisis Kesulitan Santri</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 text-xs font-medium">
        <button
          onClick={() => setActiveTab('kurikulum')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'kurikulum' ? 'bg-[#0B1B3D] text-white shadow-xs font-bold' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Kurikulum & Tahapan Shufhah
        </button>
        <button
          onClick={() => setActiveTab('santri')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'santri' ? 'bg-[#0B1B3D] text-white shadow-xs font-bold' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Pelacak Progres Belajar Santri
        </button>
        <button
          onClick={() => setActiveTab('latihan')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl transition-all ${
            activeTab === 'latihan' ? 'bg-amber-600 text-white shadow-xs font-bold' : 'text-amber-800 hover:bg-amber-50'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Latihan Membaca Kitab & Kedudukan Kalimat</span>
        </button>
      </div>

      {/* TAB 1: KURIKULUM & TAHAPAN SHUFHAH */}
      {activeTab === 'kurikulum' && (
        <div className="space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            
            {/* Marhalah 1 */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                  Marhalah I
                </span>
                <span className="text-xs font-arabic text-slate-500 font-bold">الصفحة ١ - ١٥</span>
              </div>
              <h3 className="font-bold text-slate-900 text-base">Dasar Kaidah & Shufhah 1–15</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pengenalan kalimat (Isim, Fi'il, Huruf), tanda-tanda kalimah Al-Wasā'il, rumus tanda I'rab (Rafa', Nashab, Jer, Jazm), serta pengenalan awal Fa'il dan Naibul Fa'il.
              </p>

              <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-700">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Kaidah Isim dengan 5 Tanda Utama</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Fi'il Madhi, Mudhari', Amar & Rumus Mabni</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Tabel 4 Tanda I'rab Al-Wasā'il</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Latihan Shufhah 1 sampai 15</span>
                </div>
              </div>
            </div>

            {/* Marhalah 2 */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                  Marhalah II
                </span>
                <span className="text-xs font-arabic text-slate-500 font-bold">الصفحة ١٦ - ٣٠</span>
              </div>
              <h3 className="font-bold text-slate-900 text-base">Tarkib & Shufhah 16–30</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pendalaman kedudukan kalimat tingkat menengah: Isim Marfu'at (Mubtada', Khabar, Kana & Inna), Manshubat (Maf'ulat, Hal, Tamyiz), dan Mahfudhat (Idhafah & Huruf Jer).
              </p>

              <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-700">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Tarkib Mubtada' Muakhar & Khabar Muqaddam</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Rumus Cepat Membedakan Hal vs Tamyiz</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Kaidah Amil Nawasikh (Kana & Saudaranya)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Latihan Shufhah 16 sampai 30</span>
                </div>
              </div>
            </div>

            {/* Marhalah 3 */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
                  Marhalah III
                </span>
                <span className="text-xs font-arabic text-slate-500 font-bold">ياقوت النفيس</span>
              </div>
              <h3 className="font-bold text-slate-900 text-base">Baca Kitab Gundul & 19 Kaidah I'lal</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Aplikasi langsung membaca Kitab Kuning Gundul tanpa harakat (Kitab Yāqūtun Nafīs & Fathul Qorib) serta penguasaan tuntas 19 Kaidah I'lal Al-Wasā'il sebagai syarat Tashih.
              </p>

              <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-700">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>19 Kaidah I'lal Lengkap (Bina' Mu'tal)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>Bedah Kitab Fiqih Yāqūtun Nafīs</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>Latihan Membaca Gundul di Depan Musahhih</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>Simulasi Ujian Syahadah Tashih Nasional</span>
                </div>
              </div>
            </div>

          </div>

          {/* 19 Kaidah I'lal Al-Wasā'il Summary Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-amber-600" />
                <h3 className="text-sm font-bold text-slate-900">Rangkuman 19 Kaidah I’lal Al-Wasā’il</h3>
              </div>
              <span className="text-xs font-semibold text-slate-500 font-arabic">قواعد الإعلال التسعة عشر</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="font-bold text-slate-900">Kaidah 1: Wawu/Ya' Jadi Alif</div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Jika Wawu atau Ya' berharakat dan huruf sebelumnya berharakat fathah, maka diganti Alif. Contoh: قَالَ (asalnya قَوَلَ), بَاعَ (asalnya بَيَعَ).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="font-bold text-slate-900">Kaidah 2: Wawu/Ya' Jadi Hamzah</div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Jika Wawu atau Ya' jatuh setelah Alif Zaidah pada Isim Fa'il, maka diganti Hamzah. Contoh: قَائِلٌ (asalnya قَاوِلٌ), بَائِعٌ (asalnya بَايِعٌ).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="font-bold text-slate-900">Kaidah 3: Pemindahan Harakat (Naql)</div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Jika huruf illat berharakat dan huruf shahih sebelumnya mati, harakat dipindah ke huruf shahih. Contoh: يَقُوْلُ (asalnya يَقْوُلُ).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="font-bold text-slate-900">Kaidah 4: Pembuangan Huruf Illat</div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Pertemuan dua sukun antara huruf illat dan huruf akhir pada Fi'il Amar atau Jazm. Contoh: قُلْ (asalnya قُوْلْ).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="font-bold text-slate-900">Kaidah 5: Penggantian pada Wazan Ifta'ala</div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Fa' fi'il berupa Wawu/Ya' diganti Ta' lalu di-idghamkan. Contoh: اِتَّقَى (asalnya اِوْتَقَى dari wazan اِفْتَعَلَ).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <div className="font-bold text-slate-900">Kaidah 6-19: Kaidah Lanjutan</div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Mencakup bina' lafif maqrun, lafif mafruq, mudha'af, mahmuz, dan perlakuan nun tawkid pada fi'il mu'tal akhir.
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: PELACAK PROGRES BELAJAR SANTRI */}
      {activeTab === 'santri' && (
        <div className="space-y-6">
          
          {/* Select Santri */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-3">
              <label className="text-slate-500 font-semibold whitespace-nowrap">Pilih Santri:</label>
              <select
                value={selectedSantriId}
                onChange={(e) => setSelectedSantriId(e.target.value)}
                className="py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900 max-w-xs sm:max-w-md truncate"
              >
                {db.santri.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.nama} ({s.nis}) - {db.kelas.find(k => k.id === s.kelasId)?.nama}
                  </option>
                ))}
              </select>
            </div>

            {canEdit && (
              <button
                onClick={handleOpenEditProgres}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-lg transition-colors self-end sm:self-auto"
              >
                <Edit2 className="w-3.5 h-3.5 text-amber-300" />
                <span>Perbarui Catatan Progres</span>
              </button>
            )}
          </div>

          {/* Santri Progress Overview Card */}
          {currentSantri && (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-6">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-[#0B1B3D] text-amber-300 flex items-center justify-center font-bold text-lg shrink-0">
                    {currentSantri.nama.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-base">{currentSantri.nama}</h3>
                    <div className="text-xs text-slate-500 font-mono-num">
                      NIS: {currentSantri.nis} · Kelas {currentKelas?.nama}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    currentProgres?.kesulitanKedudukanKalimat 
                      ? 'bg-amber-100 text-amber-800 border border-amber-200' 
                      : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  }`}>
                    {currentProgres?.kesulitanKedudukanKalimat ? '⚠ Kesulitan Kedudukan Kalimat' : '✓ Tarkib Lancar'}
                  </span>

                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200">
                    Baca Kitab: {currentProgres?.kelancaranMembacaKitab || 'Baik'}
                  </span>
                </div>
              </div>

              {/* Grid Status */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                  <div className="text-slate-400 font-bold uppercase text-[10px]">Tahapan Aktif</div>
                  <div className="font-bold text-slate-900 text-sm">
                    {currentProgres?.tahapanAktif || 'Marhalah 1 (Shufhah 1–15)'}
                  </div>
                  <div className="text-slate-500 text-[11px] font-mono-num">
                    Terakhir diperbarui: {currentProgres?.terakhirDiperbarui || '-'}
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                  <div className="text-slate-400 font-bold uppercase text-[10px]">Target Harian & Hafalan</div>
                  <div className="text-slate-800 font-semibold">
                    Harian: <span className="font-normal">{currentProgres?.targetHarian || 'Membaca 2 Shufhah'}</span>
                  </div>
                  <div className="text-slate-800 font-semibold">
                    Hafalan: <span className="font-normal">{currentProgres?.targetHafalan || 'Kaidah I\'lal 1-5'}</span>
                  </div>
                </div>

              </div>

              {/* Materi Selesai */}
              <div className="space-y-2 text-xs">
                <div className="font-bold text-slate-900">Materi yang Telah Diselesaikan Santri:</div>
                <div className="flex flex-wrap gap-2">
                  {currentProgres?.materiSelesai && currentProgres.materiSelesai.length > 0 ? (
                    currentProgres.materiSelesai.map((m, idx) => (
                      <span key={idx} className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-medium">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{m}</span>
                      </span>
                    ))
                  ) : (
                    <span className="text-slate-400 italic">Belum ada catatan materi selesai.</span>
                  )}
                </div>
              </div>

              {/* Catatan Kesulitan & Rekomendasi Bimbingan Lanjutan */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1.5">
                  <div className="font-bold text-amber-950 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    <span>Catatan Kesulitan Santri</span>
                  </div>
                  <p className="text-amber-900 text-xs leading-relaxed">
                    {currentProgres?.catatanKesulitan || 'Tidak ada kesulitan signifikan.'}
                  </p>
                </div>

                <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-xl space-y-1.5">
                  <div className="font-bold text-blue-950 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    <span>Rekomendasi Bimbingan Lanjutan</span>
                  </div>
                  <p className="text-blue-900 text-xs leading-relaxed">
                    {currentProgres?.rekomendasiBimbingan || 'Lanjutkan target pembelajaran sesuai kurikulum rombel.'}
                  </p>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* TAB 3: LATIHAN MEMBACA KITAB GUNDUL & MENENTUKAN KEDUDUKAN KALIMAT */}
      {activeTab === 'latihan' && (
        <div className="space-y-6">
          
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-5 space-y-2 text-xs text-amber-950">
            <div className="font-bold text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>Simulasi Interaktif: Menentukan Jenis & Kedudukan Kalimat (Metode Al-Wasā'il)</span>
            </div>
            <p className="leading-relaxed">
              Santri dan asatidz dapat menggunakan sarana interaktif ini untuk melatih ketajaman menentukan jenis kalimah (Isim, Fi'il, Huruf), kedudukan (Fa'il, Maf'ul, Mubtada', Khabar, Hal, Tamyiz, dsb.), dan tanda I'rab pada teks ibarat kitab kuning asli.
            </p>
          </div>

          {/* Sentence Selector */}
          <div className="flex items-center gap-2 overflow-x-auto text-xs pb-1">
            {sampleKitabSentences.map((sent, idx) => (
              <button
                key={idx}
                onClick={() => { setSelectedSentenceIndex(idx); setShowAnswerResult(false); }}
                className={`px-3.5 py-2 rounded-xl whitespace-nowrap font-medium transition-all ${
                  selectedSentenceIndex === idx ? 'bg-[#0B1B3D] text-white shadow-xs font-bold' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                Latihan {idx + 1}: {sent.bab}
              </button>
            ))}
          </div>

          {/* Sentence Display Card */}
          {(() => {
            const currentSentence = sampleKitabSentences[selectedSentenceIndex];

            return (
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-6">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
                  <div>
                    <span className="text-[11px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded">
                      {currentSentence.kitab}
                    </span>
                    <h3 className="font-bold text-slate-900 text-sm mt-1">{currentSentence.bab}</h3>
                  </div>
                  <div className="text-xs text-slate-400">
                    Metode Al-Wasā'il: Baca Gundul & Tarkib
                  </div>
                </div>

                {/* Arabic Text Display */}
                <div className="p-6 bg-slate-900 text-amber-200 rounded-xl text-center space-y-3 shadow-inner">
                  <div className="text-xs text-slate-400 font-sans uppercase tracking-wider">
                    Teks Kitab Tanpa Harakat (Gundul):
                  </div>
                  <div className="font-arabic text-2xl sm:text-3xl text-white font-bold leading-relaxed tracking-wider">
                    {currentSentence.arabicGundul}
                  </div>
                  <div className="text-xs text-slate-300 font-arabic italic">
                    Harakat Penuh: {currentSentence.arabicText}
                  </div>
                </div>

                {/* Word Breakdown & Tarkib Analysis */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 text-sm">Bedah Tarkib Kalimah per Kalimah:</h4>
                    <button
                      onClick={() => setShowAnswerResult(!showAnswerResult)}
                      className="text-xs font-bold text-blue-600 hover:underline"
                    >
                      {showAnswerResult ? 'Sembunyikan Kunci Jawaban' : 'Tampilkan Kunci Jawaban Lengkap'}
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left border border-slate-200 rounded-lg overflow-hidden">
                      <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[11px] border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 px-3">Lafadz Kalimah</th>
                          <th className="py-2.5 px-3">Jenis Kalimah</th>
                          <th className="py-2.5 px-3">Kedudukan (Tarkib)</th>
                          <th className="py-2.5 px-3">Hukum I'rab & Tanda</th>
                          <th className="py-2.5 px-3">Arti / Makna</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {currentSentence.words.map((w, wIdx) => (
                          <tr key={wIdx} className="hover:bg-slate-50">
                            <td className="py-2.5 px-3 font-arabic text-lg font-bold text-[#0B1B3D]">{w.word}</td>
                            <td className="py-2.5 px-3 font-semibold text-slate-800">
                              {showAnswerResult ? w.jenis : <span className="text-slate-400 italic">???</span>}
                            </td>
                            <td className="py-2.5 px-3 font-bold text-blue-700">
                              {showAnswerResult ? w.kedudukan : <span className="text-slate-400 italic">???</span>}
                            </td>
                            <td className="py-2.5 px-3 font-mono-num text-slate-700">
                              {showAnswerResult ? w.irab : <span className="text-slate-400 italic">???</span>}
                            </td>
                            <td className="py-2.5 px-3 text-slate-600">
                              {w.arti}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Kunci Rumus Al-Wasā'il */}
                  {showAnswerResult && (
                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-1">
                      <div className="font-bold text-emerald-950 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Kaidah Emas Al-Wasā'il:</span>
                      </div>
                      <p className="text-emerald-900 leading-relaxed">
                        {currentSentence.tarkibPenting}
                      </p>
                    </div>
                  )}
                </div>

              </div>
            );
          })()}

        </div>
      )}

      {/* Modal Edit Progres Santri */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl my-8 overflow-hidden">
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <h3 className="text-base font-bold">Perbarui Catatan Perkembangan Santri</h3>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveProgres} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Tahapan yang Sedang Ditempuh</label>
                <select
                  value={editFormData.tahapanAktif || 'Marhalah 1 (Shufhah 1–15)'}
                  onChange={(e) => setEditFormData({ ...editFormData, tahapanAktif: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                >
                  <option value="Marhalah 1 (Shufhah 1–15)">Marhalah 1 (Shufhah 1–15) - Pengenalan Dasar</option>
                  <option value="Marhalah 2 (Shufhah 16–30)">Marhalah 2 (Shufhah 16–30) - Tarkib Lanjutan</option>
                  <option value="Marhalah 3 (Tarkib & Kitab Gundul)">Marhalah 3 (Tarkib & Kitab Gundul) - Kitab Kuning</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Kelancaran Membaca Kitab Gundul</label>
                <select
                  value={editFormData.kelancaranMembacaKitab || 'Baik'}
                  onChange={(e) => setEditFormData({ ...editFormData, kelancaranMembacaKitab: e.target.value as any })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                >
                  <option value="Sangat Baik">Sangat Baik (Lancar & Fasih)</option>
                  <option value="Baik">Baik (Lancar)</option>
                  <option value="Cukup">Cukup (Masih Kadang Ragu)</option>
                  <option value="Kurang">Kurang (Mengeja / Butuh Bimbingan)</option>
                </select>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center gap-2">
                <input
                  type="checkbox"
                  id="kesulitanKedudukan"
                  checked={editFormData.kesulitanKedudukanKalimat || false}
                  onChange={(e) => setEditFormData({ ...editFormData, kesulitanKedudukanKalimat: e.target.checked })}
                  className="w-4 h-4 text-amber-600 rounded"
                />
                <label htmlFor="kesulitanKedudukan" className="text-amber-950 font-bold cursor-pointer">
                  Tandai: Santri Mengalami Kesulitan Menentukan Kedudukan Kalimat (Tarkib)
                </label>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Target Harian</label>
                <input
                  type="text"
                  value={editFormData.targetHarian || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, targetHarian: e.target.value })}
                  placeholder="Contoh: Membaca 2 Shufhah & Mengi'rab 5 kalimat"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Target Hafalan</label>
                <input
                  type="text"
                  value={editFormData.targetHafalan || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, targetHafalan: e.target.value })}
                  placeholder="Contoh: Kaidah I'lal 1-10"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Catatan Kesulitan Santri</label>
                <textarea
                  rows={2}
                  value={editFormData.catatanKesulitan || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, catatanKesulitan: e.target.value })}
                  placeholder="Detail kendala santri dalam tarkib..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Rekomendasi Bimbingan Lanjutan</label>
                <textarea
                  rows={2}
                  value={editFormData.rekomendasiBimbingan || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, rekomendasiBimbingan: e.target.value })}
                  placeholder="Langkah perbaikan, misal drill ba'da Maghrib..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Simpan Progres
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
