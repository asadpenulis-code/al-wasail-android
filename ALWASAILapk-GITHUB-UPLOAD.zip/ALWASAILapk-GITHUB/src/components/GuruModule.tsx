import React, { useState } from 'react';
import { DatabaseState, Guru, UserAccount } from '../types';
import { GraduationCap, Plus, Search, Edit2, Trash2, Phone, BookOpen, Award, CheckCircle2, X } from 'lucide-react';

interface GuruModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdateGuru: (guruList: Guru[]) => void;
}

export const GuruModule: React.FC<GuruModuleProps> = ({
  db,
  currentUser,
  onUpdateGuru
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGuru, setEditingGuru] = useState<Guru | null>(null);

  const [formData, setFormData] = useState<Partial<Guru>>({
    nig: '',
    nama: '',
    tempatLahir: '',
    tanggalLahir: '',
    alamat: '',
    noHp: '',
    pendidikanTerakhir: '',
    tahunMulaiMengajar: '2022',
    mapel: ['Nahwu Al-Wasā\'il'],
    kelasAmpu: ['k-1'],
    status: 'Aktif',
    riwayatMengajar: ''
  });

  const canEdit = currentUser.role === 'admin';

  const filteredGuru = db.guru.filter(g => 
    g.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
    g.nig.toLowerCase().includes(searchTerm.toLowerCase()) ||
    g.mapel.some(m => m.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleOpenAdd = () => {
    const nextNig = `NIG-${new Date().getFullYear()}-${String(db.guru.length + 1).padStart(2, '0')}`;
    setFormData({
      nig: nextNig,
      nama: '',
      tempatLahir: 'Sampang',
      tanggalLahir: '1992-01-01',
      alamat: '',
      noHp: '',
      pendidikanTerakhir: 'Ma\'had Aly / S1 PAI',
      tahunMulaiMengajar: String(new Date().getFullYear()),
      mapel: ['Nahwu Al-Wasā\'il'],
      kelasAmpu: ['k-1'],
      status: 'Aktif',
      riwayatMengajar: ''
    });
    setEditingGuru(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (g: Guru) => {
    setFormData(g);
    setEditingGuru(g);
    setIsModalOpen(true);
  };

  const handleSaveGuru = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama || !formData.nig) return;

    if (editingGuru) {
      const updated = db.guru.map(g => g.id === editingGuru.id ? { ...g, ...(formData as Guru) } : g);
      onUpdateGuru(updated);
    } else {
      const newGuru: Guru = {
        id: `g-${Date.now()}`,
        nig: formData.nig || '',
        nama: formData.nama || '',
        tempatLahir: formData.tempatLahir || '',
        tanggalLahir: formData.tanggalLahir || '',
        alamat: formData.alamat || '',
        noHp: formData.noHp || '',
        pendidikanTerakhir: formData.pendidikanTerakhir || '',
        tahunMulaiMengajar: formData.tahunMulaiMengajar || '2024',
        mapel: formData.mapel || ['Nahwu'],
        kelasAmpu: formData.kelasAmpu || ['k-1'],
        status: (formData.status as 'Aktif' | 'Non-Aktif') || 'Aktif',
        riwayatMengajar: formData.riwayatMengajar || ''
      };
      onUpdateGuru([...db.guru, newGuru]);
    }
    setIsModalOpen(false);
  };

  const handleDeleteGuru = (id: string, nama: string) => {
    if (window.confirm(`Yakin ingin menghapus data ustadz "${nama}"?`)) {
      onUpdateGuru(db.guru.filter(g => g.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <GraduationCap className="w-4 h-4" />
            <span>Dewan Asatidz & Guru Al-Wasā’il</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Data Pengajar & Wali Kelas
          </h2>
          <p className="text-xs text-slate-500">
            Mengelola pembagian tugas pengajaran metode Al-Wasā'il PP Al-Ihsan Jrangoan.
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs self-start md:self-auto"
          >
            <Plus className="w-4 h-4 text-amber-300" />
            <span>Tambah Data Guru</span>
          </button>
        )}
      </div>

      {/* Search */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama guru, NIG, atau mata pelajaran..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>
      </div>

      {/* Guru Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredGuru.map(g => {
          const kelasAmpuNames = g.kelasAmpu
            .map(cId => db.kelas.find(k => k.id === cId)?.nama)
            .filter(Boolean)
            .join(', ');

          const waliKelas = db.kelas.find(k => k.waliKelasId === g.id);
          const totalJurnal = db.jurnal.filter(j => j.guruId === g.id).length;

          return (
            <div key={g.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
              
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-[#0B1B3D] text-amber-300 flex items-center justify-center font-bold text-lg shrink-0">
                    {g.nama.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{g.nama}</h3>
                    <div className="text-[11px] text-slate-500 font-mono-num">
                      {g.nig} · Mengajar sejak {g.tahunMulaiMengajar}
                    </div>
                  </div>
                </div>

                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  g.status === 'Aktif' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                }`}>
                  {g.status}
                </span>
              </div>

              {/* Info details */}
              <div className="space-y-1.5 text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div>
                  <span className="font-semibold text-slate-800">Pendidikan: </span>
                  {g.pendidikanTerakhir}
                </div>
                <div>
                  <span className="font-semibold text-slate-800">Bidang Pengajaran: </span>
                  <span className="text-blue-700 font-medium">{g.mapel.join(', ')}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-800">Kelas yang Diampu: </span>
                  <span className="font-medium text-slate-900">{kelasAmpuNames || '-'}</span>
                </div>
                {waliKelas && (
                  <div className="text-amber-900 font-medium pt-1 border-t border-slate-200/60">
                    ★ Wali Kelas Rombel: <strong className="text-amber-950">{waliKelas.nama}</strong>
                  </div>
                )}
              </div>

              {/* Contact & Journal summary */}
              <div className="flex items-center justify-between text-xs pt-1">
                <a
                  href={`https://wa.me/${g.noHp.replace(/[^0-9]/g, '').replace(/^0/, '62')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-emerald-700 hover:text-emerald-800 font-mono-num font-medium bg-emerald-50 px-2.5 py-1 rounded-lg"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{g.noHp}</span>
                </a>

                <div className="flex items-center gap-1">
                  <span className="text-slate-400 text-[11px] font-mono-num mr-2">{totalJurnal} Jurnal</span>
                  {canEdit && (
                    <>
                      <button
                        onClick={() => handleOpenEdit(g)}
                        className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteGuru(g.id, g.nama)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* Modal Add / Edit Guru */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl my-8 overflow-hidden">
            
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingGuru ? 'Edit Data Asatidz' : 'Tambah Guru / Asatidz Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveGuru} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nomor Induk Guru (NIG) *</label>
                  <input
                    type="text"
                    required
                    value={formData.nig || ''}
                    onChange={(e) => setFormData({ ...formData, nig: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Lengkap & Gelar *</label>
                  <input
                    type="text"
                    required
                    value={formData.nama || ''}
                    onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">No. HP / WhatsApp</label>
                  <input
                    type="text"
                    value={formData.noHp || ''}
                    onChange={(e) => setFormData({ ...formData, noHp: e.target.value })}
                    placeholder="081234567890"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Pendidikan Terakhir</label>
                  <input
                    type="text"
                    value={formData.pendidikanTerakhir || ''}
                    onChange={(e) => setFormData({ ...formData, pendidikanTerakhir: e.target.value })}
                    placeholder="Contoh: Ma'had Aly / S1 PAI"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tahun Mulai Mengajar</label>
                  <input
                    type="text"
                    value={formData.tahunMulaiMengajar || '2024'}
                    onChange={(e) => setFormData({ ...formData, tahunMulaiMengajar: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Status</label>
                  <select
                    value={formData.status || 'Aktif'}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as 'Aktif' | 'Non-Aktif' })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="Aktif">Aktif</option>
                    <option value="Non-Aktif">Non-Aktif</option>
                  </select>
                </div>

              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Mata Pelajaran / Bidang Pengajaran (Pisahkan koma)</label>
                <input
                  type="text"
                  value={formData.mapel?.join(', ') || ''}
                  onChange={(e) => setFormData({ ...formData, mapel: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                  placeholder="Contoh: Nahwu Al-Wasā'il, Kitab Yāqūtun Nafīs, 19 Kaidah I'lal"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Riwayat Mengajar & Spesialisasi</label>
                <textarea
                  rows={2}
                  value={formData.riwayatMengajar || ''}
                  onChange={(e) => setFormData({ ...formData, riwayatMengajar: e.target.value })}
                  placeholder="Pengalaman mengajar, sanad pembacaan kitab kuning, dsb."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Simpan Guru
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
