import React from 'react';
import { DatabaseState, UserAccount } from '../types';
import { NavTab } from './Sidebar';
import { Users, GraduationCap, Layers, CalendarCheck, Award, FileCheck2, Sparkles, AlertCircle, ArrowUpRight, TrendingUp } from 'lucide-react';

interface DashboardAdminProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onNavigate: (tab: NavTab) => void;
  onOpenMutuModal: () => void;
}

export const DashboardAdmin: React.FC<DashboardAdminProps> = ({
  db,
  currentUser,
  onNavigate,
  onOpenMutuModal
}) => {
  const totalSantri = db.santri.length;
  const santriAktif = db.santri.filter(s => s.status === 'Aktif').length;
  const totalGuru = db.guru.filter(g => g.status === 'Aktif').length;
  const totalKelas = db.kelas.length;
  const totalTashihLulus = db.tashih.filter(t => t.statusLulus === 'Lulus').length;

  // Santri needing attention
  const santriKesulitanCount = db.progres.filter(p => p.kesulitanKedudukanKalimat).length;

  // Recent Journals
  const recentJournals = [...db.jurnal].sort((a, b) => b.tanggal.localeCompare(a.tanggal)).slice(0, 4);

  // Recent Announcements
  const recentPengumuman = [...db.pengumuman].slice(0, 3);

  return (
    <div className="space-y-6">
      
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#0B1B3D] via-[#0E2656] to-[#0B1B3D] text-white p-6 sm:p-8 shadow-sm">
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-amber-300">
            <span className="font-arabic text-base">«بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ»</span>
            <span>·</span>
            <span>Pusat Kendali Admin Utama</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mb-2">
            Selamat Datang di Portal AL-WASĀ’IL
          </h1>
          <p className="text-xs sm:text-sm text-slate-200/90 leading-relaxed mb-4">
            Sistem Informasi & Manajemen Pendidikan Lembaga Al-Wasā’il PP Al-Ihsan Jrangoan.
            Memantau pembelajaran metode cepat membaca kitab kuning secara akurat dan berbasis data.
          </p>
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenMutuModal}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-[#0B1B3D] bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-sm"
            >
              <Sparkles className="w-4 h-4 text-[#0B1B3D]" />
              <span>Analisis Mutu Metodologi</span>
            </button>
            <button
              onClick={() => onNavigate('santri')}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl transition-colors"
            >
              <span>Kelola Data Santri</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Subtle decorative watermark Arabic badge */}
        <div className="absolute right-4 bottom-2 sm:right-8 sm:bottom-4 pointer-events-none opacity-10 select-none">
          <div className="font-arabic text-7xl sm:text-9xl text-amber-200 leading-none">
            الوسائل
          </div>
        </div>
      </div>

      {/* KPI Stat Cards Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div 
          onClick={() => onNavigate('santri')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Santri Aktif</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-num">
            {santriAktif}
            <span className="text-xs text-slate-400 font-normal ml-1.5 font-sans">/ {totalSantri} total</span>
          </div>
          <div className="text-[11px] text-emerald-600 font-medium flex items-center gap-1 mt-1">
            <TrendingUp className="w-3 h-3" />
            <span>Terdaftar di 4 Rombel Kelas</span>
          </div>
        </div>

        <div 
          onClick={() => onNavigate('guru')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Asatidz Pengampu</span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-700">
              <GraduationCap className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-num">{totalGuru}</div>
          <div className="text-[11px] text-slate-500 font-medium mt-1">
            Guru Al-Wasā'il & Musahhih
          </div>
        </div>

        <div 
          onClick={() => onNavigate('kelas')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Rombel Kelas</span>
            <div className="p-2 rounded-lg bg-purple-50 text-purple-700">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-num">{totalKelas}</div>
          <div className="text-[11px] text-slate-500 font-medium mt-1">
            I’dadiyah & Takhassus A/B/C
          </div>
        </div>

        <div 
          onClick={() => onNavigate('tashih')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Syahadah Tashih</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono-num">{totalTashihLulus}</div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">
            Lulus Tashih Kitab Kuning
          </div>
        </div>

      </div>

      {/* Critical Pedagogical Alert Notice (Santri Kesulitan Tarkib) */}
      {santriKesulitanCount > 0 && (
        <div className="p-4 bg-amber-50/80 border border-amber-200/90 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-amber-500 text-white rounded-lg shrink-0 mt-0.5">
              <AlertCircle className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-950">
                Peringatan Mutu: Terdeteksi {santriKesulitanCount} Santri Mengalami Kesulitan Kedudukan Kalimat
              </div>
              <div className="text-[11px] text-amber-900/80 mt-0.5">
                Santri memerlukan bimbingan taktis khusus pada materi tarkib (Fa'il, Maf'ul, Hal & Tamyiz) sebelum memasuki tahapan Tashih.
              </div>
            </div>
          </div>
          <button
            onClick={onOpenMutuModal}
            className="shrink-0 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Lihat Rekomendasi Bimbingan
          </button>
        </div>
      )}

      {/* Two Column Layout: Quick Modules & Recent Journals */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Activity & Class Summary */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Quick Access Card Grid */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">Akses Modul Cepat</h3>
              <span className="text-xs text-slate-400">Pusat Administrasi</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <button
                onClick={() => onNavigate('santri')}
                className="p-3.5 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/40 transition-all group"
              >
                <div className="w-10 h-10 mx-auto rounded-xl bg-blue-50 group-hover:bg-blue-100 text-blue-700 flex items-center justify-center mb-2 transition-colors">
                  <Users className="w-5 h-5" />
                </div>
                <div className="text-xs font-semibold text-slate-800">Biodata Santri</div>
                <div className="text-[10px] text-slate-400">Cari, Input & Cetak</div>
              </button>

              <button
                onClick={() => onNavigate('absensi')}
                className="p-3.5 rounded-xl border border-slate-100 hover:border-amber-200 hover:bg-amber-50/40 transition-all group"
              >
                <div className="w-10 h-10 mx-auto rounded-xl bg-amber-50 group-hover:bg-amber-100 text-amber-700 flex items-center justify-center mb-2 transition-colors">
                  <CalendarCheck className="w-5 h-5" />
                </div>
                <div className="text-xs font-semibold text-slate-800">Absensi Harian</div>
                <div className="text-[10px] text-slate-400">Presensi & Rekap</div>
              </button>

              <button
                onClick={() => onNavigate('penilaian')}
                className="p-3.5 rounded-xl border border-slate-100 hover:border-emerald-200 hover:bg-emerald-50/40 transition-all group"
              >
                <div className="w-10 h-10 mx-auto rounded-xl bg-emerald-50 group-hover:bg-emerald-100 text-emerald-700 flex items-center justify-center mb-2 transition-colors">
                  <Award className="w-5 h-5" />
                </div>
                <div className="text-xs font-semibold text-slate-800">Nilai & Rapor</div>
                <div className="text-[10px] text-slate-400">8 Bidang Al-Wasā'il</div>
              </button>

              <button
                onClick={() => onNavigate('tashih')}
                className="p-3.5 rounded-xl border border-slate-100 hover:border-purple-200 hover:bg-purple-50/40 transition-all group"
              >
                <div className="w-10 h-10 mx-auto rounded-xl bg-purple-50 group-hover:bg-purple-100 text-purple-700 flex items-center justify-center mb-2 transition-colors">
                  <FileCheck2 className="w-5 h-5" />
                </div>
                <div className="text-xs font-semibold text-slate-800">Ujian Tashih</div>
                <div className="text-[10px] text-slate-400">Ijazah & Syahadah</div>
              </button>
            </div>
          </div>

          {/* Rombel Classes Status Table */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">Status Rombongan Belajar (Rombel)</h3>
              <button 
                onClick={() => onNavigate('kelas')}
                className="text-xs font-medium text-blue-600 hover:underline"
              >
                Kelola Kelas →
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Kelas</th>
                    <th className="py-2.5 px-3">Wali Kelas</th>
                    <th className="py-2.5 px-3 text-center">Jumlah Santri</th>
                    <th className="py-2.5 px-3">Fokus Kurikulum Al-Wasā'il</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {db.kelas.map(k => {
                    const wali = db.guru.find(g => g.id === k.waliKelasId);
                    const count = db.santri.filter(s => s.kelasId === k.id && s.status === 'Aktif').length;
                    return (
                      <tr key={k.id} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3 font-bold text-slate-900">{k.nama}</td>
                        <td className="py-2.5 px-3 text-slate-700">{wali?.nama || '-'}</td>
                        <td className="py-2.5 px-3 text-center font-mono-num font-semibold text-slate-800">{count} Santri</td>
                        <td className="py-2.5 px-3 text-slate-500 text-[11px] truncate max-w-xs">{k.keterangan}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right Col: Recent Teaching Journals & Announcements */}
        <div className="space-y-6">
          
          {/* Recent Teaching Journals */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">Jurnal Guru Terkini</h3>
              <button 
                onClick={() => onNavigate('jurnal')}
                className="text-xs font-medium text-blue-600 hover:underline"
              >
                Lihat Semua
              </button>
            </div>

            <div className="space-y-3">
              {recentJournals.map(j => (
                <div key={j.id} className="p-3 rounded-lg bg-slate-50 border border-slate-100 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{j.kelasNama}</span>
                    <span className="text-[10px] text-slate-400 font-mono-num">{j.tanggal}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">{j.guruNama}</div>
                  <div className="text-[11px] text-slate-700 line-clamp-2">
                    <span className="font-semibold text-slate-800">Materi: </span>
                    {j.materiDiajarkan}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pengumuman Lembaga */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">Agenda & Pengumuman</h3>
              <button 
                onClick={() => onNavigate('pengumuman')}
                className="text-xs font-medium text-blue-600 hover:underline"
              >
                Pusat Info
              </button>
            </div>

            <div className="space-y-2.5">
              {recentPengumuman.map(p => (
                <div key={p.id} className="p-3 rounded-lg border border-slate-100 space-y-1 text-xs">
                  <div className="flex items-center gap-1.5 text-[10px] text-amber-700 font-semibold">
                    <span>{p.kategori}</span>
                    <span className="text-slate-300">·</span>
                    <span className="text-slate-400 font-mono-num">{p.tanggal}</span>
                  </div>
                  <div className="font-bold text-slate-900 text-xs leading-snug">{p.judul}</div>
                  <p className="text-[11px] text-slate-500 line-clamp-2">{p.isi}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
