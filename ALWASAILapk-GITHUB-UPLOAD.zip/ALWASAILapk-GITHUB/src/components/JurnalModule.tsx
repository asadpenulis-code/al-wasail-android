import React, { useState } from 'react';
import { DatabaseState, JurnalGuru, UserAccount } from '../types';
import { FileText, Plus, Search, Calendar, CheckCircle2, Clock, Trash2, Edit2, X, Download } from 'lucide-react';
import { exportToCSV } from '../services/db';

interface JurnalModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdateJurnal: (jurnalList: JurnalGuru[]) => void;
}

export const JurnalModule: React.FC<JurnalModuleProps> = ({
  db,
  currentUser,
  onUpdateJurnal
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedKelasFilter, setSelectedKelasFilter] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingJurnal, setEditingJurnal] = useState<JurnalGuru | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<JurnalGuru>>({
    kelasId: db.kelas[0]?.id || 'k-1',
    tanggal: new Date().toISOString().split('T')[0],
    materiDiajarkan: '',
    targetPembelajaran: '',
    materiSelesai: '',
    kendala: '',
    catatanEvaluasi: '',
    statusVerifikasi: 'Terverifikasi'
  });

  const canAdd = currentUser.role === 'admin' || currentUser.role === 'guru';

  const filteredJurnal = db.jurnal.filter(j => {
    const matchSearch = j.guruNama.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        j.materiDiajarkan.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        j.kelasNama.toLowerCase().includes(searchTerm.toLowerCase());
    const matchKelas = selectedKelasFilter === 'all' || j.kelasId === selectedKelasFilter;
    return matchSearch && matchKelas;
  });

  const handleOpenAdd = () => {
    setEditingJurnal(null);
    setFormData({
      kelasId: db.kelas[0]?.id || 'k-1',
      tanggal: new Date().toISOString().split('T')[0],
      materiDiajarkan: '',
      targetPembelajaran: '',
      materiSelesai: '',
      kendala: '',
      catatanEvaluasi: '',
      statusVerifikasi: 'Terverifikasi'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (j: JurnalGuru) => {
    setEditingJurnal(j);
    setFormData(j);
    setIsModalOpen(true);
  };

  const handleSaveJurnal = (e: React.FormEvent) => {
    e.preventDefault();
    const kls = db.kelas.find(k => k.id === formData.kelasId);
    if (!kls || !formData.materiDiajarkan) return;

    const teacherName = currentUser.role === 'guru' 
      ? currentUser.name 
      : (db.guru.find(g => g.id === kls.waliKelasId)?.nama || 'Ust. Ahmad Ghazali, S.Pd.I');
    
    const teacherId = currentUser.relatedId || kls.waliKelasId || 'g-1';

    const newJurnal: JurnalGuru = {
      id: editingJurnal?.id || `jur-${Date.now()}`,
      guruId: teacherId,
      guruNama: teacherName,
      kelasId: kls.id,
      kelasNama: kls.nama,
      tanggal: formData.tanggal || new Date().toISOString().split('T')[0],
      materiDiajarkan: formData.materiDiajarkan || '',
      targetPembelajaran: formData.targetPembelajaran || '',
      materiSelesai: formData.materiSelesai || '',
      kendala: formData.kendala || 'Tidak ada kendala',
      catatanEvaluasi: formData.catatanEvaluasi || 'Berjalan lancar',
      statusVerifikasi: formData.statusVerifikasi || 'Terverifikasi'
    };

    if (editingJurnal) {
      onUpdateJurnal(db.jurnal.map(j => j.id === editingJurnal.id ? newJurnal : j));
    } else {
      onUpdateJurnal([newJurnal, ...db.jurnal]);
    }

    setIsModalOpen(false);
  };

  const handleDeleteJurnal = (id: string) => {
    if (window.confirm("Hapus catatan jurnal mengajar ini?")) {
      onUpdateJurnal(db.jurnal.filter(j => j.id !== id));
    }
  };

  const handleExportCSV = () => {
    const headers = ['Tanggal', 'Guru Pengampu', 'Kelas', 'Materi Diajarkan', 'Target', 'Materi Selesai', 'Kendala', 'Evaluasi'];
    const rows = filteredJurnal.map(j => [
      j.tanggal,
      j.guruNama,
      j.kelasNama,
      j.materiDiajarkan,
      j.targetPembelajaran,
      j.materiSelesai,
      j.kendala,
      j.catatanEvaluasi
    ]);
    const dateStr = new Date().toISOString().split('T')[0];
    exportToCSV(`jurnal_guru_alwasail_${dateStr}`, headers, rows);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <FileText className="w-4 h-4" />
            <span>Dokumentasi Pembelajaran Asatidz</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Jurnal Pembelajaran Guru Al-Wasā’il
          </h2>
          <p className="text-xs text-slate-500">
            Mencatat materi kitab yang diajarkan, target capaian, kendala kelas, dan catatan evaluasi harian.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Ekspor Jurnal (CSV)</span>
          </button>

          {canAdd && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <Plus className="w-4 h-4 text-amber-300" />
              <span>Isi Jurnal Baru</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari guru, kelas, atau materi..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-slate-500 font-medium">Filter Kelas:</span>
          <select
            value={selectedKelasFilter}
            onChange={(e) => setSelectedKelasFilter(e.target.value)}
            className="py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
          >
            <option value="all">Semua Kelas</option>
            {db.kelas.map(k => (
              <option key={k.id} value={k.id}>{k.nama}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Jurnal List */}
      <div className="space-y-4">
        {filteredJurnal.map(j => (
          <div key={j.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-blue-50 text-blue-700">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{j.guruNama}</span>
                    <span className="text-slate-300">·</span>
                    <span className="text-xs font-semibold text-blue-800 bg-blue-50 px-2 py-0.5 rounded">
                      Kelas: {j.kelasNama}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono-num flex items-center gap-1.5 mt-0.5">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    <span>{j.tanggal}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto">
                <span className="px-2.5 py-1 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{j.statusVerifikasi}</span>
                </span>

                {canAdd && (
                  <>
                    <button
                      onClick={() => handleOpenEdit(j)}
                      className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteJurnal(j.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Details Content */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                <span className="text-slate-400 font-bold uppercase text-[10px]">Materi yang Diajarkan</span>
                <p className="font-semibold text-slate-900">{j.materiDiajarkan}</p>
                <div className="text-[11px] text-slate-600 pt-1">
                  <strong className="text-slate-800">Target Pembelajaran: </strong>
                  {j.targetPembelajaran}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                <span className="text-slate-400 font-bold uppercase text-[10px]">Capaian & Hasil Selesai</span>
                <p className="font-semibold text-emerald-900">{j.materiSelesai}</p>
                <div className="text-[11px] text-slate-600 pt-1">
                  <strong className="text-slate-800">Kendala Kelas: </strong>
                  {j.kendala}
                </div>
              </div>
            </div>

            {j.catatanEvaluasi && (
              <div className="p-2.5 bg-amber-50/60 rounded-xl border border-amber-100/70 text-xs text-amber-950">
                <span className="font-bold">Catatan Evaluasi Guru: </span>
                {j.catatanEvaluasi}
              </div>
            )}

          </div>
        ))}
      </div>

      {/* Modal Add / Edit Jurnal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl my-8 overflow-hidden">
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingJurnal ? 'Edit Jurnal Pembelajaran' : 'Isi Jurnal Pembelajaran Guru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveJurnal} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Pilih Kelas *</label>
                  <select
                    value={formData.kelasId || ''}
                    onChange={(e) => setFormData({ ...formData, kelasId: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                  >
                    {db.kelas.map(k => (
                      <option key={k.id} value={k.id}>{k.nama}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tanggal Mengajar *</label>
                  <input
                    type="date"
                    required
                    value={formData.tanggal || ''}
                    onChange={(e) => setFormData({ ...formData, tanggal: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Materi yang Diajarkan *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Kitab Yāqūtun Nafīs Bab Shalat & Shufhah 18 (Tarkib Fa'il)"
                  value={formData.materiDiajarkan || ''}
                  onChange={(e) => setFormData({ ...formData, materiDiajarkan: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Target Pembelajaran</label>
                <input
                  type="text"
                  placeholder="Contoh: Santri mampu mengidentifikasi fa'il pada ibarat syarat sah shalat"
                  value={formData.targetPembelajaran || ''}
                  onChange={(e) => setFormData({ ...formData, targetPembelajaran: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Materi yang Berhasil Diselesaikan</label>
                <input
                  type="text"
                  placeholder="Contoh: Tuntas 2 halaman dan praktik membaca gundul oleh 6 santri"
                  value={formData.materiSelesai || ''}
                  onChange={(e) => setFormData({ ...formData, materiSelesai: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Kendala Pembelajaran di Kelas</label>
                <textarea
                  rows={2}
                  placeholder="Contoh: Beberapa santri masih tertukar membedakan Maf'ul Bih dan Maf'ul Fih"
                  value={formData.kendala || ''}
                  onChange={(e) => setFormData({ ...formData, kendala: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Catatan Evaluasi / Solusi Pertemuan Berikutnya</label>
                <textarea
                  rows={2}
                  placeholder="Contoh: Diberikan latihan mandiri 5 contoh tarkib untuk diperiksa besok"
                  value={formData.catatanEvaluasi || ''}
                  onChange={(e) => setFormData({ ...formData, catatanEvaluasi: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Simpan Jurnal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
