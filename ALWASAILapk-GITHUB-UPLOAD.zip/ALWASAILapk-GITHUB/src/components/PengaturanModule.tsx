import React, { useState } from 'react';
import { DatabaseState, PengaturanLembaga, UserAccount } from '../types';
import { Settings, Save, Database, Smartphone, Shield, Building2, Upload, RefreshCw, CheckCircle2 } from 'lucide-react';
import { downloadDatabaseBackup, resetDatabaseToDefault } from '../services/db';

interface PengaturanModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdatePengaturan: (pengaturan: PengaturanLembaga) => void;
  onOpenBackupModal: () => void;
}

export const PengaturanModule: React.FC<PengaturanModuleProps> = ({
  db,
  currentUser,
  onUpdatePengaturan,
  onOpenBackupModal
}) => {
  const [formData, setFormData] = useState<PengaturanLembaga>(db.pengaturan);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const canEdit = currentUser.role === 'admin';

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdatePengaturan(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <Settings className="w-4 h-4" />
            <span>Konfigurasi Sistem & Lembaga</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Pengaturan Lembaga & Database
          </h2>
          <p className="text-xs text-slate-500">
            Mengatur identitas resmi Al-Wasā'il, KKM Tashih, tahun ajaran aktif, dan pencadangan data.
          </p>
        </div>

        <button
          onClick={onOpenBackupModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs self-start md:self-auto"
        >
          <Database className="w-4 h-4 text-amber-300" />
          <span>Cadangkan / Pulihkan Database</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2.5 text-xs text-emerald-800 font-semibold">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Pengaturan identitas lembaga berhasil disimpan secara permanen ke database!</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSave} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-6 text-xs">
        
        <div>
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 mb-1">
            <Building2 className="w-4 h-4 text-blue-600" />
            <span>Identitas Resmi Lembaga Al-Wasā'il</span>
          </h3>
          <p className="text-slate-500 text-[11px]">
            Data ini tercetak pada kop surat rapor santri, syahadah kelulusan tashih, dan dokumen administrasi.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          <div>
            <label className="block text-slate-700 font-semibold mb-1">Nama Lembaga *</label>
            <input
              type="text"
              required
              disabled={!canEdit}
              value={formData.namaLembaga}
              onChange={(e) => setFormData({ ...formData, namaLembaga: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-bold"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Naungan Pesantren *</label>
            <input
              type="text"
              required
              disabled={!canEdit}
              value={formData.naungan}
              onChange={(e) => setFormData({ ...formData, naungan: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Slogan Resmi (Bahasa Arab) *</label>
            <input
              type="text"
              required
              disabled={!canEdit}
              value={formData.sloganArab}
              onChange={(e) => setFormData({ ...formData, sloganArab: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-arabic font-bold text-sm text-amber-900"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Slogan (Bahasa Indonesia) *</label>
            <input
              type="text"
              required
              disabled={!canEdit}
              value={formData.sloganIndo}
              onChange={(e) => setFormData({ ...formData, sloganIndo: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg italic"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Nama Pengasuh / Pimpinan Lembaga *</label>
            <input
              type="text"
              required
              disabled={!canEdit}
              value={formData.namaPimpinan}
              onChange={(e) => setFormData({ ...formData, namaPimpinan: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-bold"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Tahun Ajaran Aktif *</label>
            <input
              type="text"
              required
              disabled={!canEdit}
              value={formData.tahunAjaranAktif}
              onChange={(e) => setFormData({ ...formData, tahunAjaranAktif: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num font-semibold"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Standar KKM Kelulusan Tashih (0-100) *</label>
            <input
              type="number"
              min={50}
              max={100}
              required
              disabled={!canEdit}
              value={formData.kkmTashih}
              onChange={(e) => setFormData({ ...formData, kkmTashih: Number(e.target.value) })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num font-bold"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Nomor Kontak Lembaga</label>
            <input
              type="text"
              disabled={!canEdit}
              value={formData.telepon}
              onChange={(e) => setFormData({ ...formData, telepon: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-slate-700 font-semibold mb-1">Alamat Lengkap Lembaga</label>
            <input
              type="text"
              disabled={!canEdit}
              value={formData.alamatLembaga}
              onChange={(e) => setFormData({ ...formData, alamatLembaga: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-slate-700 font-semibold mb-1">URL Logo Lembaga (Opsional)</label>
            <input
              type="text"
              disabled={!canEdit}
              placeholder="Kosongkan untuk menggunakan lambang kaligrafi resmi bawaan"
              value={formData.logoUrl || ''}
              onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>

        </div>

        {canEdit && (
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end">
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <Save className="w-4 h-4 text-amber-300" />
              <span>Simpan Perubahan Pengaturan</span>
            </button>
          </div>
        )}

      </form>

      {/* Android APK & Capacitor Configuration Instructions Guide */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-3 text-xs">
        <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
          <Smartphone className="w-4 h-4 text-emerald-600" />
          <span>Panduan Konversi Menjadi Aplikasi Android (APK) dengan Capacitor</span>
        </div>
        <p className="text-slate-600 leading-relaxed">
          Proyek <strong>AL-WASĀ’IL</strong> telah dilengkapi berkas konfigurasi resmi <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-mono">capacitor.config.ts</code> dengan App ID <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-mono">id.ponpes.alihsanjrangoan.alwasail</code>.
        </p>

        <div className="bg-slate-900 text-slate-200 p-4 rounded-xl font-mono text-[11px] space-y-2 overflow-x-auto">
          <div className="text-slate-400 font-sans font-semibold">Langkah Mudah Build APK Android:</div>
          <div>1. Build aset web aplikasi:</div>
          <div className="text-amber-300 font-bold">npm run build</div>
          <div>2. Tambahkan platform Android:</div>
          <div className="text-amber-300 font-bold">npx cap add android</div>
          <div>3. Sinkronisasikan berkas:</div>
          <div className="text-amber-300 font-bold">npx cap sync</div>
          <div>4. Buka di Android Studio untuk generate APK siap pasang:</div>
          <div className="text-amber-300 font-bold">npx cap open android</div>
        </div>
      </div>

    </div>
  );
};
