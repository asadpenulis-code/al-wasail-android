import React, { useState } from 'react';
import { DatabaseState, Santri, UserAccount, Gender, StatusSantri } from '../types';
import { exportToCSV } from '../services/db';
import { 
  Users, Plus, Search, Filter, Download, Printer, Edit2, Trash2, ArrowRightLeft, 
  Phone, MapPin, Calendar, CheckCircle, X, Eye, Sparkles
} from 'lucide-react';

interface SantriModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdateSantri: (santriList: Santri[]) => void;
  onSelectSantriForDetail?: (santriId: string) => void;
}

export const SantriModule: React.FC<SantriModuleProps> = ({
  db,
  currentUser,
  onUpdateSantri
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedKelas, setSelectedKelas] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedGender, setSelectedGender] = useState<string>('all');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSantri, setEditingSantri] = useState<Santri | null>(null);
  const [detailSantri, setDetailSantri] = useState<Santri | null>(null);
  const [transferSantri, setTransferSantri] = useState<Santri | null>(null);
  const [targetKelasId, setTargetKelasId] = useState<string>('');
  const [transferNote, setTransferNote] = useState<string>('');

  // Form State for Add / Edit
  const [formData, setFormData] = useState<Partial<Santri>>({
    nis: '',
    nama: '',
    gender: 'L',
    tempatLahir: '',
    tanggalLahir: '',
    alamat: '',
    namaAyah: '',
    namaIbu: '',
    noHpWali: '',
    lembagaAsal: 'PP Al-Ihsan Jrangoan - Pusat',
    tahunMasuk: '2024',
    status: 'Aktif',
    kelasId: db.kelas[0]?.id || 'k-1',
    catatanKhusus: ''
  });

  const canEdit = currentUser.role === 'admin' || currentUser.role === 'guru';

  // Filtered List
  const filteredSantri = db.santri.filter(s => {
    const matchSearch = s.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        s.nis.includes(searchTerm) ||
                        s.lembagaAsal.toLowerCase().includes(searchTerm.toLowerCase());
    const matchKelas = selectedKelas === 'all' || s.kelasId === selectedKelas;
    const matchStatus = selectedStatus === 'all' || s.status === selectedStatus;
    const matchGender = selectedGender === 'all' || s.gender === selectedGender;
    return matchSearch && matchKelas && matchStatus && matchGender;
  });

  // Handle Export to CSV/Excel
  const handleExportCSV = () => {
    const headers = [
      'NIS', 'Nama Lengkap', 'Jenis Kelamin', 'Tempat Lahir', 'Tanggal Lahir',
      'Alamat', 'Nama Ayah', 'Nama Ibu', 'No HP Wali', 'Lembaga Asal',
      'Tahun Masuk', 'Status', 'Kelas', 'Wali Kelas', 'Catatan Khusus'
    ];

    const rows = filteredSantri.map(s => {
      const kls = db.kelas.find(k => k.id === s.kelasId);
      const wali = db.guru.find(g => g.id === kls?.waliKelasId);
      return [
        s.nis,
        s.nama,
        s.gender === 'L' ? 'Laki-laki' : 'Perempuan',
        s.tempatLahir,
        s.tanggalLahir,
        s.alamat,
        s.namaAyah,
        s.namaIbu,
        s.noHpWali,
        s.lembagaAsal,
        s.tahunMasuk,
        s.status,
        kls?.nama || '-',
        wali?.nama || '-',
        s.catatanKhusus || ''
      ];
    });

    const dateStr = new Date().toISOString().split('T')[0];
    exportToCSV(`data_santri_alwasail_${dateStr}`, headers, rows);
  };

  // Open Add Modal
  const handleOpenAdd = () => {
    // Generate next NIS suggestion
    const nextNis = `2024${String(db.santri.length + 1).padStart(4, '0')}`;
    setFormData({
      nis: nextNis,
      nama: '',
      gender: 'L',
      tempatLahir: 'Sampang',
      tanggalLahir: '2008-01-01',
      alamat: '',
      namaAyah: '',
      namaIbu: '',
      noHpWali: '',
      lembagaAsal: 'PP Al-Ihsan Jrangoan - Pusat',
      tahunMasuk: '2024',
      status: 'Aktif',
      kelasId: db.kelas[0]?.id || 'k-1',
      catatanKhusus: ''
    });
    setEditingSantri(null);
    setIsAddModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (s: Santri) => {
    setFormData(s);
    setEditingSantri(s);
    setIsAddModalOpen(true);
  };

  // Save Add / Edit
  const handleSaveSantri = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama || !formData.nis) return;

    if (editingSantri) {
      // Edit existing
      const updated = db.santri.map(s => s.id === editingSantri.id ? { ...s, ...(formData as Santri) } : s);
      onUpdateSantri(updated);
    } else {
      // Create new
      const newSantri: Santri = {
        id: `s-${Date.now()}`,
        nis: formData.nis || '',
        nama: formData.nama || '',
        gender: (formData.gender as Gender) || 'L',
        tempatLahir: formData.tempatLahir || '',
        tanggalLahir: formData.tanggalLahir || '',
        alamat: formData.alamat || '',
        namaAyah: formData.namaAyah || '',
        namaIbu: formData.namaIbu || '',
        noHpWali: formData.noHpWali || '',
        lembagaAsal: formData.lembagaAsal || 'PP Al-Ihsan Jrangoan',
        tahunMasuk: formData.tahunMasuk || '2024',
        status: (formData.status as StatusSantri) || 'Aktif',
        kelasId: formData.kelasId || db.kelas[0]?.id || 'k-1',
        catatanKhusus: formData.catatanKhusus || '',
        riwayatKelas: [
          {
            kelasId: formData.kelasId || db.kelas[0]?.id || 'k-1',
            kelasNama: db.kelas.find(k => k.id === formData.kelasId)?.nama || 'I’dadiyah',
            tahunAjaran: db.pengaturan.tahunAjaranAktif,
            tanggalPindah: new Date().toISOString().split('T')[0],
            keterangan: 'Pendaftaran Awal Santri'
          }
        ]
      };
      onUpdateSantri([...db.santri, newSantri]);
    }
    setIsAddModalOpen(false);
  };

  // Delete Santri
  const handleDeleteSantri = (id: string, nama: string) => {
    if (window.confirm(`Yakin ingin menghapus data santri "${nama}"?`)) {
      onUpdateSantri(db.santri.filter(s => s.id !== id));
    }
  };

  // Open Transfer Modal
  const handleOpenTransfer = (s: Santri) => {
    setTransferSantri(s);
    setTargetKelasId(s.kelasId);
    setTransferNote('');
  };

  // Process Class Transfer
  const handleProcessTransfer = () => {
    if (!transferSantri || !targetKelasId || targetKelasId === transferSantri.kelasId) return;

    const targetKelas = db.kelas.find(k => k.id === targetKelasId);
    if (!targetKelas) return;

    const newHistory = [
      ...(transferSantri.riwayatKelas || []),
      {
        kelasId: targetKelas.id,
        kelasNama: targetKelas.nama,
        tahunAjaran: db.pengaturan.tahunAjaranAktif,
        tanggalPindah: new Date().toISOString().split('T')[0],
        keterangan: transferNote || `Kenaikan / Pemindahan kelas ke ${targetKelas.nama}`
      }
    ];

    const updated = db.santri.map(s => {
      if (s.id === transferSantri.id) {
        return {
          ...s,
          kelasId: targetKelas.id,
          riwayatKelas: newHistory
        };
      }
      return s;
    });

    onUpdateSantri(updated);
    setTransferSantri(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <Users className="w-4 h-4" />
            <span>Modul Data Santri Al-Wasā’il</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Buku Induk & Administrasi Santri
          </h2>
          <p className="text-xs text-slate-500">
            Total {db.santri.length} santri terdaftar di sistem PP Al-Ihsan Jrangoan.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Ekspor Excel/CSV</span>
          </button>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Printer className="w-4 h-4 text-slate-600" />
            <span>Cetak Rekap</span>
          </button>

          {canEdit && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <Plus className="w-4 h-4 text-amber-300" />
              <span>Tambah Santri Baru</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          
          {/* Search Box */}
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nama santri, NIS, atau cabang..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          {/* Filter Kelas */}
          <div>
            <select
              value={selectedKelas}
              onChange={(e) => setSelectedKelas(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="all">Semua Kelas</option>
              {db.kelas.map(k => (
                <option key={k.id} value={k.id}>{k.nama}</option>
              ))}
            </select>
          </div>

          {/* Filter Status */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="all">Semua Status</option>
              <option value="Aktif">Aktif</option>
              <option value="Tidak Aktif">Tidak Aktif</option>
              <option value="Lulus">Lulus</option>
            </select>
          </div>

          {/* Filter Gender */}
          <div>
            <select
              value={selectedGender}
              onChange={(e) => setSelectedGender(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="all">Semua Gender</option>
              <option value="L">Santri Putra (L)</option>
              <option value="P">Santri Putri (P)</option>
            </select>
          </div>

        </div>

        {/* Active Result Count */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
          <span>Menampilkan <strong className="text-slate-800 font-mono-num">{filteredSantri.length}</strong> santri dari total {db.santri.length} santri</span>
          {(searchTerm || selectedKelas !== 'all' || selectedStatus !== 'all' || selectedGender !== 'all') && (
            <button
              onClick={() => { setSearchTerm(''); setSelectedKelas('all'); setSelectedStatus('all'); setSelectedGender('all'); }}
              className="text-blue-600 hover:underline font-medium"
            >
              Reset Filter
            </button>
          )}
        </div>
      </div>

      {/* Santri Data Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-3">Santri</th>
                <th className="py-3 px-3">NIS</th>
                <th className="py-3 px-3">Kelas & Wali</th>
                <th className="py-3 px-3">Lembaga / Asal</th>
                <th className="py-3 px-3">Kontak Wali</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSantri.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    Tidak ada santri yang sesuai dengan kriteria filter pencarian.
                  </td>
                </tr>
              ) : (
                filteredSantri.map(s => {
                  const kls = db.kelas.find(k => k.id === s.kelasId);
                  const wali = db.guru.find(g => g.id === kls?.waliKelasId);
                  const prog = db.progres.find(p => p.santriId === s.id);

                  return (
                    <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                      
                      {/* Name & Avatar */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                            s.gender === 'L' ? 'bg-blue-100 text-blue-800' : 'bg-pink-100 text-pink-800'
                          }`}>
                            {s.nama.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 hover:text-blue-600 cursor-pointer" onClick={() => setDetailSantri(s)}>
                              {s.nama}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {s.gender === 'L' ? 'Putra' : 'Putri'} · {s.tempatLahir}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* NIS */}
                      <td className="py-3 px-3 font-mono-num font-semibold text-slate-700">
                        {s.nis}
                      </td>

                      {/* Class & Wali */}
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-800">{kls?.nama || '-'}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[130px]">{wali?.nama || '-'}</div>
                      </td>

                      {/* Origin Institution */}
                      <td className="py-3 px-3 text-slate-600 text-[11px]">
                        <div className="truncate max-w-[140px]" title={s.lembagaAsal}>{s.lembagaAsal}</div>
                        <div className="text-[10px] text-slate-400">Masuk: {s.tahunMasuk}</div>
                      </td>

                      {/* Phone Wali with direct WhatsApp click */}
                      <td className="py-3 px-3">
                        <a
                          href={`https://wa.me/${s.noHpWali.replace(/[^0-9]/g, '').replace(/^0/, '62')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[11px] font-mono-num text-emerald-700 hover:text-emerald-800 hover:underline bg-emerald-50 px-2 py-0.5 rounded-md"
                        >
                          <Phone className="w-3 h-3 text-emerald-600" />
                          <span>{s.noHpWali}</span>
                        </a>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          s.status === 'Aktif'
                            ? 'bg-emerald-100 text-emerald-800'
                            : s.status === 'Lulus'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {s.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setDetailSantri(s)}
                            title="Lihat Detail Profil & Riwayat"
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {canEdit && (
                            <>
                              <button
                                onClick={() => handleOpenTransfer(s)}
                                title="Pindahkan Rombel Kelas"
                                className="p-1.5 text-slate-500 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                              >
                                <ArrowRightLeft className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => handleOpenEdit(s)}
                                title="Edit Biodata"
                                className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => handleDeleteSantri(s.id, s.nama)}
                                title="Hapus Santri"
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Add or Edit Santri */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl my-8 overflow-hidden">
            
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingSantri ? 'Edit Data Santri' : 'Tambah Santri Baru Al-Wasā’il'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSantri} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nomor Induk Santri (NIS) *</label>
                  <input
                    type="text"
                    required
                    value={formData.nis || ''}
                    onChange={(e) => setFormData({ ...formData, nis: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Lengkap Santri *</label>
                  <input
                    type="text"
                    required
                    value={formData.nama || ''}
                    onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Jenis Kelamin</label>
                  <select
                    value={formData.gender || 'L'}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as Gender })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="L">Laki-laki (Putra)</option>
                    <option value="P">Perempuan (Putri)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Status Keaktifan</label>
                  <select
                    value={formData.status || 'Aktif'}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as StatusSantri })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="Aktif">Aktif</option>
                    <option value="Tidak Aktif">Tidak Aktif</option>
                    <option value="Lulus">Lulus</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tempat Lahir</label>
                  <input
                    type="text"
                    value={formData.tempatLahir || ''}
                    onChange={(e) => setFormData({ ...formData, tempatLahir: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tanggal Lahir</label>
                  <input
                    type="date"
                    value={formData.tanggalLahir || ''}
                    onChange={(e) => setFormData({ ...formData, tanggalLahir: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Penempatan Kelas</label>
                  <select
                    value={formData.kelasId || ''}
                    onChange={(e) => setFormData({ ...formData, kelasId: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                  >
                    {db.kelas.map(k => (
                      <option key={k.id} value={k.id}>{k.nama}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tahun Masuk</label>
                  <input
                    type="text"
                    value={formData.tahunMasuk || '2024'}
                    onChange={(e) => setFormData({ ...formData, tahunMasuk: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Ayah</label>
                  <input
                    type="text"
                    value={formData.namaAyah || ''}
                    onChange={(e) => setFormData({ ...formData, namaAyah: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Ibu</label>
                  <input
                    type="text"
                    value={formData.namaIbu || ''}
                    onChange={(e) => setFormData({ ...formData, namaIbu: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">No. HP / WhatsApp Wali</label>
                  <input
                    type="text"
                    placeholder="Contoh: 081234567890"
                    value={formData.noHpWali || ''}
                    onChange={(e) => setFormData({ ...formData, noHpWali: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Lembaga Asal / Cabang</label>
                  <input
                    type="text"
                    value={formData.lembagaAsal || ''}
                    onChange={(e) => setFormData({ ...formData, lembagaAsal: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Alamat Lengkap</label>
                <textarea
                  rows={2}
                  value={formData.alamat || ''}
                  onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                  placeholder="Dusun, Desa/Kelurahan, Kecamatan, Kabupaten..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Catatan Khusus Santri</label>
                <textarea
                  rows={2}
                  value={formData.catatanKhusus || ''}
                  onChange={(e) => setFormData({ ...formData, catatanKhusus: e.target.value })}
                  placeholder="Catatan perkembangan khusus, riwayat kesehatan, atau arahan metodologi..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Simpan Data Santri
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Modal: Transfer Class (Pemindahan Antarkelas Tanpa Menghilangkan Riwayat) */}
      {transferSantri && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="px-5 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4 text-amber-300" />
                <h3 className="text-sm font-bold">Pindah Kelas Santri</h3>
              </div>
              <button
                onClick={() => setTransferSantri(null)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
                <div className="font-bold text-slate-900 text-sm">{transferSantri.nama}</div>
                <div className="text-slate-500 font-mono-num">NIS: {transferSantri.nis}</div>
                <div className="text-slate-700">
                  Kelas Saat Ini: <strong className="text-blue-700">{db.kelas.find(k => k.id === transferSantri.kelasId)?.nama}</strong>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Pilih Kelas Tujuan Baru</label>
                <select
                  value={targetKelasId}
                  onChange={(e) => setTargetKelasId(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
                >
                  {db.kelas.map(k => (
                    <option key={k.id} value={k.id}>{k.nama} (Tahun: {k.tahunAjaran})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Keterangan / Alasan Pemindahan</label>
                <input
                  type="text"
                  value={transferNote}
                  onChange={(e) => setTransferNote(e.target.value)}
                  placeholder="Contoh: Kenaikan kelas semester genap setelah tuntas Shufhah 1-15"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="text-[11px] text-slate-500 bg-amber-50 p-2.5 rounded-lg border border-amber-200/60">
                Sistem akan menyimpan catatan riwayat perpindahan kelas sebelumnya secara permanen.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setTransferSantri(null)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleProcessTransfer}
                  className="px-4 py-1.5 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Proses Pemindahan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Detail Santri & Riwayat Kelas & Kartu Pelajar */}
      {detailSantri && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl my-8 overflow-hidden">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">Profil Lengkap Santri Al-Wasā’il</h3>
                <p className="text-xs text-slate-300">PP Al-Ihsan Jrangoan</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-2.5 py-1 text-xs bg-white/10 hover:bg-white/20 text-white rounded-lg border border-white/20 flex items-center gap-1"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak Biodata</span>
                </button>
                <button
                  onClick={() => setDetailSantri(null)}
                  className="p-1 text-slate-300 hover:text-white rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4 text-xs">
              
              <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div className="w-16 h-16 rounded-xl bg-[#0B1B3D] text-amber-300 flex items-center justify-center font-bold text-2xl shrink-0">
                  {detailSantri.nama.charAt(0)}
                </div>
                <div className="space-y-1">
                  <h4 className="text-base font-bold text-slate-900">{detailSantri.nama}</h4>
                  <div className="text-slate-500 font-mono-num">
                    NIS: <strong>{detailSantri.nis}</strong> · {detailSantri.gender === 'L' ? 'Santri Putra' : 'Santri Putri'}
                  </div>
                  <div className="text-slate-600">
                    Kelas: <strong>{db.kelas.find(k => k.id === detailSantri.kelasId)?.nama}</strong> · Tahun Masuk: {detailSantri.tahunMasuk}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-slate-700">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Tempat, Tanggal Lahir</span>
                  <span className="font-medium">{detailSantri.tempatLahir}, {detailSantri.tanggalLahir}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Lembaga Asal</span>
                  <span className="font-medium">{detailSantri.lembagaAsal}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Nama Orang Tua</span>
                  <span className="font-medium">{detailSantri.namaAyah} / {detailSantri.namaIbu}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">No. HP Wali</span>
                  <span className="font-mono-num font-medium text-emerald-700">{detailSantri.noHpWali}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Alamat Lengkap</span>
                  <span className="font-medium">{detailSantri.alamat}</span>
                </div>
                {detailSantri.catatanKhusus && (
                  <div className="col-span-2 p-2.5 bg-amber-50 rounded-lg border border-amber-200/60">
                    <span className="text-amber-900 block text-[10px] uppercase font-bold">Catatan Khusus</span>
                    <span className="text-amber-950">{detailSantri.catatanKhusus}</span>
                  </div>
                )}
              </div>

              {/* Riwayat Pemindahan Kelas */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <h5 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                  <ArrowRightLeft className="w-3.5 h-3.5 text-blue-600" />
                  <span>Riwayat Perjalanan Kelas Santri</span>
                </h5>

                <div className="space-y-1.5">
                  {detailSantri.riwayatKelas && detailSantri.riwayatKelas.length > 0 ? (
                    detailSantri.riwayatKelas.map((rw, i) => (
                      <div key={i} className="p-2 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between">
                        <div>
                          <span className="font-bold text-slate-800">{rw.kelasNama}</span>
                          <span className="text-[10px] text-slate-400 ml-2 font-mono-num">{rw.tahunAjaran}</span>
                          {rw.keterangan && <p className="text-[11px] text-slate-500 mt-0.5">{rw.keterangan}</p>}
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono-num">{rw.tanggalPindah}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-slate-400 text-[11px]">Belum ada riwayat perpindahan kelas.</div>
                  )}
                </div>
              </div>

            </div>

            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setDetailSantri(null)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg font-medium"
              >
                Tutup
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
