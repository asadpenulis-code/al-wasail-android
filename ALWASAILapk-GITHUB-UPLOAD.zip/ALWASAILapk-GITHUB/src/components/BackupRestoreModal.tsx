import React, { useState, useRef } from 'react';
import { DatabaseState } from '../types';
import { downloadDatabaseBackup, restoreDatabaseFromFile, resetDatabaseToDefault } from '../services/db';
import { X, Download, Upload, RefreshCw, Database, CheckCircle2, AlertTriangle } from 'lucide-react';

interface BackupRestoreModalProps {
  db: DatabaseState;
  onClose: () => void;
  onRefresh: () => void;
}

export const BackupRestoreModal: React.FC<BackupRestoreModalProps> = ({
  db,
  onClose,
  onRefresh
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  const handleDownload = () => {
    downloadDatabaseBackup();
    setStatusMessage({ type: 'success', text: 'Berkas cadangan JSON berhasil diunduh ke perangkat Anda.' });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsRestoring(true);
    setStatusMessage(null);
    try {
      await restoreDatabaseFromFile(file);
      setStatusMessage({ type: 'success', text: 'Database berhasil dipulihkan dari berkas backup!' });
      onRefresh();
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err?.message || 'Gagal memulihkan database. Pastikan berkas berformat JSON yang sah.' });
    } finally {
      setIsRestoring(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleReset = () => {
    if (window.confirm("Apakah Anda yakin ingin mengatur ulang database ke data default bawaan? Semua perubahan baru akan digantikan.")) {
      resetDatabaseToDefault();
      setStatusMessage({ type: 'success', text: 'Database telah diatur ulang ke data awal Al-Wasā\'il.' });
      onRefresh();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold">Pencadangan & Pemulihan Database</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-xs text-slate-700">
          
          {/* Current Status */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <div className="font-semibold text-slate-900 text-sm flex items-center justify-between">
              <span>Status Database Aktif</span>
              <span className="text-[11px] font-mono-num text-slate-500">v{db.version}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600">
              <div>Total Santri: <span className="font-bold text-slate-800 font-mono-num">{db.santri.length}</span></div>
              <div>Total Guru: <span className="font-bold text-slate-800 font-mono-num">{db.guru.length}</span></div>
              <div>Total Kelas: <span className="font-bold text-slate-800 font-mono-num">{db.kelas.length}</span></div>
              <div>Sesi Absensi: <span className="font-bold text-slate-800 font-mono-num">{db.absensi.length}</span></div>
              <div>Data Penilaian: <span className="font-bold text-slate-800 font-mono-num">{db.penilaian.length}</span></div>
              <div>Peserta Tashih: <span className="font-bold text-slate-800 font-mono-num">{db.tashih.length}</span></div>
            </div>
            <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-200/60 font-mono-num">
              Terakhir diperbarui: {new Date(db.lastUpdated).toLocaleString('id-ID')}
            </div>
          </div>

          {/* Feedback message */}
          {statusMessage && (
            <div className={`p-3 rounded-xl flex items-start gap-2 ${
              statusMessage.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
            }`}>
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* Actions */}
          <div className="space-y-3">
            {/* Download Backup */}
            <div className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors flex items-center justify-between gap-3 bg-white">
              <div>
                <div className="font-bold text-slate-900">Cadangkan Database (Backup JSON)</div>
                <div className="text-[11px] text-slate-500">Unduh seluruh data lembaga ke dalam satu berkas JSON aman.</div>
              </div>
              <button
                onClick={handleDownload}
                className="shrink-0 flex items-center gap-1.5 px-3 py-2 bg-[#0B1B3D] hover:bg-[#152e61] text-white rounded-lg font-medium transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-amber-300" />
                <span>Unduh</span>
              </button>
            </div>

            {/* Restore from File */}
            <div className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors flex items-center justify-between gap-3 bg-white">
              <div>
                <div className="font-bold text-slate-900">Pulihkan Database (Restore JSON)</div>
                <div className="text-[11px] text-slate-500">Unggah berkas backup untuk memulihkan seluruh data.</div>
              </div>
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".json,application/json"
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isRestoring}
                  className="shrink-0 flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-medium transition-colors disabled:opacity-50"
                >
                  <Upload className="w-3.5 h-3.5 text-blue-300" />
                  <span>{isRestoring ? 'Memproses...' : 'Pilih File'}</span>
                </button>
              </div>
            </div>

            {/* Reset to Factory Default */}
            <div className="p-3.5 rounded-xl border border-rose-200 bg-rose-50/40 flex items-center justify-between gap-3">
              <div>
                <div className="font-bold text-rose-950">Atur Ulang ke Default</div>
                <div className="text-[11px] text-rose-700">Kembalikan data ke contoh awal PP Al-Ihsan Jrangoan.</div>
              </div>
              <button
                onClick={handleReset}
                className="shrink-0 flex items-center gap-1.5 px-3 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-medium transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-slate-600 hover:text-slate-900 font-medium rounded-lg text-xs"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
