import React, { useState } from 'react';
import { DatabaseState, PesertaTashih, UserAccount } from '../types';
import { exportToCSV } from '../services/db';
import { FileCheck2, Plus, Search, Printer, Download, Award, CheckCircle2, XCircle, Clock, Edit2, Trash2, X, Sparkles } from 'lucide-react';

interface TashihModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdateTashih: (tashihList: PesertaTashih[]) => void;
}

export const TashihModule: React.FC<TashihModuleProps> = ({
  db,
  currentUser,
  onUpdateTashih
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Lulus' | 'Tidak Lulus' | 'Belum Ujian'>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPeserta, setEditingPeserta] = useState<PesertaTashih | null>(null);
  const [selectedSyahadah, setSelectedSyahadah] = useState<PesertaTashih | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<PesertaTashih>>({
    nomorPeserta: '',
    nama: '',
    lembagaAsal: 'PP Al-Ihsan Jrangoan - Pusat',
    kelasAsal: 'Takhassus C',
    gelombangUjian: 'Gelombang II (November 2026)',
    ruangUjian: 'Aula Utama Ma\'had Al-Ihsan',
    tanggalUjian: new Date().toISOString().split('T')[0],
    penguji: 'Ust. Hasan Basri, S.Hum',
    nilaiNahwu: 80,
    nilaiSharraf: 80,
    nilaiMembacaKitab: 80,
    catatanPenguji: '',
    statusLulus: 'Belum Ujian'
  });

  const canEdit = currentUser.role === 'admin' || currentUser.role === 'guru' || currentUser.role === 'kepala';
  const kkm = db.pengaturan.kkmTashih || 70;

  const filteredTashih = db.tashih.filter(t => {
    const matchSearch = t.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        t.nomorPeserta.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        t.lembagaAsal.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || t.statusLulus === statusFilter;
    return matchSearch && matchStatus;
  });

  const handleOpenAdd = () => {
    const nextNomor = `TSH-${new Date().getFullYear()}-${String(db.tashih.length + 1).padStart(3, '0')}`;
    setEditingPeserta(null);
    setFormData({
      nomorPeserta: nextNomor,
      nama: '',
      lembagaAsal: 'PP Al-Ihsan Jrangoan - Pusat',
      kelasAsal: 'Takhassus C',
      gelombangUjian: 'Gelombang II (November 2026)',
      ruangUjian: 'Aula Utama Ma\'had Al-Ihsan',
      tanggalUjian: new Date().toISOString().split('T')[0],
      penguji: db.guru[3]?.nama || 'Ust. Hasan Basri, S.Hum',
      nilaiNahwu: 75,
      nilaiSharraf: 75,
      nilaiMembacaKitab: 75,
      catatanPenguji: '',
      statusLulus: 'Belum Ujian'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (t: PesertaTashih) => {
    setEditingPeserta(t);
    setFormData(t);
    setIsModalOpen(true);
  };

  const calculateStatus = (nahwu: number, sharraf: number, baca: number): { status: 'Lulus' | 'Tidak Lulus'; predikat?: 'Mumtaz' | 'Jayyid Jiddan' | 'Jayyid' | 'Rasib' } => {
    const avg = (nahwu + sharraf + baca) / 3;
    if (nahwu < kkm || sharraf < kkm || baca < kkm || avg < kkm) {
      return { status: 'Tidak Lulus', predikat: 'Rasib' };
    }
    if (avg >= 90) return { status: 'Lulus', predikat: 'Mumtaz' };
    if (avg >= 80) return { status: 'Lulus', predikat: 'Jayyid Jiddan' };
    return { status: 'Lulus', predikat: 'Jayyid' };
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama || !formData.nomorPeserta) return;

    let computedStatus = formData.statusLulus || 'Belum Ujian';
    let computedPredikat = formData.predikat;
    let computedSyahadah = formData.nomorSyahadah;

    if (computedStatus !== 'Belum Ujian') {
      const result = calculateStatus(Number(formData.nilaiNahwu || 0), Number(formData.nilaiSharraf || 0), Number(formData.nilaiMembacaKitab || 0));
      computedStatus = result.status;
      computedPredikat = result.predikat;

      if (computedStatus === 'Lulus' && !computedSyahadah) {
        computedSyahadah = `SY-ALW/${new Date().getMonth() + 1}/${new Date().getFullYear()}/${String(db.tashih.length + 100).padStart(3, '0')}`;
      }
    }

    const newPeserta: PesertaTashih = {
      id: editingPeserta?.id || `tsh-${Date.now()}`,
      nomorPeserta: formData.nomorPeserta || '',
      nama: formData.nama || '',
      lembagaAsal: formData.lembagaAsal || '',
      kelasAsal: formData.kelasAsal || '',
      gelombangUjian: formData.gelombangUjian || '',
      ruangUjian: formData.ruangUjian || '',
      tanggalUjian: formData.tanggalUjian || '',
      penguji: formData.penguji || '',
      nilaiNahwu: Number(formData.nilaiNahwu || 0),
      nilaiSharraf: Number(formData.nilaiSharraf || 0),
      nilaiMembacaKitab: Number(formData.nilaiMembacaKitab || 0),
      catatanPenguji: formData.catatanPenguji || '',
      statusLulus: computedStatus as any,
      predikat: computedPredikat,
      nomorSyahadah: computedSyahadah
    };

    if (editingPeserta) {
      onUpdateTashih(db.tashih.map(t => t.id === editingPeserta.id ? newPeserta : t));
    } else {
      onUpdateTashih([...db.tashih, newPeserta]);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (id: string, nama: string) => {
    if (window.confirm(`Hapus data peserta tashih "${nama}"?`)) {
      onUpdateTashih(db.tashih.filter(t => t.id !== id));
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Nomor Peserta', 'Nama Peserta', 'Lembaga Asal', 'Kelas Asal', 'Gelombang',
      'Penguji', 'Nilai Nahwu', 'Nilai Sharraf', 'Nilai Baca Kitab', 'Rata-rata',
      'Status Kelulusan', 'Predikat', 'Nomor Syahadah'
    ];
    const rows = filteredTashih.map(t => {
      const avg = Math.round((t.nilaiNahwu + t.nilaiSharraf + t.nilaiMembacaKitab) / 3);
      return [
        t.nomorPeserta,
        t.nama,
        t.lembagaAsal,
        t.kelasAsal,
        t.gelombangUjian,
        t.penguji,
        t.nilaiNahwu,
        t.nilaiSharraf,
        t.nilaiMembacaKitab,
        avg,
        t.statusLulus,
        t.predikat || '-',
        t.nomorSyahadah || '-'
      ];
    });
    const dateStr = new Date().toISOString().split('T')[0];
    exportToCSV(`rekap_tashih_alwasail_${dateStr}`, headers, rows);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <FileCheck2 className="w-4 h-4" />
            <span>Majelis Tashih & Pengujian Kitab Kuning</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Administrasi Ujian Tashih Al-Wasā’il
          </h2>
          <p className="text-xs text-slate-500">
            Pengujian 3 Bidang: Nahwu, Sharraf & I'lal, Lafadz Makna & Membaca Kitab Gundul. Standar KKM: {kkm}.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Ekspor Rekap (CSV)</span>
          </button>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Printer className="w-4 h-4 text-slate-600" />
            <span>Cetak Peserta</span>
          </button>

          {canEdit && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs"
            >
              <Plus className="w-4 h-4 text-amber-300" />
              <span>Daftarkan Peserta Tashih</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama peserta, nomor, cabang..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-slate-500 font-medium">Status Kelulusan:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg font-semibold"
          >
            <option value="all">Semua Status</option>
            <option value="Lulus">Lulus (Syahadah)</option>
            <option value="Tidak Lulus">Tidak Lulus (Remidi)</option>
            <option value="Belum Ujian">Belum Ujian / Terdaftar</option>
          </select>
        </div>
      </div>

      {/* Tashih List Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-3">No. Peserta</th>
                <th className="py-3 px-3">Nama & Asal Cabang</th>
                <th className="py-3 px-3">Penguji & Ruang</th>
                <th className="py-3 px-3 text-center">Nahwu</th>
                <th className="py-3 px-3 text-center">Sharraf & I'lal</th>
                <th className="py-3 px-3 text-center">Baca Kitab</th>
                <th className="py-3 px-3 text-center">Rata-rata</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTashih.map(t => {
                const avg = t.statusLulus !== 'Belum Ujian' 
                  ? Math.round((t.nilaiNahwu + t.nilaiSharraf + t.nilaiMembacaKitab) / 3) 
                  : '-';

                return (
                  <tr key={t.id} className="hover:bg-slate-50/80 transition-colors">
                    
                    <td className="py-3 px-3 font-mono-num font-bold text-slate-800">
                      {t.nomorPeserta}
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-bold text-slate-900">{t.nama}</div>
                      <div className="text-[11px] text-slate-500">{t.lembagaAsal}</div>
                    </td>

                    <td className="py-3 px-3 text-slate-600 text-[11px]">
                      <div className="font-medium text-slate-800">{t.penguji}</div>
                      <div className="text-slate-400">{t.ruangUjian} · {t.tanggalUjian}</div>
                    </td>

                    <td className="py-3 px-3 text-center font-mono-num font-bold text-slate-700">
                      {t.statusLulus === 'Belum Ujian' ? '-' : t.nilaiNahwu}
                    </td>

                    <td className="py-3 px-3 text-center font-mono-num font-bold text-slate-700">
                      {t.statusLulus === 'Belum Ujian' ? '-' : t.nilaiSharraf}
                    </td>

                    <td className="py-3 px-3 text-center font-mono-num font-bold text-slate-700">
                      {t.statusLulus === 'Belum Ujian' ? '-' : t.nilaiMembacaKitab}
                    </td>

                    <td className="py-3 px-3 text-center font-mono-num font-extrabold text-[#0B1B3D]">
                      {avg}
                    </td>

                    <td className="py-3 px-3 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        t.statusLulus === 'Lulus'
                          ? 'bg-emerald-100 text-emerald-800'
                          : t.statusLulus === 'Tidak Lulus'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {t.statusLulus} {t.predikat ? `(${t.predikat})` : ''}
                      </span>
                    </td>

                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        {t.statusLulus === 'Lulus' && (
                          <button
                            onClick={() => setSelectedSyahadah(t)}
                            title="Cetak Syahadah / Ijazah Kelulusan Resmi"
                            className="p-1.5 text-amber-700 hover:text-amber-800 hover:bg-amber-50 rounded-lg transition-colors"
                          >
                            <Award className="w-4 h-4" />
                          </button>
                        )}

                        {canEdit && (
                          <>
                            <button
                              onClick={() => handleOpenEdit(t)}
                              title="Input / Edit Hasil Ujian"
                              className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDelete(t.id, t.nama)}
                              title="Hapus Peserta"
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Tashih */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl my-8 overflow-hidden">
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingPeserta ? 'Input Nilai / Edit Peserta Tashih' : 'Pendaftaran Peserta Ujian Tashih Al-Wasā’il'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nomor Peserta Tashih *</label>
                  <input
                    type="text"
                    required
                    value={formData.nomorPeserta || ''}
                    onChange={(e) => setFormData({ ...formData, nomorPeserta: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num font-bold"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Lengkap Peserta *</label>
                  <input
                    type="text"
                    required
                    value={formData.nama || ''}
                    onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Lembaga / Cabang Asal</label>
                  <input
                    type="text"
                    value={formData.lembagaAsal || ''}
                    onChange={(e) => setFormData({ ...formData, lembagaAsal: e.target.value })}
                    placeholder="Contoh: PP Al-Ihsan Jrangoan / Cabang Bangkalan"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Kelas Asal</label>
                  <input
                    type="text"
                    value={formData.kelasAsal || ''}
                    onChange={(e) => setFormData({ ...formData, kelasAsal: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Gelombang / Ruang Ujian</label>
                  <input
                    type="text"
                    value={formData.gelombangUjian || ''}
                    onChange={(e) => setFormData({ ...formData, gelombangUjian: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Penguji (Musahhih)</label>
                  <input
                    type="text"
                    value={formData.penguji || ''}
                    onChange={(e) => setFormData({ ...formData, penguji: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              {/* 3 Bidang Tashih Input */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="font-bold text-slate-900 text-xs">
                  Input Skor Ujian Tashih 3 Bidang (Standar Kelulusan KKM: {kkm}):
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-600 font-medium mb-1">1. Nahwu (0-100)</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={formData.nilaiNahwu || 0}
                      onChange={(e) => setFormData({ ...formData, nilaiNahwu: Number(e.target.value) })}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono-num font-bold text-center"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-medium mb-1">2. Sharraf & I'lal</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={formData.nilaiSharraf || 0}
                      onChange={(e) => setFormData({ ...formData, nilaiSharraf: Number(e.target.value) })}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono-num font-bold text-center"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-medium mb-1">3. Baca Kitab Gundul</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={formData.nilaiMembacaKitab || 0}
                      onChange={(e) => setFormData({ ...formData, nilaiMembacaKitab: Number(e.target.value) })}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg font-mono-num font-bold text-center"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-600 font-medium mb-1">Status Pelaksanaan Ujian</label>
                  <select
                    value={formData.statusLulus || 'Belum Ujian'}
                    onChange={(e) => setFormData({ ...formData, statusLulus: e.target.value as any })}
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg font-semibold"
                  >
                    <option value="Belum Ujian">Belum Ujian (Hanya Terdaftar)</option>
                    <option value="Lulus">Sudah Ujian (Hitung Otomatis Berdasarkan Skor)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Catatan Khusus Penguji (Musahhih)</label>
                <textarea
                  rows={2}
                  value={formData.catatanPenguji || ''}
                  onChange={(e) => setFormData({ ...formData, catatanPenguji: e.target.value })}
                  placeholder="Catatan kelancaran, adab membaca kitab, atau materi remidial..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Simpan Data Tashih
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Syahadah Tashih Official Certificate View (Ijazah Resmi Al-Wasā'il) */}
      {selectedSyahadah && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl my-8 overflow-hidden">
            
            {/* Top Toolbar */}
            <div className="no-print px-6 py-3.5 bg-[#0B1B3D] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-300" />
                <span className="font-bold text-sm">Pratinjau Syahadah / Ijazah Tashih Al-Wasā’il</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-1.5 bg-amber-400 hover:bg-amber-300 text-[#0B1B3D] font-bold rounded-lg text-xs flex items-center gap-1.5 transition-colors shadow-2xs"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak Syahadah (PDF)</span>
                </button>
                <button
                  onClick={() => setSelectedSyahadah(null)}
                  className="p-1 text-slate-300 hover:text-white rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Syahadah Certificate Sheet */}
            <div className="p-10 bg-[#FFFDF9] text-slate-900 border-8 border-double border-amber-900/30 m-4 rounded-xl relative overflow-hidden">
              
              {/* Subtle watermark background */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
                <span className="font-arabic text-9xl text-amber-900">الوسائل</span>
              </div>

              {/* Islamic Calligraphy Header */}
              <div className="text-center space-y-1 relative z-10">
                <div className="font-arabic text-2xl font-bold text-amber-900">
                  بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                </div>
                <div className="font-arabic text-3xl font-extrabold text-[#0B1B3D] tracking-wider pt-2">
                  شَهَادَةُ التَّصْحِيْحِ لِقِرَاءَةِ الْكُتُبِ
                </div>
                <div className="font-arabic text-base text-amber-800 font-semibold">
                  {db.pengaturan.sloganArab}
                </div>

                <div className="pt-2">
                  <h2 className="text-lg font-black tracking-widest uppercase text-slate-900">
                    {db.pengaturan.namaLembaga}
                  </h2>
                  <p className="text-xs font-semibold text-slate-700">
                    {db.pengaturan.naungan}
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono-num">
                    Nomor Syahadah: {selectedSyahadah.nomorSyahadah || 'SY-ALW/2026/089'}
                  </p>
                </div>
              </div>

              <div className="w-32 h-0.5 bg-gradient-to-r from-transparent via-amber-600 to-transparent mx-auto my-4"></div>

              {/* Certificate Statement Body */}
              <div className="max-w-2xl mx-auto text-center space-y-4 text-xs leading-relaxed relative z-10">
                <p className="text-slate-700 italic">
                  Dewan Musahhih Lembaga Pendidikan Al-Wasā'il menerangkan bahwa santri di bawah ini:
                </p>

                <div className="py-2">
                  <div className="text-2xl font-black text-[#0B1B3D] tracking-wide uppercase">
                    {selectedSyahadah.nama}
                  </div>
                  <div className="text-xs text-slate-600 font-mono-num mt-1">
                    No. Registrasi: <strong>{selectedSyahadah.nomorPeserta}</strong> · Asal Lembaga: <strong>{selectedSyahadah.lembagaAsal}</strong>
                  </div>
                </div>

                <p className="text-slate-800">
                  Telah mengikuti dan dinyatakan <strong className="text-emerald-800 uppercase text-sm">LULUS</strong> dalam <br />
                  <strong>UJIAN TASHIH AL-WASĀ’IL TINGKAT NASIONAL</strong><br />
                  meliputi bidang pengujian Nahwu, Sharraf & 19 Kaidah I‘lal, serta Kemampuan Membaca Kitab Kuning Gundul <em>(Kitab Yāqūtun Nafīs)</em> dengan predikat:
                </p>

                <div className="inline-block px-6 py-2 bg-amber-100 border border-amber-300 rounded-xl">
                  <span className="font-arabic text-2xl font-bold text-amber-950">
                    {selectedSyahadah.predikat === 'Mumtaz' ? 'مُمْتَاز (MUMTAZ / ISTIMEWA)' : selectedSyahadah.predikat === 'Jayyid Jiddan' ? 'جَيِّدٌ جِدًّا (JAYYID JIDDAN / SANGAT BAIK)' : 'جَيِّد (JAYYID / BAIK)'}
                  </span>
                </div>

                <p className="text-[11px] text-slate-600">
                  Semoga ilmu yang diperoleh menjadi bekal yang berkah dan bermanfaat dalam tafaqquh fiddin bagi umat dan bangsa.
                </p>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-2 text-xs pt-10 text-center relative z-10 max-w-2xl mx-auto">
                <div className="space-y-16">
                  <div>
                    Musahhih Penguji,<br />
                    <strong>Penguji Utama Al-Wasā'il</strong>
                  </div>
                  <div>
                    <strong className="underline underline-offset-4">{selectedSyahadah.penguji}</strong>
                  </div>
                </div>

                <div className="space-y-16">
                  <div>
                    Sampang, {new Date(selectedSyahadah.tanggalUjian).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}<br />
                    <strong>Pengasuh / Kepala Lembaga</strong>
                  </div>
                  <div>
                    <strong className="underline underline-offset-4">{db.pengaturan.namaPimpinan}</strong>
                  </div>
                </div>
              </div>

            </div>

            <div className="no-print px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedSyahadah(null)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-semibold"
              >
                Tutup Pratinjau
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
