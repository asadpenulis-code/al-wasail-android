import React, { useState } from 'react';
import { DatabaseState, Pengumuman, UserAccount } from '../types';
import { Bell, Plus, Calendar, Tag, Trash2, Edit2, X, AlertCircle } from 'lucide-react';

interface PengumumanModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdatePengumuman: (list: Pengumuman[]) => void;
}

export const PengumumanModule: React.FC<PengumumanModuleProps> = ({
  db,
  currentUser,
  onUpdatePengumuman
}) => {
  const [selectedTarget, setSelectedTarget] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPengumuman, setEditingPengumuman] = useState<Pengumuman | null>(null);

  const [formData, setFormData] = useState<Partial<Pengumuman>>({
    judul: '',
    kategori: 'Kegiatan',
    tanggal: new Date().toISOString().split('T')[0],
    isi: '',
    target: 'Semua',
    penulis: currentUser.name,
    isPenting: false
  });

  const canEdit = currentUser.role === 'admin' || currentUser.role === 'kepala';

  const filtered = db.pengumuman.filter(p => {
    if (selectedTarget === 'all') return true;
    return p.target === selectedTarget || p.target === 'Semua';
  });

  const handleOpenAdd = () => {
    setEditingPengumuman(null);
    setFormData({
      judul: '',
      kategori: 'Kegiatan',
      tanggal: new Date().toISOString().split('T')[0],
      isi: '',
      target: 'Semua',
      penulis: currentUser.name,
      isPenting: false
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Pengumuman) => {
    setEditingPengumuman(p);
    setFormData(p);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.judul || !formData.isi) return;

    const newP: Pengumuman = {
      id: editingPengumuman?.id || `pgm-${Date.now()}`,
      judul: formData.judul || '',
      kategori: formData.kategori || 'Kegiatan',
      tanggal: formData.tanggal || new Date().toISOString().split('T')[0],
      isi: formData.isi || '',
      target: formData.target || 'Semua',
      penulis: formData.penulis || currentUser.name,
      isPenting: formData.isPenting || false
    };

    if (editingPengumuman) {
      onUpdatePengumuman(db.pengumuman.map(p => p.id === editingPengumuman.id ? newP : p));
    } else {
      onUpdatePengumuman([newP, ...db.pengumuman]);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Hapus pengumuman ini?")) {
      onUpdatePengumuman(db.pengumuman.filter(p => p.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <Bell className="w-4 h-4" />
            <span>Pusat Informasi & Pengumuman</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Agenda Lembaga & Informasi Santri
          </h2>
          <p className="text-xs text-slate-500">
            Jadwal kegiatan, agenda ujian tashih, rapat asatidz, dan pengumuman wali santri.
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs self-start md:self-auto"
          >
            <Plus className="w-4 h-4 text-amber-300" />
            <span>Buat Pengumuman Baru</span>
          </button>
        )}
      </div>

      {/* Target Filter */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-slate-500 font-semibold">Tampilkan untuk:</span>
        {(['all', 'Semua', 'Santri', 'Guru', 'Wali'] as const).map(t => (
          <button
            key={t}
            onClick={() => setSelectedTarget(t)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedTarget === t ? 'bg-[#0B1B3D] text-white shadow-2xs' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {t === 'all' ? 'Semua Target' : t}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="space-y-4">
        {filtered.map(p => (
          <div key={p.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                  {p.kategori}
                </span>
                <span className="text-slate-300">·</span>
                <span className="text-xs text-slate-500 font-mono-num flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  {p.tanggal}
                </span>
                <span className="text-slate-300">·</span>
                <span className="text-xs text-slate-600">Target: <strong>{p.target}</strong></span>
              </div>

              {canEdit && (
                <div className="flex items-center gap-1 self-end sm:self-auto">
                  <button
                    onClick={() => handleOpenEdit(p)}
                    className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(p.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            <h3 className="font-bold text-slate-900 text-base">{p.judul}</h3>
            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">{p.isi}</p>

            <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-100">
              <span>Diterbitkan oleh: <strong>{p.penulis}</strong></span>
              {p.isPenting && (
                <span className="text-rose-700 font-bold flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                  <span>Pemberitahuan Penting</span>
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modal Add / Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg my-8 overflow-hidden">
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingPengumuman ? 'Edit Informasi' : 'Buat Pengumuman Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Judul Pengumuman *</label>
                <input
                  type="text"
                  required
                  value={formData.judul || ''}
                  onChange={(e) => setFormData({ ...formData, judul: e.target.value })}
                  placeholder="Contoh: Jadwal Ujian Tashih Gelombang II"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Kategori</label>
                  <select
                    value={formData.kategori || 'Kegiatan'}
                    onChange={(e) => setFormData({ ...formData, kategori: e.target.value as any })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="Kegiatan">Kegiatan</option>
                    <option value="Jadwal Ujian">Jadwal Ujian</option>
                    <option value="Rapat Guru">Rapat Guru</option>
                    <option value="Pengumuman Santri">Pengumuman Santri</option>
                    <option value="Wali Santri">Wali Santri</option>
                    <option value="Agenda Lembaga">Agenda Lembaga</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Target Sasaran</label>
                  <select
                    value={formData.target || 'Semua'}
                    onChange={(e) => setFormData({ ...formData, target: e.target.value as any })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="Semua">Semua (Umum)</option>
                    <option value="Santri">Khusus Santri</option>
                    <option value="Guru">Khusus Guru / Asatidz</option>
                    <option value="Wali">Khusus Wali Santri</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Isi Pengumuman / Agenda Lengkap *</label>
                <textarea
                  rows={4}
                  required
                  value={formData.isi || ''}
                  onChange={(e) => setFormData({ ...formData, isi: e.target.value })}
                  placeholder="Tuliskan isi informasi dengan jelas..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isPenting"
                  checked={formData.isPenting || false}
                  onChange={(e) => setFormData({ ...formData, isPenting: e.target.checked })}
                  className="w-4 h-4 text-amber-600 rounded"
                />
                <label htmlFor="isPenting" className="text-slate-800 font-medium cursor-pointer">
                  Tandai sebagai Pengumuman Penting (Wajib Dibaca)
                </label>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Terbitkan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
