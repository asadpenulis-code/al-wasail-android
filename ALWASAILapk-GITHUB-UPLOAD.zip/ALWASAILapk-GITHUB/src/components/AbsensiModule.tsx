import React, { useState } from 'react';
import { DatabaseState, AbsensiSesi, UserAccount, StatusKehadiran } from '../types';
import { exportToCSV } from '../services/db';
import { CalendarCheck, Plus, Download, Printer, AlertTriangle, CheckCircle, Clock, Search, Calendar, Check } from 'lucide-react';

interface AbsensiModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdateAbsensi: (absensiList: AbsensiSesi[]) => void;
}

export const AbsensiModule: React.FC<AbsensiModuleProps> = ({
  db,
  currentUser,
  onUpdateAbsensi
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'input' | 'rekap' | 'peringatan'>('input');
  
  // Selection for input
  const [selectedKelasId, setSelectedKelasId] = useState<string>(db.kelas[0]?.id || 'k-1');
  const [selectedTanggal, setSelectedTanggal] = useState<string>(new Date().toISOString().split('T')[0]);
  const [catatanSesi, setCatatanSesi] = useState<string>('');

  // Local attendance state for current input form
  const currentKelas = db.kelas.find(k => k.id === selectedKelasId);
  const santriInClass = db.santri.filter(s => s.kelasId === selectedKelasId && s.status === 'Aktif');

  // Check if session exists for this date and class
  const existingSesi = db.absensi.find(a => a.kelasId === selectedKelasId && a.tanggal === selectedTanggal);

  const [inputAttendance, setInputAttendance] = useState<Record<string, { status: StatusKehadiran; keterangan?: string }>>(() => {
    const initial: Record<string, { status: StatusKehadiran; keterangan?: string }> = {};
    santriInClass.forEach(s => {
      const rec = existingSesi?.records.find(r => r.santriId === s.id);
      initial[s.id] = {
        status: rec?.status || 'Hadir',
        keterangan: rec?.keterangan || ''
      };
    });
    return initial;
  });

  // Re-sync form state when selected class or date changes
  React.useEffect(() => {
    const sesi = db.absensi.find(a => a.kelasId === selectedKelasId && a.tanggal === selectedTanggal);
    const updated: Record<string, { status: StatusKehadiran; keterangan?: string }> = {};
    const students = db.santri.filter(s => s.kelasId === selectedKelasId && s.status === 'Aktif');
    students.forEach(s => {
      const rec = sesi?.records.find(r => r.santriId === s.id);
      updated[s.id] = {
        status: rec?.status || 'Hadir',
        keterangan: rec?.keterangan || ''
      };
    });
    setInputAttendance(updated);
    setCatatanSesi(sesi?.catatan || '');
  }, [selectedKelasId, selectedTanggal, db.absensi]);

  const canInput = currentUser.role === 'admin' || currentUser.role === 'guru';

  // Bulk set all to "Hadir"
  const handleSetAllHadir = () => {
    const updated = { ...inputAttendance };
    santriInClass.forEach(s => {
      updated[s.id] = { status: 'Hadir', keterangan: '' };
    });
    setInputAttendance(updated);
  };

  // Toggle single status
  const handleStatusChange = (santriId: string, status: StatusKehadiran) => {
    setInputAttendance(prev => ({
      ...prev,
      [santriId]: {
        ...prev[santriId],
        status
      }
    }));
  };

  // Save Attendance Session
  const handleSaveAbsensi = () => {
    const records = santriInClass.map(s => ({
      santriId: s.id,
      status: inputAttendance[s.id]?.status || 'Hadir',
      keterangan: inputAttendance[s.id]?.keterangan || ''
    }));

    const guruName = currentUser.role === 'guru' 
      ? currentUser.name 
      : (db.guru.find(g => g.id === currentKelas?.waliKelasId)?.nama || 'Ust. Pengampu Al-Wasā\'il');

    const newSesi: AbsensiSesi = {
      id: existingSesi?.id || `abs-${Date.now()}`,
      tanggal: selectedTanggal,
      kelasId: selectedKelasId,
      guruId: currentUser.relatedId || currentKelas?.waliKelasId || 'g-1',
      guruNama: guruName,
      records,
      catatan: catatanSesi,
      createdAt: new Date().toISOString()
    };

    if (existingSesi) {
      onUpdateAbsensi(db.absensi.map(a => a.id === existingSesi.id ? newSesi : a));
    } else {
      onUpdateAbsensi([...db.absensi, newSesi]);
    }

    alert("Data absensi santri berhasil disimpan ke database!");
  };

  // Calculate Rekapitulasi Statistics per Santri
  const rekapSantri = db.santri.filter(s => s.status === 'Aktif').map(s => {
    const kls = db.kelas.find(k => k.id === s.kelasId);
    let hadir = 0;
    let sakit = 0;
    let izin = 0;
    let alfa = 0;
    let total = 0;

    db.absensi.forEach(sesi => {
      const rec = sesi.records.find(r => r.santriId === s.id);
      if (rec) {
        total++;
        if (rec.status === 'Hadir') hadir++;
        else if (rec.status === 'Sakit') sakit++;
        else if (rec.status === 'Izin') izin++;
        else if (rec.status === 'Alfa') alfa++;
      }
    });

    const persen = total > 0 ? Math.round((hadir / total) * 100) : 100;

    return {
      santri: s,
      kelasNama: kls?.nama || '-',
      hadir,
      sakit,
      izin,
      alfa,
      total,
      persen
    };
  });

  // Santri Sering Tidak Masuk (Alfa >= 2 or Alfa >= 3)
  const santriPeringatan = rekapSantri.filter(r => r.alfa >= 2);

  // Export Rekap to CSV
  const handleExportRekapCSV = () => {
    const headers = ['NIS', 'Nama Santri', 'Kelas', 'Total Sesi', 'Hadir', 'Sakit', 'Izin', 'Alfa', 'Persentase Kehadiran'];
    const rows = rekapSantri.map(r => [
      r.santri.nis,
      r.santri.nama,
      r.kelasNama,
      r.total,
      r.hadir,
      r.sakit,
      r.izin,
      r.alfa,
      `${r.persen}%`
    ]);
    const dateStr = new Date().toISOString().split('T')[0];
    exportToCSV(`rekap_absensi_alwasail_${dateStr}`, headers, rows);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <CalendarCheck className="w-4 h-4" />
            <span>Sistem Presensi Santri Al-Wasā’il</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Absensi Harian & Rekapitulasi Kehadiran
          </h2>
          <p className="text-xs text-slate-500">
            Pencatatan kehadiran harian santri per rombel kelas metode membaca kitab kuning.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportRekapCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Ekspor Rekap (CSV)</span>
          </button>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-xs transition-colors"
          >
            <Printer className="w-4 h-4 text-slate-600" />
            <span>Cetak Dokumen</span>
          </button>
        </div>
      </div>

      {/* Segmented Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 text-xs font-medium">
        <button
          onClick={() => setActiveSubTab('input')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeSubTab === 'input' ? 'bg-[#0B1B3D] text-white shadow-xs font-bold' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Form Input Absensi Harian
        </button>
        <button
          onClick={() => setActiveSubTab('rekap')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeSubTab === 'rekap' ? 'bg-[#0B1B3D] text-white shadow-xs font-bold' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Rekapitulasi Kehadiran Santri ({rekapSantri.length})
        </button>
        <button
          onClick={() => setActiveSubTab('peringatan')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl transition-all ${
            activeSubTab === 'peringatan' ? 'bg-rose-600 text-white shadow-xs font-bold' : 'text-rose-700 hover:bg-rose-50'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Peringatan Sering Tidak Masuk ({santriPeringatan.length})</span>
        </button>
      </div>

      {/* Subtab 1: Input Absensi Harian */}
      {activeSubTab === 'input' && (
        <div className="space-y-4">
          
          {/* Controls Bar: Pilih Kelas & Tanggal */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              <div>
                <label className="block text-slate-500 font-semibold mb-1 text-[11px]">Pilih Rombel Kelas</label>
                <select
                  value={selectedKelasId}
                  onChange={(e) => setSelectedKelasId(e.target.value)}
                  className="py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-800"
                >
                  {db.kelas.map(k => (
                    <option key={k.id} value={k.id}>{k.nama}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1 text-[11px]">Tanggal Presensi</label>
                <input
                  type="date"
                  value={selectedTanggal}
                  onChange={(e) => setSelectedTanggal(e.target.value)}
                  className="py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg font-mono-num text-slate-800"
                />
              </div>

              {existingSesi && (
                <div className="self-end pb-1.5">
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-md font-semibold text-[11px]">
                    ✓ Presensi Tanggal Ini Sudah Tersimpan
                  </span>
                </div>
              )}
            </div>

            {canInput && (
              <div className="flex items-center gap-2 self-end sm:self-auto">
                <button
                  type="button"
                  onClick={handleSetAllHadir}
                  className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg font-semibold transition-colors"
                >
                  Set Semua Hadir
                </button>
                <button
                  type="button"
                  onClick={handleSaveAbsensi}
                  className="px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold shadow-2xs"
                >
                  Simpan Presensi
                </button>
              </div>
            )}
          </div>

          {/* Table List of Santri for Attendance Input */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-3">No</th>
                    <th className="py-3 px-3">Nama Santri</th>
                    <th className="py-3 px-3">NIS</th>
                    <th className="py-3 px-3 text-center">Status Kehadiran</th>
                    <th className="py-3 px-3">Keterangan Tambahan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {santriInClass.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-10 text-center text-slate-400">
                        Tidak ada santri aktif di kelas ini.
                      </td>
                    </tr>
                  ) : (
                    santriInClass.map((s, idx) => {
                      const currentStatus = inputAttendance[s.id]?.status || 'Hadir';
                      return (
                        <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-3 font-mono-num text-slate-400">{idx + 1}</td>
                          <td className="py-3 px-3 font-bold text-slate-900">{s.nama}</td>
                          <td className="py-3 px-3 font-mono-num text-slate-600">{s.nis}</td>
                          
                          {/* Attendance Status Buttons */}
                          <td className="py-3 px-3 text-center">
                            <div className="inline-flex p-1 bg-slate-100 rounded-lg gap-1">
                              {(['Hadir', 'Sakit', 'Izin', 'Alfa'] as StatusKehadiran[]).map((st) => {
                                const isSelected = currentStatus === st;
                                const colors: Record<StatusKehadiran, string> = {
                                  Hadir: 'bg-emerald-600 text-white shadow-xs',
                                  Sakit: 'bg-blue-600 text-white shadow-xs',
                                  Izin: 'bg-amber-600 text-white shadow-xs',
                                  Alfa: 'bg-rose-600 text-white shadow-xs'
                                };
                                return (
                                  <button
                                    key={st}
                                    type="button"
                                    disabled={!canInput}
                                    onClick={() => handleStatusChange(s.id, st)}
                                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                                      isSelected
                                        ? colors[st]
                                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
                                    }`}
                                  >
                                    {st === 'Hadir' ? 'H (Hadir)' : st === 'Sakit' ? 'S (Sakit)' : st === 'Izin' ? 'I (Izin)' : 'A (Alfa)'}
                                  </button>
                                );
                              })}
                            </div>
                          </td>

                          {/* Keterangan input */}
                          <td className="py-3 px-3">
                            <input
                              type="text"
                              disabled={!canInput}
                              placeholder={currentStatus === 'Hadir' ? 'Nihil' : 'Alasan / Surat dokter...'}
                              value={inputAttendance[s.id]?.keterangan || ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                setInputAttendance(prev => ({
                                  ...prev,
                                  [s.id]: {
                                    ...prev[s.id],
                                    keterangan: val
                                  }
                                }));
                              }}
                              className="w-full p-1.5 bg-slate-50 border border-slate-200 rounded-md text-xs focus:bg-white"
                            />
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Catatan Sesi Mengajar */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-1 text-xs">
              <label className="block text-slate-700 font-semibold">Catatan Sesi / Rangkuman Kehadiran Kelas</label>
              <input
                type="text"
                disabled={!canInput}
                placeholder="Contoh: Seluruh santri hadir tepat waktu, 1 santri izin ziarah keluarga."
                value={catatanSesi}
                onChange={(e) => setCatatanSesi(e.target.value)}
                className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>
          </div>

        </div>
      )}

      {/* Subtab 2: Rekapitulasi Kehadiran Santri */}
      {activeSubTab === 'rekap' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-3">Santri</th>
                  <th className="py-3 px-3">Kelas</th>
                  <th className="py-3 px-3 text-center">Total Sesi</th>
                  <th className="py-3 px-3 text-center">Hadir (H)</th>
                  <th className="py-3 px-3 text-center">Sakit (S)</th>
                  <th className="py-3 px-3 text-center">Izin (I)</th>
                  <th className="py-3 px-3 text-center">Alfa (A)</th>
                  <th className="py-3 px-3 text-center">Persentase</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rekapSantri.map(r => (
                  <tr key={r.santri.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-bold text-slate-900">
                      {r.santri.nama}
                      <span className="block text-[10px] text-slate-400 font-mono-num">NIS: {r.santri.nis}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-700 font-medium">{r.kelasNama}</td>
                    <td className="py-3 px-3 text-center font-mono-num font-semibold text-slate-700">{r.total}</td>
                    <td className="py-3 px-3 text-center font-mono-num font-bold text-emerald-700">{r.hadir}</td>
                    <td className="py-3 px-3 text-center font-mono-num text-blue-700">{r.sakit}</td>
                    <td className="py-3 px-3 text-center font-mono-num text-amber-700">{r.izin}</td>
                    <td className="py-3 px-3 text-center font-mono-num font-bold text-rose-700">{r.alfa}</td>
                    <td className="py-3 px-3 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold font-mono-num ${
                        r.persen >= 85 ? 'bg-emerald-100 text-emerald-800' : r.persen >= 75 ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {r.persen}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Subtab 3: Santri yang Sering Tidak Masuk */}
      {activeSubTab === 'peringatan' && (
        <div className="space-y-4">
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 text-xs text-rose-900 space-y-1">
            <div className="font-bold text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>Sistem Peringatan Dini Ketidakhadiran Santri (Alfa ≥ 2 Kali)</span>
            </div>
            <p>
              Daftar santri berikut memiliki catatan ketidakhadiran tanpa keterangan (Alfa). Sesuai tata tertib Lembaga Al-Wasā'il, santri dengan Alfa ≥ 3 kali wajib menerima surat pemberitahuan dan pemanggilan wali santri.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {santriPeringatan.length === 0 ? (
              <div className="col-span-2 text-center py-10 bg-white rounded-xl border border-slate-200 text-slate-400 text-xs">
                Alhamdulillah, tidak ada santri yang memiliki catatan Alfa berlebih.
              </div>
            ) : (
              santriPeringatan.map(r => (
                <div key={r.santri.id} className="bg-white p-4 rounded-xl border border-rose-200 shadow-2xs space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{r.santri.nama}</h4>
                      <div className="text-[11px] text-slate-500 font-mono-num">
                        NIS: {r.santri.nis} · Rombel {r.kelasNama}
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded bg-rose-100 text-rose-800 font-bold text-xs font-mono-num">
                      {r.alfa} Kali Alfa
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100 space-y-1">
                    <div>Wali Santri: <strong className="text-slate-800">{r.santri.namaAyah} / {r.santri.namaIbu}</strong></div>
                    <div className="flex items-center gap-2">
                      <span>No. Kontak:</span>
                      <a
                        href={`https://wa.me/${r.santri.noHpWali.replace(/[^0-9]/g, '').replace(/^0/, '62')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-700 font-semibold font-mono-num hover:underline"
                      >
                        {r.santri.noHpWali} (Kirim Pesan WA)
                      </a>
                    </div>
                  </div>

                  <div className="pt-1 flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-medium">Persentase Hadir: <strong className="font-mono-num">{r.persen}%</strong></span>
                    <button
                      onClick={() => alert(`Surat panggilan wali santri untuk ${r.santri.nama} telah dicetak secara virtual.`)}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-semibold text-xs transition-colors"
                    >
                      Kirim Peringatan Wali
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

    </div>
  );
};
