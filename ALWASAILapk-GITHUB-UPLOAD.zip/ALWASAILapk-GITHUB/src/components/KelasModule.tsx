import React, { useState } from 'react';
import { DatabaseState, Kelas, UserAccount } from '../types';
import { Layers, Plus, Users, GraduationCap, Edit2, Trash2, ArrowRightLeft, X, BookOpen, Clock } from 'lucide-react';

interface KelasModuleProps {
  db: DatabaseState;
  currentUser: UserAccount;
  onUpdateKelas: (kelasList: Kelas[]) => void;
  onNavigateToSantriFiltered?: (kelasId: string) => void;
}

export const KelasModule: React.FC<KelasModuleProps> = ({
  db,
  currentUser,
  onUpdateKelas,
  onNavigateToSantriFiltered
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingKelas, setEditingKelas] = useState<Kelas | null>(null);
  const [selectedKelasDetail, setSelectedKelasDetail] = useState<Kelas | null>(null);

  const [formData, setFormData] = useState<Partial<Kelas>>({
    nama: '',
    waliKelasId: db.guru[0]?.id || '',
    tahunAjaran: db.pengaturan.tahunAjaranAktif,
    keterangan: ''
  });

  const canEdit = currentUser.role === 'admin';

  const handleOpenAdd = () => {
    setFormData({
      nama: '',
      waliKelasId: db.guru[0]?.id || '',
      tahunAjaran: db.pengaturan.tahunAjaranAktif,
      keterangan: ''
    });
    setEditingKelas(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (k: Kelas) => {
    setFormData(k);
    setEditingKelas(k);
    setIsModalOpen(true);
  };

  const handleSaveKelas = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama) return;

    if (editingKelas) {
      const updated = db.kelas.map(k => k.id === editingKelas.id ? { ...k, ...(formData as Kelas) } : k);
      onUpdateKelas(updated);
    } else {
      const newKelas: Kelas = {
        id: `k-${Date.now()}`,
        nama: formData.nama || '',
        waliKelasId: formData.waliKelasId || db.guru[0]?.id || '',
        tahunAjaran: formData.tahunAjaran || db.pengaturan.tahunAjaranAktif,
        keterangan: formData.keterangan || ''
      };
      onUpdateKelas([...db.kelas, newKelas]);
    }
    setIsModalOpen(false);
  };

  const handleDeleteKelas = (id: string, nama: string) => {
    const santriInClass = db.santri.filter(s => s.kelasId === id);
    if (santriInClass.length > 0) {
      alert(`Tidak dapat menghapus kelas "${nama}" karena masih memiliki ${santriInClass.length} santri aktif. Harap pindahkan santri terlebih dahulu.`);
      return;
    }
    if (window.confirm(`Yakin ingin menghapus rombel kelas "${nama}"?`)) {
      onUpdateKelas(db.kelas.filter(k => k.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-700">
            <Layers className="w-4 h-4" />
            <span>Rombongan Belajar (Rombel)</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
            Manajemen Kelas Al-Wasā’il
          </h2>
          <p className="text-xs text-slate-500">
            I’dadiyah (Dasar Shufhah 1-15), Takhassus A/B/C (Pendalaman Tarkib & Kitab Kuning).
          </p>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white font-bold rounded-xl text-xs transition-colors shadow-2xs self-start md:self-auto"
          >
            <Plus className="w-4 h-4 text-amber-300" />
            <span>Tambah Kelas Baru</span>
          </button>
        )}
      </div>

      {/* Grid Kelas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {db.kelas.map(k => {
          const wali = db.guru.find(g => g.id === k.waliKelasId);
          const santriInClass = db.santri.filter(s => s.kelasId === k.id);
          const santriAktif = santriInClass.filter(s => s.status === 'Aktif');
          const guruPengajar = db.guru.filter(g => g.kelasAmpu.includes(k.id));

          return (
            <div key={k.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
              
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-800 border border-amber-200/60 flex items-center justify-center font-bold text-lg shrink-0">
                    <Layers className="w-6 h-6 text-[#0B1B3D]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-base">{k.nama}</h3>
                    <div className="text-[11px] text-slate-500 font-mono-num">
                      Tahun Ajaran: {k.tahunAjaran}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {canEdit && (
                    <>
                      <button
                        onClick={() => handleOpenEdit(k)}
                        className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteKelas(k.id, k.nama)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Kurikulum & Wali Kelas Info */}
              <div className="space-y-2 text-xs bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Wali Kelas:</span>
                  <span className="font-bold text-slate-900">{wali?.nama || '-'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Jumlah Santri:</span>
                  <span className="font-bold text-slate-900 font-mono-num">
                    {santriAktif.length} Santri Aktif ({santriInClass.length} total)
                  </span>
                </div>
                <div className="pt-1 border-t border-slate-200/60 text-slate-600">
                  <span className="font-semibold text-slate-800">Fokus Pembelajaran: </span>
                  {k.keterangan || 'Kajian Metodologi Al-Wasā\'il'}
                </div>
              </div>

              {/* Guru Pengajar Tags */}
              <div className="text-xs">
                <span className="text-slate-500 font-medium">Asatidz Pengajar: </span>
                <span className="text-slate-700 font-medium">
                  {guruPengajar.map(g => g.nama).join(', ') || 'Belum diatur'}
                </span>
              </div>

              {/* Action: Lihat Daftar Santri di Rombel ini */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => setSelectedKelasDetail(k)}
                  className="text-xs font-semibold text-[#0B1B3D] hover:underline flex items-center gap-1"
                >
                  <Users className="w-3.5 h-3.5 text-amber-600" />
                  <span>Lihat {santriAktif.length} Santri di Kelas Ini</span>
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Modal: View Santri in Class */}
      {selectedKelasDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg my-8 overflow-hidden">
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">Daftar Santri: {selectedKelasDetail.nama}</h3>
                <p className="text-xs text-slate-300">Tahun Ajaran {selectedKelasDetail.tahunAjaran}</p>
              </div>
              <button
                onClick={() => setSelectedKelasDetail(null)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 text-xs space-y-3 max-h-[70vh] overflow-y-auto">
              {db.santri.filter(s => s.kelasId === selectedKelasDetail.id).length === 0 ? (
                <div className="text-center py-6 text-slate-400">Belum ada santri terdaftar di kelas ini.</div>
              ) : (
                db.santri.filter(s => s.kelasId === selectedKelasDetail.id).map((s, idx) => {
                  const prog = db.progres.find(p => p.santriId === s.id);
                  return (
                    <div key={s.id} className="p-3 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between">
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-2">
                          <span>{idx + 1}. {s.nama}</span>
                          <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                            s.status === 'Aktif' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                          }`}>
                            {s.status}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono-num">
                          NIS: {s.nis} · {s.gender === 'L' ? 'Putra' : 'Putri'} · Asal: {s.lembagaAsal}
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                          {prog?.kelancaranMembacaKitab || 'Belajar'}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedKelasDetail(null)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg font-medium text-xs"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Add / Edit Kelas */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="px-6 py-4 bg-[#0B1B3D] text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {editingKelas ? 'Edit Rombel Kelas' : 'Tambah Rombel Kelas Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-300 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveKelas} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nama Kelas *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Takhassus D, I'dadiyah Putra, dll."
                  value={formData.nama || ''}
                  onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Wali Kelas</label>
                <select
                  value={formData.waliKelasId || ''}
                  onChange={(e) => setFormData({ ...formData, waliKelasId: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-medium"
                >
                  {db.guru.map(g => (
                    <option key={g.id} value={g.id}>{g.nama}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Tahun Ajaran</label>
                <input
                  type="text"
                  value={formData.tahunAjaran || db.pengaturan.tahunAjaranAktif}
                  onChange={(e) => setFormData({ ...formData, tahunAjaran: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono-num"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Keterangan / Fokus Kurikulum</label>
                <textarea
                  rows={2}
                  value={formData.keterangan || ''}
                  onChange={(e) => setFormData({ ...formData, keterangan: e.target.value })}
                  placeholder="Deskripsi materi atau tahapan Al-Wasā'il kelas ini..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0B1B3D] hover:bg-[#162f66] text-white rounded-lg font-bold"
                >
                  Simpan Kelas
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
