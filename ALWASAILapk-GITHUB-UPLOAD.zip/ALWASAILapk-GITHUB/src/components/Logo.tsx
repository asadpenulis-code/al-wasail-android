import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  logoUrl?: string;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true,
  logoUrl
}) => {
  const iconSizes = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-base',
    xl: 'w-20 h-20 text-xl'
  };

  const titleSizes = {
    sm: 'text-base font-bold',
    md: 'text-lg font-bold',
    lg: 'text-2xl font-extrabold',
    xl: 'text-3xl font-extrabold'
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {logoUrl ? (
        <img
          src={logoUrl}
          alt="Logo Al-Wasā’il"
          className={`${iconSizes[size]} object-contain rounded-lg shadow-sm border border-amber-300/40`}
          referrerPolicy="no-referrer"
        />
      ) : (
        <div className={`${iconSizes[size]} shrink-0 rounded-xl bg-gradient-to-br from-[#0B1B3D] via-[#0E2656] to-[#08132B] border border-amber-400/40 text-amber-300 flex items-center justify-center shadow-sm relative group`}>
          {/* Subtle Islamic 8-point geometric star motif */}
          <svg className="w-3/5 h-3/5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
            {/* Open Kitab Kuning */}
            <path d="M2 4v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V4" />
            <path d="M12 4v18" />
            <path d="M2 4a2 2 0 0 1 2-2h8v18H4a2 2 0 0 1-2-2z" fill="#D4AF37" fillOpacity="0.2" />
            <path d="M22 4a2 2 0 0 0-2-2h-8v18h8a2 2 0 0 0 2-2z" fill="#D4AF37" fillOpacity="0.2" />
            {/* Pen/Reham symbol */}
            <circle cx="12" cy="3" r="1.5" fill="#FBBF24" />
          </svg>
        </div>
      )}

      <div className="flex flex-col">
        <div className="flex items-baseline gap-2">
          <span className={`${titleSizes[size]} tracking-tight text-[#0B1B3D] font-extrabold`}>
            AL-WASĀ’IL
          </span>
          <span className="font-arabic text-[#C59A27] font-bold text-sm tracking-wide">
            الْوَسَائِلُ
          </span>
        </div>
        {showSubtitle && (
          <span className="text-[11px] text-slate-500 font-medium leading-none tracking-normal">
            PP Al-Ihsan Jrangoan · Metode Membaca Kitab
          </span>
        )}
      </div>
    </div>
  );
};
